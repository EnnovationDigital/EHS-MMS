//
//  AttributedStringExtension.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 19/07/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import UIKit

extension NSMutableAttributedString {
    @discardableResult func bold(_ text: String) -> NSMutableAttributedString {
        let size = UIScreen.main.bounds.size.height <= 568.0 ? 15.0 : 15.0
        let attrs: [NSAttributedStringKey: Any] = [.font: UIFont.boldSystemFont(ofSize: CGFloat(size))]
        let boldString = NSMutableAttributedString(string:text, attributes: attrs)
        append(boldString)
        
        return self
    }
    
    @discardableResult func normal(_ text: String) -> NSMutableAttributedString {
        
        let attrs: [NSAttributedStringKey: Any] = [.font: UIFont.systemFont(ofSize: text == "\n" ? 0.0 : 13.0)]
        let normal = NSMutableAttributedString(string:text, attributes: attrs)
        append(normal)
        
        return self
    }
}

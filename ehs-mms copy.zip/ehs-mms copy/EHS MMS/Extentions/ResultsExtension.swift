//
//  ResultsExtension.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/19/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift
import Realm

extension Results {
    func toArray<T>(ofType: T.Type) -> [T] {
        let array = Array(self) as! [T]
        return array
    }
}

//
//  SampleData.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/23/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

extension InspectionTypes {
    // Realm Data
    func saveRealmData() {
        md_lkp_InspectionType().saveInspectionType(realm: realm, inspectionTypeId: -10, inspectionTypeName: "-- Select --", descriptionInspectionType: "nil", orderNo: 0, status: "Active")
        
        // saveRegions()
        md_lkp_Region().saveRegions(realm: realm, regionId: -999, regionName: "-- Select --", descriptionRegion: "empty", orderNo: 0, status: "Active")
        
        // saveBuildings()
        md_lkp_Buildings().saveBuildings(realm: realm, buildingId: -999, buildingName: "-- Select --", descriptionBuilding: "empty", orderNo: 0, regionId: -999, status: "Active")
        //
        // saveFloors()
        md_lkp_Floors().saveFloors(realm: realm, floorId: -999, floorName: "-- Select --", descriptionFloor: "empty", orderNo: 0, buildingId: -999, regionId: -999, status: "Active")
        
        // saveLocationType()
        md_lkp_LocationType().saveLocationTypes(realm: realm, locationTypeId: -999, locationType: "-- Select --", descriptionLocationType: "empty", orderNo: 0, status: "Active")
        
        // saveLocation()
        md_lkp_Locations().saveLocations(realm: realm, locationId: -999, locationName: "-- Select --", descriptionLocation: "empty", locationTypeId: -999, orderNo: 0, floorId: -999, buildingId: -999, regionId: -999, telephoneNo: "empty", status: "Active")
        
    }
}

extension NewInspectionView {

    func saveRealmData() {
        
    }
}


extension InspectionCategory  {
    
    func saveRealmData () {
        
    }
}

extension InspectionSubCategory {
    // Realm Data
    func saveRealmData() {
        
    }
}

extension QuestionVC {
    
    func saveRealmData() {
//
        
    }
}

//
//  APIConstants.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 30/07/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

public struct API {
    
    
    
    static let API_AUTH_KEY                         = "8438a04e8ca546e8ad39bdcc3340c8ad"
    
    //DEV -  "bc0bdd9b788b4ad8b20aa723fc6ee454"
    //Test - OLD - 612529041d074160afc3242c97f028a0
    static let API_BASE_URL                         = "https://services.incytetest.com/ehsmms/tibcoehsservices?servicecode=%@&key=%@"
    //"https://services.incytedev.com/ehsmms/tibcoehsservices?servicecode=%@&key=%@"
    //"http://services.incytedev.com/ehsdev/tibcoehsservices?servicecode=%@&key=%@"
    static let API_SERVER_URL                       = ""
    
    
    //MARK: - Access Token
    static let API_AUTHENTICATE_USER_CODE           = "LOGIN"
    
    //MARK: - User Details
    static let API_FETCH_USER_DETAILS_CODE          = "USERDETL"
    
    //MARK: - API to get Location data, User data and Question Data from Share Point.
    static let API_GET_MASTER_DATA_CODE             = "SYNCMDATA"
    
    //MARK: - CREATE
    //MARK: - API to create Inspection
    
    static let API_CREATE_NEW_INSPECTION_CODE       = "CRSI"
    
    // MARK: - Create a new record for tracking a ticket Progress
    
    static let API_CREATE_TRACKING_TICKET_CODE      = "CRSIP"
    
    // MARK: - Submit Question.
    static let API_CREATE_QUESTION_TICKET_CODE      = "CRSIQ"
    
    // MARK: - Add a picture to stg_InspectionQuestionsPicture Library
    
    static let API_SUBMIT_PICTURE_CODE              = "CRSIQP"
    
    
    //MARK: - GET
    
    // MARK: - Gets inspections from the list filtered by created by field
    static let API_GET_INSPECTIONS_CODE             = "GRSI"
    
    // MARK: - Gets Inspection Progress details related to an Inspection
    static let API_GET_INSPECTION_PROGRESS_CODE     = "GRSIP"
    
    // MARK: - Get Questions and Answers related to the Inspection.
    static let API_GET_INSPECTIONS_QUESTIONS_CODE   = "GRSIQ"
    
    // MARK: - Get Pending Inspections
    static let API_PENDING_INSPECTIONS_AT_PLACE     = "GROT"
    
    // MARK: - DELETE    
    // MARK: - Delete a record from stg_Inspection List.
    static let API_DELTE_INSPECTION_CODE            = "DRSI"
    
    // MARK: - Delete record from stg_InspectionQuestions.
    static let API_DELETE_QUESTION                  = "DRSIQ"
    
    // MARK: - Delete item from stg_InspectionQuestionsPicture.
    static let API_DELTE_IMAGE_FROMQUESTION_CODE    = "DRSIQP"
    
    // MARK: - DELETE INSPECTION
    static let API_DELETE_INSPECTION                = "DRINSDET"
    
    // MARK: - Update
    // MARK: - Update User Token
    static let API_UPDATE_USER_PUSH_TOKEN           = "URDT"
    
    // MARK: - Update Inspection
    static let API_UPDATE_QUESTION                  = "URSIQ"

    static let API_UPDATE_PCITURE                   = "URSIQP"
    
    
}


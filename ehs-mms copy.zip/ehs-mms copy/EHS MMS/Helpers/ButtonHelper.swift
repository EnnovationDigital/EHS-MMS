//
//  ButtonHelper.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/15/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import UIKit
public class ButtonHelper {
    
    class func setRoundCornerButton(button: UIButton) {
        button.layer.shadowOpacity = 0.5
        button.layer.shadowOffset = CGSize(width: 5.0, height: 5.0)
        button.layer.shadowRadius = 5.0
        button.layer.cornerRadius = 20.0
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOffset = CGSize(width: 5, height: 5)
        button.layer.masksToBounds = false
    }

    class func setRoundCornerButton(button: UIButton, cornerRadius: CGFloat) {
        button.layer.shadowOpacity = 0.5
        button.layer.shadowOffset = CGSize(width: 5.0, height: 5.0)
        button.layer.shadowRadius = 5.0
        button.layer.cornerRadius = cornerRadius
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOffset = CGSize(width: 5, height: 5)
        button.layer.masksToBounds = false
    }

    
    class func setBorderShadow(button: UIButton) {
        button.layer.shadowOpacity = 0.5
        button.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.borderColor = UIColor.blue.cgColor
    }
    
}

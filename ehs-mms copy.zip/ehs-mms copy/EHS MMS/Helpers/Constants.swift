//
//  Constants.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/20/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import Foundation

open class Constants {
    
    let isPad = UI_USER_INTERFACE_IDIOM() == .pad
    
    var blueColor = UIColor.init(red: 52.0/255.0, green: 51.0/255.0, blue: 153.0/255.0, alpha: 1.0)
    var grayColor = UIColor.init(red: 235.0/255.0, green: 235.0/255.0, blue: 235.0/255.0, alpha: 1.0)
    public var firstLaunch : Bool = false
    
    class func fetchIDFromMetaData(data:AnyObject) -> Int {
        
        let dictMeta = data["__metadata"] as! [String:String]
        let url = dictMeta["uri"]
        let arrURL = url?.components(separatedBy: "/")
        var strLastPart = arrURL?[(arrURL?.count)! - 1]
        print(strLastPart!)
        strLastPart = strLastPart?.replacingOccurrences(of: "Items(", with: "")
        strLastPart = strLastPart?.replacingOccurrences(of: ")", with: "")
        let qID = Int(strLastPart!)
        return qID!
    }
    
    func displayAlert(title: String, message: String, dismiss: String, view: UIViewController) {
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        if (title == "Discard") {
            let okAction = UIAlertAction (title: "YES", style: UIAlertActionStyle.cancel, handler: {
                (alert: UIAlertAction!) -> Void in
                let inspection = view.storyboard?.instantiateViewController(withIdentifier: "EntryView")
                view.show(inspection!, sender: self)
            })
            alert.addAction(okAction)
            NSLog("Discard Pressed")
        }
        alert.addAction(UIAlertAction.init(title: dismiss, style: .destructive, handler: nil))
        view.present(alert, animated: true, completion: nil)
    }
    
    func actionSheet(view : UIViewController, title : String, message : String, mainMenuCompletion : @escaping (_ result : UIAlertAction) -> Void, saveCompletion : @escaping (UIAlertAction) -> Void, discardCompletion : @escaping (UIAlertAction) -> Void) {
        
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: .actionSheet)
        
        let saveAction = UIAlertAction.init(title: "Save", style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            saveCompletion(alert)
//            
        })
        
        let discardAction = UIAlertAction.init(title: "Discard", style: .destructive, handler: {
            (alert: UIAlertAction!) -> Void in
            saveCompletion(alert)            
        })
        
        let mainMenu = UIAlertAction.init(title: "Main Menu", style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            let inspection = view.storyboard?.instantiateViewController(withIdentifier: "EntryView")
            view.show(inspection!, sender: self)
        })
        
        let cancel = UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil)
        
        alert.addAction(saveAction)
        alert.addAction(discardAction)
        alert.addAction(mainMenu)
        alert.addAction(cancel)
        
        alert.popoverPresentationController?.sourceView = view.view
        if UI_USER_INTERFACE_IDIOM() == .pad {
            //maxY
            alert.popoverPresentationController?.sourceRect = CGRect(x: view.view.bounds.midX, y: view.view.bounds.midY, width: 0, height: 0)
            alert.popoverPresentationController?.permittedArrowDirections = []
        } else {
            alert.popoverPresentationController?.sourceRect = view.view.bounds
        }
        view.present(alert, animated: true, completion: nil)
    }
    
    //check launch
    func isFirstLaunch() -> Bool {
        let firstLaunchFlag = "isFirstLaunchFlag"
        let isFirstLaunch = UserDefaults.standard.string(forKey: firstLaunchFlag) == nil
        if (isFirstLaunch) {
            firstLaunch = isFirstLaunch
            UserDefaults.standard.set("false", forKey: firstLaunchFlag)
            UserDefaults.standard.synchronize()
        }
        return firstLaunch || isFirstLaunch
    }
    
    func isLandScape () -> Bool {
        if UI_USER_INTERFACE_IDIOM() == .phone {
            return false
        }
        else {
            return UIApplication.shared.statusBarOrientation == .landscapeLeft || UIApplication.shared.statusBarOrientation == .landscapeRight
        }
    }
    
    func answerWidth () -> CGFloat {
        let screenWidth = UIScreen.main.bounds.size.width
        var answerWidth : CGFloat = 100.0
        if self.isLandScape() == true {
            answerWidth = (screenWidth - 60.0 - 250.0 - 140.0) / 2.0
        }
        else {
            if self.isPad {
                answerWidth = (screenWidth - 340.0 - 140.0) / 2.0
            }
            else {
                answerWidth = (screenWidth - 100.0 - 60.0) / 2.0
            }
        }
        
        return answerWidth
    }
}




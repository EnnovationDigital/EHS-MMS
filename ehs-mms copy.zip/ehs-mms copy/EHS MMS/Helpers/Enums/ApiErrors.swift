//
//  File.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 8/1/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

enum ApiErrors: String {
    case invalidCredentials = "Invalid Email or Password"
    //case
}

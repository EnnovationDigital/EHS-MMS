//
//  Form.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/30/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

class Form: NSObject {
    
    var regionId: Int = 0
    var buildingId: Int = 0
    var floorId: Int = 0
    var locationTypeId: Int = 0
    var locationId: Int = 0
    var insepectionTypeId: Int = 0
    
    // inspectionNo
    
    static let sharedInstance: Form = {
        let instance = Form()
        return instance
    }()
    
    override init() {
        super.init()
        regionId = 0
        buildingId = 0
        floorId = 0
        locationTypeId = 0
        locationId = 0
        insepectionTypeId = 0
    }
    
}

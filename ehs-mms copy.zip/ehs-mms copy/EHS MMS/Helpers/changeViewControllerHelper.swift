//
//  changeViewControllerHelper.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/17/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import UIKit
class changeViewControllerHelper {
    
    class func changeScreen (screenId: String!, controller: UIViewController) {
        let nView = controller.storyboard?.instantiateViewController(withIdentifier: screenId)
        nView?.modalTransitionStyle = .crossDissolve
        controller.present(nView!, animated: true, completion: nil)
    }
    
    class func changeScreenShow () {
        
    }
    
    class func changeScreenNav () {
        
    }
    
    
}

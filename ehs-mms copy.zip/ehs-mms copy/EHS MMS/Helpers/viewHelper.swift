//
//  viewHelper.swift
//  EHS MMS
//
//  Created by Macbook Pro on 6/11/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import UIKit
public class viewHelper {
    
    class func setBorderToView(view: UIView, color: CGColor) {
        view.layer.borderWidth = 1.5
        view.layer.borderColor = color
        view.layer.cornerRadius = 16.0
    }
    class func setBorderToViewWithRoundCorners(view: UIView, color: CGColor) {
        view.layer.borderWidth = 1.5
        view.layer.borderColor = color
        view.layer.cornerRadius = 15.0
    }
}

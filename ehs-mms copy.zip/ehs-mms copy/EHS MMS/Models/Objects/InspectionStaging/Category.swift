//
//  Category.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct Category: Codable {
    
    var categoryId : Int = 0
    var categoryName : String? = ""
    var inspectionTypeId : Int = 0
    var descriptionCategory : String? = "" // allows null
    var orderNo : Int = 0

}

//
//  Inspection.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct Inspection: Codable {
    
    var  inspectionId : String? = ""
    var  inspectionNo : Int = 0       // data type
    var  createBy : String? = ""      // allows nil
    var  createDate : String? = ""    // allows nil
    var  modifiedDate : String? = ""  // allows nil
    var  modifiedBy : String? = ""    // allows nil
    var  isSubmitted : Bool = false
    var  isSaved : Bool = false
    var  description_Stg : String? = ""   // allows nil
    var  regionId : Int = 0
    var  buildingId : Int = 0
    var  floorId : Int = 0
    var  locationTypeId : Int = 0
    var  locationId : Int = 0
    var  inspectionTypeId : Int = 0

}

//
//  InspectionProgress.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct InspectionProgress: Codable {
    
    var inspectionProgressId : Int = 0
    var inspectionId : Int = 0
    var categoryId : Int = 0
    var subCategoryId : Int = 0
    var totalQuestions : Int = 0      // allow nil ? confirm
    var totalAnswered : String? = ""   // allow nil
    var isCompleted: Bool = false
    var inspectionTypeId: Int = 0

}

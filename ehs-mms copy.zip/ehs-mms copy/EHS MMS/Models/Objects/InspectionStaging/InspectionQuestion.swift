//
//  InspectionQuestion.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct InspectionQuestion: Codable {
    
    var inspectionQuestionId : Int = 0
    var inspectionId : Int = 0            // inspectionNo
    var questionId : Int = 0
    var answerId : Int = 0
    var cagetoryId : Int = 0
    var subCategoryId : Int = 0
    var assignedTo : String? = ""          // allows nil
    var comments : String? = ""            // allows nil
    var inspectionTypeId : Int = 0
    var assignToEHS : Bool = false
    var repeatId : String? = ""

}

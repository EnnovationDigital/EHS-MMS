//
//  InspectionType.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct InspectionType: Codable {
    
    var inspectionTypeId : Int = 0
    var inspectionTypeName : String? = ""
    var descriptionInspectionType : String? = "" // allows null
    var orderNo : Int = 0

}

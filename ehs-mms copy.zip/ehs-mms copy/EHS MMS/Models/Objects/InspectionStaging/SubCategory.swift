//
//  SubCategory.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct SubCategory: Codable {
    
    var subCategoryId : Int = 0
    var subCategoryName : String? = ""            // allow nil
    var descriptionSubCategory : String? = ""     // allow nil
    var orderNo : Int = 0
    var categoryId : Int = 0
    var inspectionTypeId : Int = 0

}

//
//  lkp_Building.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct Building: Codable {
    
    var buildingId : Int = 0
    var buildingName : String? = ""
    var descriptionBuilding : String? = ""  // allows null
    var orderNo : Int = 0
    var regionId : Int = 0
}

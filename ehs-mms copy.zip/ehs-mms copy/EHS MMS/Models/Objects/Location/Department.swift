//
//  lkp_Departments.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct Department: Codable {
    
    var departmentId: Int = 0
    var department : String? = ""

}

//
//  lkp_Floor.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct Floor: Codable {
    
    var floorId : Int = 0
    var floorName : String? = ""
    var descriptionFloor : String? = ""
    var orderNo : Int = 0
    var buildingId : Int = 0
    var regionId : Int = 0
    
}

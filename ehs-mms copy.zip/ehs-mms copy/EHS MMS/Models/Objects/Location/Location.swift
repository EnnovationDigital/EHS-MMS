//
//  lkp_Location.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct Location: Codable {
    
    var locationId : Int = 0
    var locationName : String? = ""           // allows null
    var descriptionLocation : String? = ""    // allows null
    var locationTypeId : Int = 0
    var orderNo : Int = 0
    var floorId : Int = 0
    var buildingId : Int = 0
    var regionId : Int = 0
    var telephoneNo : String? = ""         // allows null

}

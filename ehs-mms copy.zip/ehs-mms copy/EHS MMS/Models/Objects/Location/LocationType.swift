//
//  lkp_LocationType.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct LocationType: Codable {
    
    var locationTypeId : Int = 0
    var locationType : String? = ""                // allows null
    var descriptionLocationType : String? = ""     // allows null
    var orderNo : Int = 0

}

//
//  lkp_Regions.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct Region: Codable {
    
    var regionId : Int = 0
    var regionName : String? = ""         // allows null
    var descriptionRegion : String? = ""  // allows null
    var orderNo : Int = 0
    
    
}

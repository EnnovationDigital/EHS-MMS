//
//  User.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct User: Codable {
    
    var userId : Int = 0
    var userName : String? = ""
    var workEmail : String? = ""          // allows nil
    var personalEmail : String? = ""      // allows nil
    var departmentId : Int = 0
    var supervisor : String? = ""
    var phoneNo : String? = ""            // allows nil
    var orderNo : Int = 0
    
}

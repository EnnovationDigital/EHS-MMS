//
//  UserLocation.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct UserLocation: Codable {
    
    var userLocationId : Int = 0
    var locationId : Int = 0
    var userId : Int = 0
    var orderNo : String? = ""

}

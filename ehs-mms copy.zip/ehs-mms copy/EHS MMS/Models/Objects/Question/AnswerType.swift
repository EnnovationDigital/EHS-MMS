//
//  AnswerType.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct AnswerType: Codable {
    
    var answerTypeId: Int = 0
    var answerType: String? = ""  // allows null
    var status: String? = ""

}

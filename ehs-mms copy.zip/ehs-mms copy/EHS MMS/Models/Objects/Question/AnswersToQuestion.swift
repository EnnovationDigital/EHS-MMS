//
//  AnswersToQuestion.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct AnswersToQuestion: Codable {
    
    var answerId : Int = 0
    var questionId : Int = 0              // allows null
    var regulationId : Int = 0
    var answer : String? = ""             // allows null
    var orderNo : Int = 0                 // allows null
    var isDecisionAnswer : Bool = false   // allows null
    var isDefaultAnswer : Bool = false    // allows null
    var defaultAnswer : String? = ""      // allows null
    var status : String? = ""             //
    var triggersEmail : Bool = false   // allows null


}

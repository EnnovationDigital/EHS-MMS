//
//  IssuesType.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct issueType: Codable {
    
    var issueTypeId: Int = 0
    var issueType: String? = ""            // allows null
    var descriptionIssue: String? = ""    // allows null
    var status: String? = ""

}

//
//  Question.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct Question: Codable {
    
    var questionId : Int = 0
    var question : String? = ""           // allows nil
    var catgeoryId : Int = 0
    var subCatgeoryId : Int = 0
    var isReaptable : Bool = false
    var orderNo : Int = 0
    var descriptionOfRepeatability : String? = ""     // allows nil
    var noOfRepeats : Int = 0
    var parentQuestionId : Int = 0
    var inspectionTypeId : Int = 0
    var status : String? = ""
    var answerTypeId : Int = 0

}

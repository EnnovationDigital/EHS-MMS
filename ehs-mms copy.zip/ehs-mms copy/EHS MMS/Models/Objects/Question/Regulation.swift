//
//  Regulation.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct Regulation: Codable {
    
    var regulationId: Int = 0
    var issueTypeId: Int = 0
    var regulation: Int = 0
    var possibleFineAmount: Int = 0
    var orderNo: Int = 0
    var priority: Int = 0
    var status: String? = ""

}

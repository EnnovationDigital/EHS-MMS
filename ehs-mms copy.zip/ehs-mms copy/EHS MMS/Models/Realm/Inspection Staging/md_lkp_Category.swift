//
//  md_lkp_Category.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class md_lkp_Category: Object {
    
    @objc dynamic var categoryId : Int = 0
    @objc dynamic var categoryName : String? = ""
    @objc dynamic var inspectionTypeId : Int = 0
    @objc dynamic var descriptionCategory : String? = "" // allows null
    @objc dynamic var orderNo : Int = 0
    @objc dynamic var Active : String = ""
    @objc dynamic var status : String = ""
    
    convenience init (categoryId: Int, categoryName: String?, inspectionTypeId: Int, descriptionCategory: String?, orderNo: Int, status: String) {
        self.init()
        self.categoryId = categoryId
        self.categoryName = categoryName
        self.inspectionTypeId = inspectionTypeId
        self.descriptionCategory = descriptionCategory
        self.orderNo = orderNo
        self.status = status
    }
    
    func saveCategoryMData(data:[String:AnyObject]) {
        
        let arrCateg = data["results"] as! [AnyObject]
        for categ in arrCateg {
            let category = categ["Category"] as! String
            let desc = "empty"//categ["Description"] as! String
            let order = categ["OrderNo"] as! Int
            let status = categ["Status"] as! String
            let inspection = Int(categ["InspectionTypeId"] as! String)
            let realm = try! Realm()
            let categoryID = categ["ID"] as! Int //Constants.fetchIDFromMetaData(data: categ)
            if getCategory(categoryId: categoryID) == -1 {
                saveCategory(realm: realm, categoryId: categoryID, categoryName: category, inspectionTypeId: inspection!, descriptionCategory: desc, orderNo: order, status: status)
            }
        }
    }
    
    func saveCategory(realm: Realm, categoryId: Int, categoryName: String?, inspectionTypeId: Int, descriptionCategory: String?, orderNo: Int, status: String) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_lkp_Category.self)
        
        let newCategory = md_lkp_Category(categoryId: categoryId,
                                          categoryName: categoryName,
                                          inspectionTypeId: inspectionTypeId,
                                          descriptionCategory: descriptionCategory,
                                          orderNo: orderNo,
                                          status: status)
        RealmService.shared.create(newCategory)
    }
    
    func getCategory(categoryId: Int) -> Int {
        let realm = try! Realm()
        let filteredInspectionType = realm.objects(md_lkp_Category.self).filter("categoryId == %@", categoryId)
        if filteredInspectionType.count == 0 {
            return -1
        }
        let id = filteredInspectionType[0].categoryId
        return id
    }
    
    class func filterCategory (inspectionID: Int) -> Results<md_lkp_Category> {
        let realm = try! Realm()
        return realm.objects(md_lkp_Category.self).filter("inspectionTypeId == %@", inspectionID).sorted(byKeyPath: "orderNo", ascending: true).sorted(byKeyPath: "orderNo", ascending: true)
    }
}





















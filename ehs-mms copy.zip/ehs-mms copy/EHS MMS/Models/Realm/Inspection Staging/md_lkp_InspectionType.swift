//
//  stg_Inspection.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class md_lkp_InspectionType: Object {
    
    @objc dynamic var inspectionTypeId : Int = 0
    @objc dynamic var inspectionTypeName : String? = ""
    @objc dynamic var descriptionInspectionType : String? = "" // allows null
    @objc dynamic var orderNo : Int = 0
    @objc dynamic var status : String = ""
    
    convenience init (inspectionTypeId: Int, inspectionTypeName: String?, descriptionInspectionType: String?, orderNo: Int, status: String) {
        self.init()
        self.inspectionTypeId = inspectionTypeId
        self.inspectionTypeName = inspectionTypeName
        self.descriptionInspectionType = descriptionInspectionType
        self.orderNo = orderNo
        self.status = status
    }
    
    func saveInspectionMData(data:[String:AnyObject]) {
        print(data)
        let arrInspections = data["results"] as! [AnyObject]
        for inspection in arrInspections {
            let name = inspection["InspectionType"] as! String
            let desc = "empty" //inspection["Description"] as! String
            let order = inspection["OrderNo"] as! Int
            let status = inspection["Status"] as! String
            let inspectionTypeID = inspection["ID"] as! Int //Constants.fetchIDFromMetaData(data: inspection)
            let realm = try! Realm()
            if getInspectionTypeId(inspectionTypeName: name) == -1 {
                saveInspectionType(realm: realm, inspectionTypeId: inspectionTypeID, inspectionTypeName: name, descriptionInspectionType: desc, orderNo: order, status: status)
            }
        }
    }
    
    //    override static func primaryKey() -> String? {
    //        return "regionId"
    //    }
    
    /*
    func autoIncrementId() -> Int {
        let realm = try! Realm()
        return (realm.objects(md_lkp_InspectionType.self).max(ofProperty: "regionId") as Int? ?? 0) + 1
    }
     */
    
    func saveInspectionType(realm: Realm, inspectionTypeId: Int, inspectionTypeName: String?, descriptionInspectionType: String?, orderNo: Int, status: String) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_lkp_InspectionType.self)
        
        let newInspection = md_lkp_InspectionType(inspectionTypeId: inspectionTypeId,
                                                  inspectionTypeName: inspectionTypeName,
                                                  descriptionInspectionType: descriptionInspectionType,
                                                  orderNo: orderNo,
                                                  status: status)
        RealmService.shared.create(newInspection)
    }
    
    func getInspectionTypeId(inspectionTypeName: String) -> Int {
        let realm = try! Realm()
        let filteredInspectionType = realm.objects(md_lkp_InspectionType.self).filter("inspectionTypeName == %@", inspectionTypeName)
        if filteredInspectionType.count == 0 {
            return -1
        }
        let id = filteredInspectionType[0].inspectionTypeId
        return id
    }

}

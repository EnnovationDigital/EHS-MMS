//
//  md_lkp_SubCategory.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class md_lkp_SubCategory: Object {
    
    @objc dynamic var subCategoryId : Int = 0
    @objc dynamic var subCategoryName : String? = ""            // allow nil
    @objc dynamic var descriptionSubCategory : String? = ""     // allow nil
    @objc dynamic var orderNo : Int = 0
    @objc dynamic var categoryId : Int = 0
    @objc dynamic var inspectionTypeId : Int = 0
    @objc dynamic var status : String = ""

    
    convenience init (subCategoryId: Int, subCategoryName: String?, descriptionSubCategory: String?, orderNo: Int, categoryId: Int, inspectionTypeId: Int, status: String) {
        self.init()
        self.subCategoryId = subCategoryId
        self.subCategoryName = subCategoryName
        self.descriptionSubCategory = descriptionSubCategory
        self.orderNo = orderNo
        self.categoryId = categoryId
        self.inspectionTypeId = inspectionTypeId
        self.status = status
    }
    
    func saveSubCategoryMData(data:[String:AnyObject]) {
        print(data)
        let arrCateg = data["results"] as! [AnyObject]
        for categ in arrCateg {
            let category = categ["SubCategory"] as! String
            let desc = "empty" //categ["Description"] as! String
            let order = categ["OrderNo"] as! Int
            let status = categ["Status"] as! String
            let inspection = Int(categ["InspectionTypeId"] as! String)
            let categoryId = Int(categ["CategoryId"] as! String)
            let subCategoryId = categ["ID"] // Constants.fetchIDFromMetaData(data: categ)
            let realm = try! Realm()
            if getSubCategory(subCategoryId: subCategoryId as! Int) == -1 {
                saveSubCategory(realm: realm, subCategoryId: subCategoryId as! Int, subCategoryName: category, descriptionSubCategory: desc, orderNo: order, categoryId: categoryId!, inspectionTypeId: inspection!, status: status)
            }
        }
    }
    
    
    
    //    override static func primaryKey() -> String? {
    //        return "regionId"
    //    }
    
    /*
     func autoIncrementId() -> Int {
     let realm = try! Realm()
     return (realm.objects(md_lkp_SubCategory.self).max(ofProperty: "orderNo") as Int? ?? 0) + 1
     }
     */
    
    func saveSubCategory(realm: Realm, subCategoryId: Int, subCategoryName: String?, descriptionSubCategory: String?, orderNo: Int, categoryId: Int, inspectionTypeId: Int, status: String) {
        _ = RealmService.shared.realm
        var subCategory = realm.objects(md_lkp_SubCategory.self)
        
        let newSubCategory = md_lkp_SubCategory(subCategoryId: subCategoryId,
                                                subCategoryName: subCategoryName,
                                                descriptionSubCategory: descriptionSubCategory,
                                                orderNo: orderNo,
                                                categoryId: categoryId,
                                                inspectionTypeId: inspectionTypeId,
                                                status: status)
        RealmService.shared.create(newSubCategory)
    }
    
    func getSubCategory(subCategoryId: Int) -> Int {
        let realm = try! Realm()
        let filteredInspectionType = realm.objects(md_lkp_SubCategory.self).filter("subCategoryId == %@", subCategoryId)
        if filteredInspectionType.count == 0 {
            return -1
        }
        let id = filteredInspectionType[0].subCategoryId
        return id
    }
}


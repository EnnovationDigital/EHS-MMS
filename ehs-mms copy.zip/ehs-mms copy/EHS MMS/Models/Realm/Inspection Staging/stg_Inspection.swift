//
//  stg_Inspection.swift
//  EHS MMS
//
//  Created by Macbook Pro on 6/30/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class stg_Inspection: Object {
    
    @objc dynamic var  inspectionId : String? = ""
    @objc dynamic var  inspectionNo : Int = 0       // data type
    @objc dynamic var  inspectionItemId : Int = 0       // data type
    @objc dynamic var  createBy : String? = ""      // allows nil
    @objc dynamic var  createDate : String? = ""    // allows nil
    @objc dynamic var  modifiedDate : String? = ""  // allows nil
    @objc dynamic var  modifiedBy : String? = ""    // allows nil
    @objc dynamic var  isSubmitted : Bool = false
    @objc dynamic var  isSaved : Bool = false
    @objc dynamic var  description_Stg : String? = ""   // allows nil
    @objc dynamic var  regionId : Int = 0
    @objc dynamic var  buildingId : Int = 0
    @objc dynamic var  floorId : Int = 0
    @objc dynamic var  locationTypeId : Int = 0
    @objc dynamic var  locationId : Int = 0
    @objc dynamic var  inspectionTypeId : Int = 0
        
    convenience init (inspectionId: String?, inspectionNo: Int, createdBy: String?, createDate: String?, modifiedDate: String?, modifiedBy: String?, isSubmitted: Bool, isSaved: Bool, description_Stg: String?, regionId: Int, buildingId: Int, floorId: Int, locationTypeId: Int, locationId: Int, inspectionTypeId: Int) {
        self.init()
        self.inspectionId = inspectionId
        self.inspectionNo = autoIncrementId ()
        self.createBy = createdBy
        self.createDate = createDate
        self.modifiedDate = modifiedDate
        self.modifiedBy = modifiedBy
        self.isSubmitted = isSubmitted
        self.isSaved = isSaved
        self.description_Stg = description_Stg
        self.regionId = regionId
        self.buildingId = buildingId
        self.floorId = floorId
        self.locationTypeId = locationTypeId
        self.locationId = locationId
        self.inspectionTypeId = inspectionTypeId
    }
    
    func autoIncrementId () -> Int {
        let realm = try! Realm()
        return (realm.objects(stg_Inspection.self).max(ofProperty: "inspectionNo") as Int? ?? 0) + 1
    }
    
    class func lastInspectionId () -> Int {
        let realm = try! Realm()
        return (realm.objects(stg_Inspection.self).max(ofProperty: "inspectionNo") as Int? ?? 0)
    }
    
    func saveInspection(realm: Realm ,inspectionId: String?, inspectionNo: Int, createdBy: String?, createDate: String?, modifiedDate: String?, modifiedBy: String?, isSubmitted: Bool, isSaved: Bool, description_Stg: String?, regionId: Int, buildingId: Int, floorId: Int, locationTypeId: Int, locationId: Int, inspectionTypeId: Int) -> stg_Inspection {
        _ = RealmService.shared.realm
        _ = realm.objects(stg_Inspection.self)
        
        
        let newInspection  = stg_Inspection(inspectionId: inspectionId,
                                            inspectionNo: inspectionNo,
                                            createdBy: createdBy,
                                            createDate: createDate,
                                            modifiedDate: modifiedDate,
                                            modifiedBy: modifiedBy,
                                            isSubmitted: isSubmitted,
                                            isSaved: isSaved,
                                            description_Stg: description_Stg,
                                            regionId: regionId,
                                            buildingId: buildingId,
                                            floorId: floorId,
                                            locationTypeId: locationTypeId,
                                            locationId: locationId,
                                            inspectionTypeId: inspectionTypeId)
        
        RealmService.shared.create(newInspection)
        
        return newInspection
    }

    class func getReportFromInspectionID(inspectionId: String) -> stg_Inspection? {
        let realm = try! Realm()
        let filteredQuestion = realm.objects(stg_Inspection.self).filter("inspectionId == %@", inspectionId)
        if filteredQuestion.count > 0 {
            return filteredQuestion[0]
        }
        else {
            return nil
        }
    }
    
    class func getReportFromId(inspectionId: Int) -> stg_Inspection? {
        let realm = try! Realm()
        let filteredQuestion = realm.objects(stg_Inspection.self).filter("inspectionNo == %@", inspectionId)
        if filteredQuestion.count > 0 {
            return filteredQuestion[0]
        }
        else {
            return nil
        }
    }
    
    class func unsubmittedReports () -> Results<stg_Inspection> {
        
        let realm = try! Realm()
        let filtered = realm.objects(stg_Inspection.self).filter("isSubmitted == %@ && isSaved == %@", false,true)
        return filtered
    }
    
    class func saveInspectionWithStatus (inspectionId:Int, status: Bool) {
        // fetch the inspection and save the status
        let inspection = stg_Inspection.getReportFromId(inspectionId: inspectionId)
        if inspection != nil {
            let realm = try! Realm()
            try! realm.write {
                inspection?.isSaved = status
            }
        }
    }
    class func submitInspectionWithStatus (inspectionId:Int, status: Bool) {
        // fetch the inspection and save the status
        let inspection = stg_Inspection.getReportFromId(inspectionId: inspectionId)
        if inspection != nil {
            let realm = try! Realm()
            try! realm.write {
                inspection?.isSubmitted = status
            }
        }
    }
}

































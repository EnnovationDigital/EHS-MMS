//
//  stg_InspectionProgress.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class stg_InspectionProgress: Object {
    
    @objc dynamic var inspectionProgressId : Int = 0
    @objc dynamic var inspectionId : Int = 0
    @objc dynamic var categoryId : Int = 0
    @objc dynamic var subCategoryId : Int = 0
    @objc dynamic var totalQuestions : Int = 0      // allow nil ? confirm
    @objc dynamic var totalAnswered : String? = ""   // allow nil
    @objc dynamic var isCompleted: Bool = false
    @objc dynamic var inspectionTypeId: Int = 0
    
    convenience init(inspectionProgressId: Int, inspectionId: Int, categoryId: Int, subCategoryId: Int, totalQuestions: Int, totalAnswered: String?, isCompleted: Bool, inspectionTypeId: Int) {
        self.init()
        self.inspectionProgressId = inspectionProgressId
        self.inspectionId = inspectionId
        self.categoryId = categoryId
        self.subCategoryId = subCategoryId
        self.totalQuestions = totalQuestions
        self.totalAnswered = totalAnswered
        self.isCompleted = isCompleted
        self.inspectionTypeId = inspectionTypeId
    }
    
    /*
     func autoIncrementId() -> Int {
     let realm = try! Realm()
     return (realm.objects(stg_InspectionProgress.self).max(ofProperty: "orderNo") as Int? ?? 0) + 1
     }
     */
    
    func saveInspectionProgress(realm: Realm , inspectionProgressId: Int, inspectionId: Int, categoryId: Int, subCategoryId: Int, totalQuestions: Int, totalAnswered: String?, isCompleted: Bool, inspectionTypeId: Int ) {
        _ = RealmService.shared.realm
        var inspectionQuestions = realm.objects(stg_InspectionQuestions.self)
        
        
        let newInspectionQuestion  = stg_InspectionProgress(inspectionProgressId: inspectionProgressId,
                                                            inspectionId: inspectionId,
                                                            categoryId: categoryId,
                                                            subCategoryId: subCategoryId,
                                                            totalQuestions: totalQuestions,
                                                            totalAnswered: totalAnswered,
                                                            isCompleted: isCompleted,
                                                            inspectionTypeId: inspectionTypeId)
        RealmService.shared.create(newInspectionQuestion)
    }
}


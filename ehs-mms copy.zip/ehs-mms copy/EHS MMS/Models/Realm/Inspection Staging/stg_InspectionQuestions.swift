//
//  stg_InspectiosQuestions.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class stg_InspectionQuestions: Object {
    
    @objc dynamic var inspectionQuestionId : Int = 0
    @objc dynamic var inspectionId : Int = 0            // inspectionNo
    @objc dynamic var questionId : Int = 0
    @objc dynamic var answerId : Int = 0
    @objc dynamic var cagetoryId : Int = 0
    @objc dynamic var subCategoryId : Int = 0
    @objc dynamic var assignedTo : String? = ""          // allows nil
    @objc dynamic var comments : String? = ""            // allows nil
    @objc dynamic var inspectionTypeId : Int = 0
    @objc dynamic var assignToEHS : Bool = false
    @objc dynamic var repeatId : String? = ""

    convenience init(inspectionQuestionId: Int, inspectionId: Int,questionId: Int, answerId: Int, cagetoryId: Int, subCategoryId: Int, assignedTo: String?,comments: String?,inspectionTypeId: Int, assignToEHS: Bool, repeatId: String?) {
        self .init()
        self.inspectionQuestionId = inspectionQuestionId
        self.inspectionId = inspectionId
        self.questionId = questionId
        self.answerId = answerId
        self.cagetoryId = cagetoryId
        self.subCategoryId = subCategoryId
        self.assignedTo = assignedTo
        self.comments = comments
        self.assignToEHS = assignToEHS
        self.repeatId = repeatId
    }
    
    /*
     func autoIncrementId() -> Int {
     let realm = try! Realm()
     return (realm.objects(stg_InspectiosQuestions.self).max(ofProperty: "orderNo") as Int? ?? 0) + 1
     }
     */
    
    func saveInspectionQuestions(realm: Realm , inspectionQuestionId: Int, inspectionId: Int, questionId: Int, answerId: Int, cagetoryId: Int, subCategoryId: Int, assignedTo: String?,comments: String?, inspectionTypeId: Int, assignToEHS: Bool, repeatId: String? ) {
        _ = RealmService.shared.realm
        _ = realm.objects(stg_InspectionQuestions.self)
        
        
        let newInspectionQuestion  = stg_InspectionQuestions(inspectionQuestionId: inspectionQuestionId,
                                                             inspectionId: inspectionId,
                                                             questionId: questionId,
                                                             answerId: answerId,
                                                             cagetoryId: cagetoryId,
                                                             subCategoryId: subCategoryId,
                                                             assignedTo: assignedTo,
                                                             comments: comments,
                                                             inspectionTypeId: inspectionTypeId,
                                                             assignToEHS: assignToEHS,
                                                             repeatId: repeatId)
        RealmService.shared.create(newInspectionQuestion)
    }
}

//
//  stg_InspectionQuestionsPicture.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class stg_InspectionQuestionsPicture: Object {
    
    @objc dynamic var inspectionQuestionPictureId : Int = 0
    @objc dynamic var inspectionId : Int = 0
    @objc dynamic var questionId : Int = 0
    @objc dynamic var picture : String? = ""  // Base64
    @objc dynamic var repeatId : String? = ""
    @objc dynamic var name : String? = ""
    //@objc dynamic var answerId : Int = 0
    
    convenience init(inspectionQuestionPictureId: Int, inspectionId: Int, questionId: Int, picture: String?, repeatId: String?, name: String?) { //answerId: Int,
        self.init()
        self.inspectionQuestionPictureId = autoIncrementId()
        self.inspectionId = inspectionId
        self.questionId = questionId
        self.repeatId = repeatId
        self.picture = picture
        self.name = name
    }
    
    func autoIncrementId() -> Int {
        let realm = try! Realm()
        return (realm.objects(stg_InspectionQuestionsPicture.self).max(ofProperty: "inspectionQuestionPictureId") as Int? ?? 0) + 1
    }
    
    
    func saveInspectionQuestionsPicture(realm: Realm , inspectionQuestionPictureId: Int,inspectionId: Int, questionId: Int, answerId: Int, picture: String?, repeatId: String?, name:String?) {
        _ = RealmService.shared.realm
        var inspectionQuestions = realm.objects(stg_InspectionQuestionsPicture.self)
        
        
        let newInspectionQuestionPicture  = stg_InspectionQuestionsPicture(inspectionQuestionPictureId: inspectionQuestionPictureId,
                                                                           inspectionId: inspectionId,
                                                                           questionId: questionId,
                                                                           picture: picture,
                                                                           repeatId: repeatId,
                                                                           name:name)
        RealmService.shared.create(newInspectionQuestionPicture)
    }
    
    class func getPictures(questionId: Int) -> Results<stg_InspectionQuestionsPicture>? {
        let realm = try! Realm()
        let filteredPictures: Results<stg_InspectionQuestionsPicture> = realm.objects(stg_InspectionQuestionsPicture.self).filter("questionId == %@", questionId)
        //print(filteredRegions)
        if filteredPictures.count > 0 {
            return filteredPictures
        }
        return nil
    }
    
    class func getPicturesByName(imageName: String) -> Results<stg_InspectionQuestionsPicture>? {
        
        let realm = try! Realm()
        let filteredPictures: Results<stg_InspectionQuestionsPicture> = realm.objects(stg_InspectionQuestionsPicture.self).filter("name == %@", imageName)
        
        if filteredPictures.count > 0 {
            return filteredPictures
        }
        
        return nil
    }
}

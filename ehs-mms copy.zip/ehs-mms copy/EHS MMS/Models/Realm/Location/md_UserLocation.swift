//
//  md_UserLocation.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/15/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

@objcMembers class md_UserLocation: Object {
    
    @objc dynamic var userLocationId : Int = 0
    @objc dynamic var locationId : Int = 0
    @objc dynamic var userId : Int = 0
    @objc dynamic var orderNo : String? = ""
    @objc dynamic var status : String = ""
    
    convenience init (userLocationId: Int, locationId: Int, userId: Int, orderNo: String?, status: String) {
        self.init()
        self.userLocationId = userLocationId
        self.locationId = locationId
        self.userId = userId
        self.orderNo = orderNo
        self.status = status
    }
    
    func saveUserLocationsMData(data:[String:AnyObject]) {        
        let arrUserLocations = data["results"] as! [AnyObject]
        for userLoc in arrUserLocations {
            let Id = userLoc["ID"] as! Int
            let location = userLoc["LocationId"] as! Int
            let userID = userLoc["UserNameId"] as! Int
            let order = String(format: "%ld",userLoc["OrderNo"] as! Int)
            let status = userLoc["Status"] as! String
            let realm = try! Realm()
            if md_UserLocation.getUserLocationId(userLocID: Id).count == 0 {
                saveUserLocations(realm: realm, userLocationId: Id, locationId: location, userId: userID, orderNo: order, status: status)
            }
        }
    }
    
    func saveUserLocations(realm: Realm, userLocationId: Int, locationId: Int, userId: Int, orderNo: String?, status: String) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_UserLocation.self)
        
        let newUserLocation  = md_UserLocation(userLocationId: userLocationId, locationId: locationId, userId: userId, orderNo: orderNo, status: status)
        RealmService.shared.create(newUserLocation)
    }
    
    class func getUserLocationId(userLocID: Int) -> Results<md_UserLocation> {
        let realm = try! Realm()
        let filteredUserLoc = realm.objects(md_UserLocation.self).filter("locationId == %@ ", userLocID)
        return filteredUserLoc
    }
    
}

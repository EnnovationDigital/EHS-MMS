//
//  md_Users.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/15/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

@objcMembers class md_Users: Object {
    
    @objc dynamic var userId : Int = 0
    @objc dynamic var userName : String? = ""
    @objc dynamic var workEmail : String? = ""          // allows nil
    @objc dynamic var personalEmail : String? = ""      // allows nil
    @objc dynamic var departmentId : Int = 0
    @objc dynamic var supervisor : String? = ""
    @objc dynamic var phoneNo : String? = ""            // allows nil
    @objc dynamic var orderNo : Int = 0
    @objc dynamic var status : String = ""
    
    convenience init (userId: Int, userName: String?, workEmail: String?, personalEmail: String?, departmentId: Int, supervisor: String?, phoneNo: String?, orderNo: Int, status: String) {
        self.init()
        self.userId = userId
        self.userName = userName
        self.workEmail = workEmail
        self.personalEmail = personalEmail
        self.departmentId = departmentId
        self.supervisor = supervisor
        self.phoneNo = phoneNo
        self.orderNo = orderNo
        self.status = status
    }
    
    func saveUsersMData(data:[String:AnyObject]) {
        print(data)
        let arrUsers = data["results"] as! [AnyObject]
        for user in arrUsers {
            let Id = user["ID"] as! Int
            let wEmail = user["WorkEmail"] as! String
            let pEmail =  "empty" //user["PersonalEmail"] as! String
            let phone  = "empty" //user["PhoneNo"] as! String
            let order = user["OrderNo"] as! Int
//            let dep = user["DepartmentId"] as! Int
            let status = user["Status"] as! String
//            let dictUserName = user["UserName"] as! [String:AnyObject]
            let userName = user["UserName"] as! String
            
//            let dictSupervisor = user["Supervisor"] as! [String:AnyObject]
            let supervisor = user["Supervisor"] as! String
            let realm = try! Realm()
            if getUserId(userID: Id) == -1 {
                saveUsers(realm: realm, userId: Id, userName: userName, workEmail: wEmail, personalEmail: pEmail, departmentId: 0, supervisor: supervisor, phoneNo: phone, orderNo: order, status: status)
            }
        }
    }
    
    func saveUsers(realm: Realm, userId: Int, userName: String?, workEmail: String?, personalEmail: String?, departmentId: Int, supervisor: String?, phoneNo: String?, orderNo: Int, status: String) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_Users.self)
        
        let newUser = md_Users(userId: userId, userName: userName, workEmail: workEmail, personalEmail: personalEmail, departmentId: departmentId, supervisor: supervisor, phoneNo: phoneNo, orderNo: orderNo, status: status)
        RealmService.shared.create(newUser)
    }
    
    class func getAllUserNames(locationID: Int) -> Results<md_Users>? {
//        locationID = 132
        let realm = try! Realm()
        let usersForLocation = md_UserLocation.getUserLocationId(userLocID: locationID)
        let userIDs = NSMutableArray()
        if usersForLocation.count == 0 {
            return nil
        }
        for i in 0 ... usersForLocation.count - 1 {
            userIDs.add(usersForLocation[i].userId)
        }
        let users = realm.objects(md_Users.self).filter("userId IN %@",userIDs)
        return users

    }
    
    func getUserId(userID: Int) -> Int {
        let realm = try! Realm()
        let filteredUser = realm.objects(md_Users.self).filter("userId == %@", userID)
        if filteredUser.count == 0 {
            return -1
        }
        let id = filteredUser[0].userId
        return id
    }

    
}





















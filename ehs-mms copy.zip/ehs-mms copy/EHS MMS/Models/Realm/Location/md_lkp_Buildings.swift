//
//  md_lkp_Buildings.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/15/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

@objcMembers class md_lkp_Buildings: Object {
    
    @objc dynamic var buildingId : Int = 0
    @objc dynamic var buildingName : String? = ""
    @objc dynamic var descriptionBuilding : String? = ""  // allows null
    @objc dynamic var orderNo : Int = 0
    @objc dynamic var regionId : Int = 0
    @objc dynamic var status : String = ""
    
    convenience init (buildingId: Int, buildingName: String?, descriptionBuilding: String?, orderNo: Int, regionId: Int, status: String) {
        self.init()
        self.buildingId = buildingId
        self.buildingName = buildingName
        self.descriptionBuilding = descriptionBuilding
        self.orderNo = orderNo
        self.regionId = regionId
        self.status = status
    }
    
    
    func saveBuildingsMDATA (data:[String:AnyObject]) {
        let arrBuildings = data["results"] as! [AnyObject]
        for building in arrBuildings {
            let id = building["ID"] as! Int
            let name = building["BuildingName"] as! String
            let desc = building["Description"] as! String
            let order = building["OrderNo"] as! Int
            let region = building["RegionId"] as! Int
            let status = building["Status"] as! String
            var realm = try! Realm()
            md_lkp_Buildings().saveBuildings(realm: realm, buildingId: id, buildingName: name, descriptionBuilding: desc, orderNo: order, regionId: region, status: status)
        }
    }
    
    // override static func primaryKey() -> String? {
    // return "buildingId"
    // }
    
    /*
     func autoIncrementId () -> Int {
     let realm = try! Realm()
     return (realm.objects(md_lkp_Buildings).max(ofProperty: "orderNo") as Int? ?? 0) + 1
     }
     */
    
    func saveBuildings(realm: Realm, buildingId: Int, buildingName: String?, descriptionBuilding: String?, orderNo: Int, regionId: Int, status: String) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_lkp_Buildings.self)
        if getBuilding(buildingId: buildingId) != -1 {
            return
        }
        let newBuilding = md_lkp_Buildings(buildingId: buildingId, buildingName: buildingName, descriptionBuilding: descriptionBuilding, orderNo: orderNo, regionId: regionId, status: status)
        RealmService.shared.create(newBuilding)
    }
    
    func getBuilding(buildingId: Int) -> Int {
        let realm = try! Realm()
        let filteredBuilding = realm.objects(md_lkp_Buildings.self).filter("buildingId == %@", buildingId)
        
        if filteredBuilding.count == 0 {
            return -1
        }
        else {
            return 0
        }
    }
    
    func getBuildingId(buildingName: String) -> Int {
        let realm = try! Realm()
        let filteredBuilding = realm.objects(md_lkp_Buildings.self).filter("buildingName == %@", buildingName)
        //print(filteredBuilding)
        if filteredBuilding.count == 0 {
            return -1
        }
        let id = filteredBuilding[0].buildingId
        return id
    }

    
}

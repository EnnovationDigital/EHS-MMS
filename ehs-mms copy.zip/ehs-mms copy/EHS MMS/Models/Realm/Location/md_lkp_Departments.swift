//
//  md_lkp_Departments.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/15/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

@objcMembers class md_lkp_Departments: Object {
    
    @objc dynamic var departmentId: Int = 0
    @objc dynamic var department : String? = ""
    @objc dynamic var status : String = ""
        
    convenience init (departmentId: Int, department: String?, status: String) {
        self.init()
        self.departmentId = departmentId
        self.department = department
        self.status = status
    }
    
    func saveDepartmentsMData(data:[String:AnyObject]) {
        print(data)
        let arrDeps = data["results"] as! [AnyObject]
        for dep in arrDeps {
            let id = dep["ID"] as! Int
            let name = dep["Department"] as! String
            let status = dep["Status"] as! String
            var realm = try! Realm()
            if getDepartmentId(name: name) == -1 {
                saveDepartments(realm: realm, departmentId: id, department: name, status: status)
            }
        }
    }
    
    //    override static func primaryKey() -> String? {
    //        return "departmentId"
    //    }
    
    /*
     func autoIncrementId () -> Int {
     let realm = try! Realm()
     return (realm.objects(md_lkp_Departments).max(ofProperty: "orderNo") as Int? ?? 0) + 1
     }
     */
    
    func saveDepartments (realm: Realm, departmentId: Int, department: String?, status: String) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_lkp_Departments.self)
        
        let newDepartment = md_lkp_Departments(departmentId: departmentId, department: department, status: status)
        RealmService.shared.create(newDepartment)
    }
    func getDepartmentId(name: String) -> Int {
        let realm = try! Realm()
        let filteredDeps = realm.objects(md_lkp_Departments.self).filter("department == %@", name)
        if filteredDeps.count > 0 {
            let id = filteredDeps[0].departmentId
            return id
        }
        else {
            return -1
        }
        
    }

    
}


























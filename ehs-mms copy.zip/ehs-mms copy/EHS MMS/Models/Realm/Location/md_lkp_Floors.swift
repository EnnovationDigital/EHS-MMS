//
//  md_lkp_Floors.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/15/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

@objcMembers class md_lkp_Floors: Object {
    
    @objc dynamic var floorId : Int = 0
    @objc dynamic var floorName : String? = ""
    @objc dynamic var descriptionFloor : String? = ""
    @objc dynamic var orderNo : Int = 0
    @objc dynamic var buildingId : Int = 0
    @objc dynamic var regionId : Int = 0
    @objc dynamic var status : String = ""
    
    convenience init (floorId: Int, floorName: String?, descriptionFloor: String?, orderNo: Int, buildingId: Int, regionId: Int, status: String) {
        self.init()
        self.floorId = floorId
        self.floorName = floorName
        self.descriptionFloor = descriptionFloor
        self.orderNo = orderNo
        self.buildingId = buildingId
        self.regionId = regionId
        self.status = status
    }
    
    func saveFloorsMDATA (data:[String:AnyObject]) {
        let arrFloors = data["results"] as! [AnyObject]
        for floor in arrFloors {
            let id = floor["ID"] as! Int
            let name = floor["FloorName"] as! String
//            let desc = floor["Description"] as! String
            let order = floor["OrderNo"] as! Int
            let region = floor["RegionId"] as! Int
            let building = floor["BuildingId"] as! Int
            let status = floor["Status"] as! String
            var realm = try! Realm()
            if getFloorId(floorName: name) == -1 {
                saveFloors(realm: realm, floorId: id, floorName: name, descriptionFloor: "empty", orderNo: order, buildingId: building, regionId: region, status: status)
            }
        }
    }
    
    //    override static func primaryKey() -> String? {
    //        return "floorId"
    //    }
    
    func autoIncrementId() -> Int {
        let realm = try! Realm()
        return (realm.objects(md_lkp_Floors.self).max(ofProperty: "regionId") as Int? ?? 0) + 1
    }
    
    func saveFloors(realm: Realm, floorId: Int, floorName: String?, descriptionFloor: String?, orderNo: Int, buildingId: Int, regionId: Int, status: String) {
        _ = RealmService.shared.realm
        var floors = realm.objects(md_lkp_Floors.self)
        
        let newFloor = md_lkp_Floors(floorId: floorId, floorName: floorName, descriptionFloor: descriptionFloor, orderNo: orderNo, buildingId: buildingId, regionId: regionId, status: status)
        RealmService.shared.create(newFloor)
    }
    
    func getFloor(floorId: Int) -> Int {
        let realm = try! Realm()
        let filteredFloor = realm.objects(md_lkp_Floors.self).filter("floorId == %@", floorId)
        if filteredFloor.count == 0 {
            return -1
        }
        else {
            return 0
        }
    }
    
    func getFloorId(floorName: String) -> Int {
        let realm = try! Realm()
        let filteredFloor = realm.objects(md_lkp_Floors.self).filter("floorName == %@", floorName)
        if filteredFloor.count == 0 {
            return -1
        }
        let id = filteredFloor[0].floorId
        return id
    }

}


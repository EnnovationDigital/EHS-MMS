//
//  md_lkp_LocationType.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/15/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

@objcMembers class md_lkp_LocationType: Object {
    @objc dynamic var locationTypeId : Int = 0
    @objc dynamic var locationType : String? = ""                // allows null
    @objc dynamic var descriptionLocationType : String? = ""     // allows null
    @objc dynamic var orderNo : Int = 0
    @objc dynamic var status : String = ""
    
    convenience init (locationTypeId: Int, locationType: String?, descriptionLocationType: String?, orderNo: Int, status: String) {
        self.init()
        self.locationTypeId = locationTypeId
        self.locationType = locationType
        self.descriptionLocationType = descriptionLocationType
        self.locationTypeId = locationTypeId
        self.orderNo = orderNo
        self.status = status
    }
    
    
    func saveLocationTypesMData(data:[String:AnyObject]) {
        print(data)
        let arrTypes = data["results"] as! [AnyObject]
        for type in arrTypes {
            let id = type["ID"] as! Int
            let name = type["LocationType"] as! String
            let desc = type["Description"] as! String
            let order = type["OrderNo"] as! Int
            let status = type["Status"] as! String
            let realm = try! Realm()
            if getLoactionTypeId(locationTypeId: id) == -1 {
                saveLocationTypes(realm: realm, locationTypeId: id, locationType: name, descriptionLocationType: desc, orderNo: order, status: status)
            }
        }
    }
    
    //    override static func primaryKey() -> String? {
    //        return "locationTypeId"
    //    }
    
    /*
     func autoIncrementId () -> Int {
     let realm = try! Realm()
     return (realm.objects(md_lkp_LocationType).max(ofProperty: "orderNo") as Int? ?? 0) + 1
     }
     */
    
    func saveLocationTypes(realm: Realm, locationTypeId: Int, locationType: String?, descriptionLocationType: String?, orderNo: Int, status: String) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_lkp_LocationType.self)
        
        let newLocationType = md_lkp_LocationType(locationTypeId: locationTypeId, locationType: locationType, descriptionLocationType: descriptionLocationType, orderNo: orderNo, status: status)
        RealmService.shared.create(newLocationType)
    }
    
    func getLoactionTypeName(locationTypeName: String) -> Int {
        let realm = try! Realm()
        let filteredLocationType = realm.objects(md_lkp_LocationType.self).filter("locationType == %@", locationTypeName)
        if filteredLocationType.count == 0 {
            return -1
        }
        let id = filteredLocationType[0].locationTypeId
        return id
    }
    
    func getLoactionTypeId(locationTypeId: Int) -> Int {
        let realm = try! Realm()
        let filteredLocationType = realm.objects(md_lkp_LocationType.self).filter("locationTypeId == %@", locationTypeId)
        if filteredLocationType.count == 0 {
            return -1
        }
        let id = filteredLocationType[0].locationTypeId
        return id
    }

    
}


//
//  md_lkp_Locations.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/15/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

@objcMembers class md_lkp_Locations: Object {
    
    @objc dynamic var locationId : Int = 0
    @objc dynamic var locationName : String? = ""           // allows null
    @objc dynamic var descriptionLocation : String? = ""    // allows null
    @objc dynamic var locationTypeId : Int = 0
    @objc dynamic var orderNo : Int = 0
    @objc dynamic var floorId : Int = 0
    @objc dynamic var buildingId : Int = 0
    @objc dynamic var regionId : Int = 0
    @objc dynamic var telephoneNo : String? = ""         // allows null
    @objc dynamic var status : String = ""
    
    convenience init (locationId: Int, locationName: String?, descriptionLocation: String?, locationTypeId: Int, orderNo: Int, floorId: Int, buildingId: Int, regionId: Int, telephoneNo: String?, status: String) {
        self.init()
        self.locationId = locationId
        self.locationName = locationName
        self.descriptionLocation = descriptionLocation
        self.locationTypeId = locationTypeId
        self.orderNo = orderNo
        self.floorId = floorId
        self.buildingId = buildingId
        self.regionId = regionId
        self.telephoneNo = telephoneNo
        self.status = status
    }
    
    func saveLocationsMDATA (data:[String:AnyObject]) {
        let arrLocations = data["results"] as! [AnyObject]
        for location in arrLocations {
            let id = location["ID"] as! Int
            let name = location["LocationName"] as! String
            let desc = location["Description"] as! String
            let order = location["OrderNo"] as! Int
            let region = location["RegionId"] as! Int
            let building = location["BuildingId"] as! Int
            let floor = location["FloorId"] as! Int
            let locationType = location["LocationTypeId"] as! Int
            let status = location["Status"] as! String
            
            var realm = try! Realm()
            saveLocations(realm: realm, locationId: id, locationName: name, descriptionLocation: desc, locationTypeId: locationType, orderNo: order, floorId: floor, buildingId: building, regionId: region, telephoneNo: "empty", status: status)
        }
    }
    
    func saveLocations (realm: Realm, locationId: Int, locationName: String?, descriptionLocation: String?, locationTypeId: Int, orderNo: Int, floorId: Int, buildingId: Int, regionId: Int, telephoneNo: String?, status: String) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_lkp_Locations.self)
        if getLocation(locationId: locationId) == -1 {
            let newLocation =  md_lkp_Locations(locationId: locationId, locationName: locationName, descriptionLocation: descriptionLocation, locationTypeId: locationTypeId, orderNo: orderNo, floorId: floorId, buildingId: buildingId, regionId: regionId, telephoneNo: telephoneNo, status: status)
            RealmService.shared.create(newLocation)
        }
    }
    
    func getLocation(locationId: Int) -> Int {
        let realm = try! Realm()
        let filteredLocation = realm.objects(md_lkp_Locations.self).filter("locationId == %@", locationId)
        if filteredLocation.count == 0 {
            return -1
        }
        else {
            return 0
        }
    }
    
    func getLocation(locationName: String) -> md_lkp_Locations? {
        let realm = try! Realm()
        let filteredLocation = realm.objects(md_lkp_Locations.self).filter("locationName == %@", locationName)
        if filteredLocation.count == 0 {
            return nil
        }
        else {
            return filteredLocation[0]
        }
    }
    
    func getLocationId(locationName: String) -> Int {
        let realm = try! Realm()
        let filteredLocation = realm.objects(md_lkp_Locations.self).filter("locationName == %@", locationName)
        if filteredLocation.count == 0 {
            return -1
        }
        let id = filteredLocation[0].locationId
        return id
    }

    
    
}

//
//  md_lkp_Region.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/15/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

@objcMembers class md_lkp_Region: Object {
    
    //simple numbers change to long -Int16
    @objc dynamic var regionId : Int = 0
    @objc dynamic var regionName : String? = ""         // allows null
    @objc dynamic var descriptionRegion : String? = ""  // allows null
    @objc dynamic var orderNo : Int = 0
    @objc dynamic var status : String = ""

    convenience init (regionId: Int, regionName: String?, descriptionRegion: String?, orderNo: Int, status: String?) {
        self.init()
        self.regionId = regionId
        self.regionName = regionName
        self.descriptionRegion = descriptionRegion
        self.orderNo = orderNo
    }
    
    
    func saveRegtionsMData(data:[String:AnyObject]) {
        print(data)
        let arrRegions = data["results"] as! [AnyObject]
        for region in arrRegions {
            let regionID = region["ID"] as! Int
            let name = region["RegionName"] as! String
            let desc = region["Description"] as! String
            let order = region["OrderNo"] as! Int
            let status = region["Status"] as! String
            var realm = try! Realm()
            self.saveRegions(realm: realm, regionId: regionID, regionName: name, descriptionRegion: desc, orderNo: order, status: status)
        }
    }
    
    
    //    override static func primaryKey() -> String? {
    //        return "regionId"
    //    }
    
    /*
    func autoIncrementId () -> Int {
        let realm = try! Realm()
        return (realm.objects(md_lkp_Region.self).max(ofProperty: "orderNo") as Int? ?? 0) + 1
    }
     */

    func saveRegions(realm: Realm, regionId: Int, regionName: String?, descriptionRegion: String?, orderNo: Int, status: String?) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_lkp_Region.self)
        
        if getRegion(regionId: regionId) == -1 {
            let newRegion = md_lkp_Region(regionId: regionId, regionName: regionName, descriptionRegion: descriptionRegion, orderNo: orderNo, status: status)
            RealmService.shared.create(newRegion)
        }
    }
    
    func getRegion(regionId: Int) -> Int {
        let realm = try! Realm()
        let filteredRegions = realm.objects(md_lkp_Region.self).filter("regionId == %@", regionId)
        if filteredRegions.count > 0 {
            return 0
        }
        else {
            return -1
        }
        
    }
    
    func getRegionId(regionName: String) -> Int {
            let realm = try! Realm()
            let filteredRegions = realm.objects(md_lkp_Region.self).filter("regionName == %@", regionName)
            //print(filteredRegions)
        if filteredRegions.count > 0 {
            let id = filteredRegions[0].regionId
            return id
        }
        else {
            return -1
        }
        
    }

    
}

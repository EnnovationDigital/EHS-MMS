//
//  EHSQuestion.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 12/11/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//


import Foundation
import RealmSwift

class EHSQuestion: Object {
    @objc dynamic var id : Int = 0
    @objc dynamic var questionId : Int = 0
    @objc dynamic var questionItemId : Int = 0
    @objc dynamic var question : String = ""
    @objc dynamic var index : Int = 0
    @objc dynamic var orderNo : Int = 0
    
    @objc dynamic var categoryId : Int = 0
    @objc dynamic var subCategoryId : Int = 0
    
    @objc dynamic var isReaptable : Bool = false
    @objc dynamic var noOfRepeats : Int = 0
    @objc dynamic var defaultAnswer : String = ""
    
    @objc dynamic var parentQuestionId : Int = 0
    @objc dynamic var hasSubQuestion : Bool = false
    @objc dynamic var isSubQuestion : Bool = false
    @objc dynamic var decisionAnswer : String = ""
    
    @objc dynamic var inspectionTypeId : Int = 0
    @objc dynamic var inspectionId : String = ""
    @objc dynamic var inspectionItemId : Int = 0
    
    @objc dynamic var status : String? = ""
    @objc dynamic var answerTypeId : Int = 0
    
    @objc dynamic var answerIds : String? = ""
    @objc dynamic var textAnswer : String? = ""
    @objc dynamic var comment : String? = ""
    
    @objc dynamic var repeatIds : String? = ""
    
    @objc dynamic var assignedToEHS : Bool = false
    @objc dynamic var assignedUsers : String = ""
    
    func saveQuestionObject (question: md_Questions, answers: Results<md_AnswersToQuestions>, repeats:Int, inspectionId : String, status : String, repeatId: String, assignedToId: String, index: Int) {
        
        _ = RealmService.shared.realm
        _ = realm?.objects(EHSQuestion.self)
        let newQuestion = EHSQuestion(question: question, answers: answers, repeats: repeats, inspectionId: inspectionId, status: status, repeatId: repeatId, assignedToId: assignedToId, index: index)
        RealmService.shared.create(newQuestion)
        
    }
    
    convenience init (question: md_Questions, answers: Results<md_AnswersToQuestions>, repeats:Int, inspectionId : String, status : String, repeatId: String, assignedToId: String, index: Int) {
        
        self.init()
        
        self.id  = self.autoIncrementId()
        self.index = index
        self.questionId = question.questionId
        self.orderNo = question.orderNo
        self.question = question.question!
        
        self.categoryId = question.categoryId
        self.subCategoryId = question.subCategoryId
        
        self.parentQuestionId = question.parentQuestionId
        if self.parentQuestionId != -1 {
            self.isSubQuestion = true
        }
        for answer in answers {
            if answer.isDecisionAnswer == true {
                self.hasSubQuestion = true
                self.decisionAnswer = String(format: "%ld", answer.answerId)
                break
            }
        }
        if question.isReaptable == true {
            self.isReaptable = question.isReaptable
            self.noOfRepeats = repeats
            
            self.repeatIds = repeatId
            
            self.assignedUsers = assignedToId
            
            for answer in answers {
                if answer.isDefaultAnswer == true {
                    self.defaultAnswer = answer.answer!
                    self.answerIds = String(format: "%ld", answer.answerId)
                    break
                }
            }
        }
        self.inspectionId = inspectionId
        self.inspectionTypeId = question.inspectionTypeId
        self.status = status // NA - not answered, A - Answered
        self.answerTypeId = question.answerTypeId
        
    }
    
    func autoIncrementId() -> Int {
        let realm = try! Realm()
        return (realm.objects(EHSQuestion.self).max(ofProperty: "id") as Int? ?? 0) + 1
    }
    
    class func getQuestionForInspection(iTypeID: Int, categoryID: Int, subCategoryID: Int, inspectionID: String) -> Results<EHSQuestion> {
        let realm = try! Realm()
        return realm.objects(EHSQuestion.self).filter("inspectionTypeId == %@ && categoryId == %@ && subCategoryId == %@ && inspectionId == %@", iTypeID, categoryID, subCategoryID, inspectionID).sorted( by: [SortDescriptor(keyPath: "questionId", ascending: true), SortDescriptor(keyPath: "orderNo", ascending: true)] )
    }
    
    class func getQuestionForOldInspection(inspectionID: String) -> Results<EHSQuestion> {
        let realm = try! Realm()
        return realm.objects(EHSQuestion.self).filter("inspectionId == %@", inspectionID).sorted( by: [SortDescriptor(keyPath: "questionId", ascending: true), SortDescriptor(keyPath: "orderNo", ascending: true)] )
    }
    
    class func getQuestionFromId(questionId: Int, inspectionId: String, repeatId: String) -> EHSQuestion? {
        let realm = try! Realm()
        let filteredQuestion = realm.objects(EHSQuestion.self).filter("questionId == %@ && inspectionId == %@ && repeatIds == %@", questionId,inspectionId,repeatId)
        if filteredQuestion.count > 0 {
            return filteredQuestion[0]
        }
        else {
            return nil
        }
    }
    
    class func getQuestions(questionId: Int, inspectionId: String) -> Results<EHSQuestion>? {
        let realm = try! Realm()
        let filteredQuestion = realm.objects(EHSQuestion.self).filter("questionId == %@ && inspectionId == %@ ", questionId,inspectionId)
        if filteredQuestion.count > 0 {
            return filteredQuestion
        }
        else {
            return nil
        }
    }
    
    
    class func getQuestionForUser(userId: String, inspectionId: String) -> EHSQuestion? {
        let realm = try! Realm()
        let filteredQuestion = realm.objects(EHSQuestion.self).filter("assignedUsers == %@ && inspectionId == %@ ",  userId, inspectionId)
        if filteredQuestion.count > 0 {
            return filteredQuestion[0]
        }
        else {
            return nil
        }
    }
}





















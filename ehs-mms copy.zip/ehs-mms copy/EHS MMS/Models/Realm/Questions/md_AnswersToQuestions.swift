//
//  md_AnswersToQuestions.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class md_AnswersToQuestions: Object {
    
    @objc dynamic var answerId : Int = 0
    @objc dynamic var questionId : Int = 0              // allows null
    @objc dynamic var regulationId : Int = 0
    @objc dynamic var answer : String? = ""             // allows null
    @objc dynamic var orderNo : Int = 0                 // allows null
    @objc dynamic var isDecisionAnswer : Bool = false   // allows null
    @objc dynamic var isDefaultAnswer : Bool = false    // allows null
    @objc dynamic var defaultAnswer : String? = ""      // allows null
    @objc dynamic var status : String? = ""             //
    @objc dynamic var triggersEmail : Bool = false   // allows null
    @objc dynamic var inspectionId : Int = 0        // can not be nil
    @objc dynamic var serverId : Int = 0     // add in every table 0 sync with server Id
    @objc dynamic var categoryId : Int = 0
    @objc dynamic var subCategoryId : Int = 0
    @objc dynamic var inspectionTypeId : Int = 0
    
    convenience init (answerId: Int, questionId:
        Int, answer: String?, orderNo: Int, isDecisionAnswer: Bool, isDefaultAnswer: Bool, defaultAnswer: String, regulationId: Int, status: String, triggersEmail: Bool, inspectionId: Int, categoryId: Int, subcategoryId: Int, inspectionTypeId: Int) {
        self.init()
        self.answerId = answerId
        self.questionId = questionId
        self.answer = answer
        self.orderNo = orderNo
        self.isDecisionAnswer = isDecisionAnswer
        self.isDefaultAnswer = isDefaultAnswer
        self.regulationId = regulationId
        self.status = status
        self.triggersEmail = triggersEmail
        self.inspectionId = inspectionId
        self.categoryId = categoryId
        self.subCategoryId = subcategoryId
        self.inspectionId = inspectionId
        
    }
    
    /*
     {
     "__metadata": {
     "id": "555a5c1f-30f4-4ccc-82ce-657258762ba4",
     "uri": "https://incytetest.sharepoint.com/sites/EHSMMS/_api/Web/Lists(guid'ccfdad08-9b74-428b-94fb-2d709c64331f')/Items(1)",
     "etag": "\"5\"",
     "type": "SP.Data.Md_x005f_AnswersToQuestionsListItem"
     },
     "Answer": "Yes",
     "OrderNo": 1,
     "IsDecesionAnswer": true,
     "IsDefaultAnswer": true,
     "DefaultValue": null,
     "QuestionId": 8,
     "RegulationId": null,
     "Status": "Active",
     "TriggersEmail": "false",
     "InspectionTypeId": 1,
     "CategoryId": 21,
     "SubCategoryId": 7
     },
 */
    
    func saveAnswersData(data:[String:AnyObject]) {
        
        print(data)
        let realm = try! Realm()
        let arrAnswers = data["results"] as! [AnyObject]
        for answer in arrAnswers {
            
            let aID = answer["ID"]// Constants.fetchIDFromMetaData(data: answer)
            
            let strAnswer = answer["Answer"] as! String
            let orderNo = answer["OrderNo"] as! Int
            let isDecisionAnswer = answer["IsDecesionAnswer"] as! Bool
            let isDefaultAnswer = answer["IsDefaultAnswer"] as! Bool
            let defaultValue = "empty"
            let qID = Int(answer["QuestionId"] as! String)
            let status = answer["Status"] as! String
            let inspectionTypeID = Int(answer["InspectionTypeId"] as! String)
            let categoryID = Int(answer["CategoryId"] as! String)
            var subCategoryID = -1
            if (answer["SubCategoryId"] as? NSNull) == nil {
                subCategoryID = Int(answer["SubCategoryId"] as! String)!
            }
            
            saveAnswerToQuestion(realm: realm, answerId: aID as! Int, questionId: qID!, answer: strAnswer, orderNo: orderNo, isDecisionAnswer: isDecisionAnswer, isDefaultAnswer: isDefaultAnswer, defaultAnswer: defaultValue, regulationId: -1, status: status, triggersEmail: false, inspectionId: 0, categoryId: categoryID!, subcategoryId: subCategoryID, inspectionTypeId: inspectionTypeID!)
            
        }
    }
    
    
    /*
     func autoIncrementId() -> Int {s
     let realm = try! Realm()
     return (realm.objects(md_AnswersToQuestions.self).max(ofProperty: "orderNo") as Int? ?? 0) + 1
     }
     */
    
    func saveAnswerToQuestion(realm: Realm, answerId: Int, questionId: Int, answer: String?, orderNo: Int, isDecisionAnswer: Bool, isDefaultAnswer: Bool, defaultAnswer: String, regulationId: Int, status: String, triggersEmail: Bool, inspectionId: Int, categoryId: Int, subcategoryId: Int, inspectionTypeId: Int) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_AnswersToQuestions.self)
        
        let newAnswerToQuestion = md_AnswersToQuestions(answerId: answerId,
                                                        questionId: questionId,
                                                        answer: answer,
                                                        orderNo: orderNo,
                                                        isDecisionAnswer: isDecisionAnswer,
                                                        isDefaultAnswer: isDefaultAnswer,
                                                        defaultAnswer: defaultAnswer,
                                                        regulationId: regulationId,
                                                        status: status,
                                                        triggersEmail: triggersEmail,
                                                        inspectionId: inspectionId,
                                                        categoryId : categoryId,
                                                        subcategoryId: subcategoryId,
                                                        inspectionTypeId: inspectionTypeId)
        
        RealmService.shared.create(newAnswerToQuestion)
    }
    
   class func getAnswers(questionId: Int) -> Results<md_AnswersToQuestions> {
        let realm = try! Realm()
        let filteredAnswers: Results<md_AnswersToQuestions> = realm.objects(md_AnswersToQuestions.self).filter("questionId == %@", questionId).sorted(byKeyPath: "orderNo", ascending: true)
        return filteredAnswers
    }

    class func fetchAnswers(answerId: Int) -> md_AnswersToQuestions? {
        let realm = try! Realm()
        let filteredAnswers: Results<md_AnswersToQuestions> = realm.objects(md_AnswersToQuestions.self).filter("answerId == %@", answerId)
        if filteredAnswers.count > 0 {
            return filteredAnswers[0]
        }
        else {
            return nil
        }
    }
    

}

//
//  md_Questions.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class md_Questions: Object {
    
    @objc dynamic var questionId : Int = 0
    @objc dynamic var question : String? = ""           // allows nil
    @objc dynamic var categoryId : Int = 0
    @objc dynamic var subCategoryId : Int = 0
    @objc dynamic var isReaptable : Bool = false
    @objc dynamic var orderNo : Int = 0
    @objc dynamic var descriptionOfRepeatability : String? = ""     // allows nil
    @objc dynamic var noOfRepeats : Int = 0
    @objc dynamic var parentQuestionId : Int = 0
    @objc dynamic var inspectionTypeId : Int = 0
    @objc dynamic var status : String? = ""
    @objc dynamic var answerTypeId : Int = 0
    @objc dynamic var answerId : Int = 0
    @objc dynamic var inspectionId : Int = 0
    @objc dynamic var questionItemId : Int = 0
    
    convenience init (questionId: Int, question: String?, categoryId: Int, subCategoryId: Int, isReaptable: Bool, orderNo: Int, descriptionOfRepeatability: String?, noOfRepeats: Int, parentQuestionId: Int, inspectionTypeId: Int, status: String, answerTypeId: Int, answerId:Int , inspectionId:Int, questionItemId: Int) {
        self.init()
        self.questionId = questionId
        self.question = question
        self.categoryId = categoryId
        self.subCategoryId = subCategoryId
        self.isReaptable = isReaptable
        self.orderNo = orderNo
        self.descriptionOfRepeatability = descriptionOfRepeatability
        self.noOfRepeats = noOfRepeats
        self.parentQuestionId = parentQuestionId
        self.inspectionTypeId = inspectionTypeId
        self.status = status
        self.answerTypeId = answerTypeId
        self.answerId = answerId
        self.inspectionId = inspectionId
        self.questionItemId = questionItemId
    }
    
    func saveQuestionsData(data:[String:AnyObject]) {
     
        print(data)
        let arrQuestions = data["results"] as! [AnyObject]
        for question in arrQuestions {
            print(question)
            let qID =  question["ID"] as! Int //Constants.fetchIDFromMetaData(data: question)
            if qID == 1414 {
                print("ikarma")
            }
            let q = question["Question"] as! String
            let categoryId = Int(question["CategoryId"] as! String)
            let subCategoryId = fetchParentID(data: question, key: "SubCategoryId")
            let isReaptable = question["IsRepeatable"] as! Bool
            var numberOfRepeats = 0
            if isReaptable == true {
                numberOfRepeats = fetchParentID(data: question,key: "NoOfRepeats")
            }
            let orderNo = question["OrderNo"] as! Int
            let descriptionOfRepeatability = "empty"
            let parentQuestionId = fetchParentID(data: question,key:"ParentQuestionId")
            
            
            let inspectionTypeId = Int(question["InspectionTypeId"] as! String)
            let status = question["Status"] as! String
            var answerTypeId = -1
            if (question["AnswerTypeId"] as? NSNull) == nil {
                answerTypeId = Int(question["AnswerTypeId"] as! String)!
            }
            let inspectionId = 0
            
            let realm = try! Realm()
            saveQuestions(realm: realm, questionId: qID, question: q, categoryId: categoryId!, subCategoryId : subCategoryId, isReaptable: isReaptable, orderNo: orderNo, descriptionOfRepeatability: descriptionOfRepeatability, noOfRepeats: numberOfRepeats, parentQuestionId: parentQuestionId, inspectionTypeId: inspectionTypeId!, status: status, answerTypeId: answerTypeId, answerId: answerId, inspectionId: inspectionId, questionItemId: 0)
        }
    }
    
    
    func fetchParentID(data:AnyObject, key: String) -> Int {
        if (data[key] as? NSNull) != nil {
            return -1
        }
        if let id = data[key] as? Int  {
            return id
        }
        else if let id = data[key] as? String  {
            return Int(id)!
        }
        
        return -1
    }
    
    //    override static func primaryKey() -> String? {
    //        return "regionId"
    //    }
    
    /*
     func autoIncrementId() -> Int {
     let realm = try! Realm()
     return (realm.objects(md_Questions.self).max(ofProperty: "orderNo") as Int? ?? 0) + 1
     }
     */
    
    func saveQuestions(realm: Realm, questionId: Int, question: String?, categoryId: Int, subCategoryId: Int, isReaptable: Bool, orderNo: Int, descriptionOfRepeatability: String?, noOfRepeats: Int, parentQuestionId: Int, inspectionTypeId: Int, status: String, answerTypeId: Int,answerId:Int , inspectionId:Int, questionItemId: Int) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_Questions.self)
        
        let newQuestion = md_Questions(questionId: questionId,
                                       question: question,
                                       categoryId: categoryId,
                                       subCategoryId: subCategoryId,
                                       isReaptable: isReaptable,
                                       orderNo: orderNo,
                                       descriptionOfRepeatability: descriptionOfRepeatability,
                                       noOfRepeats: noOfRepeats,
                                       parentQuestionId: parentQuestionId,
                                       inspectionTypeId: inspectionTypeId,
                                       status: status,
                                       answerTypeId: answerTypeId,
                                       answerId:answerId,
                                       inspectionId: inspectionId,
                                       questionItemId: 0)
        
        RealmService.shared.create(newQuestion)
    }
    
    class func getQuestionForInspection(iTypeID: Int, categoryID: Int, subCategoryID: Int) -> Results<md_Questions> {
        let realm = try! Realm()
        return realm.objects(md_Questions.self).filter("inspectionTypeId == %@ && categoryId == %@ && subCategoryId == %@", iTypeID, categoryID, subCategoryID).sorted( by: [SortDescriptor(keyPath: "questionId", ascending: true), SortDescriptor(keyPath: "orderNo", ascending: true)] )
        
    }
    
   class func getQuestionFromId(questionId: Int) -> md_Questions? {
        let realm = try! Realm()
        let filteredQuestion = realm.objects(md_Questions.self).filter("questionId == %@", questionId)
        if filteredQuestion.count > 0 {
            return filteredQuestion[0]
        }
        else {
            return nil
        }
    }
}





















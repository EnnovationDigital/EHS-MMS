//
//  md_answered_questions.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 8/7/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class md_answered_questions  : Object {
    
    @objc dynamic var id : Int = 0
    @objc dynamic var questionId : Int = 0
    @objc dynamic var inspectionId : Int = 0
    @objc dynamic var answers : String = ""
    @objc dynamic var  createdBy : String? = ""      // allows nil
    @objc dynamic var  createdDate : String? = ""    // allows nil
    @objc dynamic var  modifiedDate : String? = ""  // allows nil
    @objc dynamic var  modifiedBy : String? = ""    // allows nil
    @objc dynamic var isSubmitted : Bool = false
    @objc dynamic var userIDs: String = ""
    
    convenience init(questionId:Int, inspectionId:Int, answers:String, createdBy:String, createdDate:String, modifiedDate:String, modifiedBy:String, isSubmitted:Bool, userIDs:String) {
        
        self.init()
        self.id = self.autoIncrementId()
        self.questionId = questionId
        self.inspectionId = inspectionId
        self.answers = answers
        self.createdBy = createdBy
        self.createdDate = createdDate
        self.modifiedDate = modifiedDate
        self.modifiedBy = modifiedBy
        self.isSubmitted = isSubmitted
        self.userIDs = userIDs
    }
    
    func autoIncrementId () -> Int {
        let realm = try! Realm()
        return (realm.objects(md_answered_questions.self).max(ofProperty: "id") as Int? ?? 0) + 1
    }
    
    func saveAnswer(realm: Realm ,questionId:Int, inspectionId:Int,answers:String, createdBy:String, createdDate:String, modifiedDate:String, modifiedBy:String, isSubmitted:Bool, userIDs:String) {
        
        _ = RealmService.shared.realm
        _ = realm.objects(md_answered_questions.self)
        
        let newReport = md_answered_questions(questionId: questionId,
                                              inspectionId: inspectionId,
                                              answers: answers,
                                              createdBy: createdBy,
                                              createdDate: createdDate,
                                              modifiedDate: modifiedDate,
                                              modifiedBy: modifiedBy,
                                              isSubmitted:isSubmitted,
                                              userIDs:userIDs)
        
        RealmService.shared.create(newReport)
    }
    
    class func getReportFromId(reportId: Int) -> md_answered_questions? {
        let realm = try! Realm()
        let filteredQuestion = realm.objects(md_answered_questions.self).filter("id == %@", reportId)
        if filteredQuestion.count > 0 {
            return filteredQuestion[0]
        }
        else {
            return nil
        }
    }
    
    class func fetchAnsweredQuestions (inspectionNo:Int, questionID: Int) -> md_answered_questions? {
        let realm = try! Realm()
        let filteredQuestion = realm.objects(md_answered_questions.self).filter("inspectionId == %@ && questionId == %@", inspectionNo,questionID)
        if filteredQuestion.count > 0 {
            return filteredQuestion[0]
        }
        else {
            return nil
        }
    }
    
    class func getReportsForStatus(status: Bool) -> [md_answered_questions] {
        let realm = try! Realm()
        return realm.objects(md_answered_questions.self).filter("isSubmitted == %@", status).toArray(ofType: md_answered_questions.self)
    }
    
    class func fetchNonSubmittedAnswers(inspectionID:Int) -> [md_answered_questions] {
        let realm = try! Realm()
        return realm.objects(md_answered_questions.self).filter("isSubmitted == %@ && inspectionId == %@", false,inspectionID).toArray(ofType: md_answered_questions.self)
    }
}

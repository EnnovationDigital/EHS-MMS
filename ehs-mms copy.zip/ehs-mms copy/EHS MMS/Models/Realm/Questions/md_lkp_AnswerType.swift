//
//  md_lkp_AnswerType.swift
//  EHS MMS
//
//  Created by Macbook Pro on 6/28/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class md_lkp_AnswerType: Object {
    
    @objc dynamic var answerTypeId: Int = 0
    @objc dynamic var answerType: String? = ""  // allows null
    @objc dynamic var status: String? = ""
    
    convenience init (answerTypeId: Int, answerType: String?, status: String?) {
        self.init()
        self.answerTypeId = answerTypeId
        self.answerType = answerType
        self.status = status
    }
    
    func saveAnswerTypesData(data:[String:AnyObject]) {
        
        print(data)
        let arrTypes = data["results"] as! [AnyObject]
        for type in arrTypes {

            let tID = type["ID"] //Constants.fetchIDFromMetaData(data: type)
            let answerType = type["AnswerType"] as! String
            let status = type["Status"] as! String
            let realm = try! Realm()
            
            saveAnswerType(realm: realm, answerTypeId: tID as! Int, answerType: answerType, status: status)
        }
    }
    
    func saveAnswerType(realm: Realm, answerTypeId: Int, answerType: String?, status: String?) {
        _ = RealmService.shared.realm
        _ = realm.objects(md_lkp_AnswerType.self)
        
        let newAnswerType = md_lkp_AnswerType(answerTypeId: answerTypeId,
                                              answerType: answerType,
                                              status: status)
        RealmService.shared.create(newAnswerType)
    }
    
    class func getAnswerTypeFromId(id: Int) -> md_lkp_AnswerType? {
        let realm = try! Realm()
        let filteredTypes = realm.objects(md_lkp_AnswerType.self).filter("answerTypeId == %@", id)
        if filteredTypes.count > 0 {
            return filteredTypes[0]
        }
        else {
            return nil
        }
    }
    
}

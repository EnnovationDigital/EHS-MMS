//
//  md_lkp_IssuesType.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class md_lkp_IssuesType: Object {
    
    @objc dynamic var issueTypeId: Int = 0
    @objc dynamic var issueType: String? = ""            // allows null
    @objc dynamic var descriptionIssue: String? = ""    // allows null
    @objc dynamic var status: String? = ""
    
    convenience init (issueTypeId: Int, issueType: String?, descriptionIssue: String?, status: String?) {
        self.init()
        self.issueTypeId = issueTypeId
        self.issueType = issueType
        self.descriptionIssue = descriptionIssue
        self.status = status
    }

    /*
     func autoIncrementId() -> Int {
     let realm = try! Realm()
     return (realm.objects(md_lkp_IssuesType.self).max(ofProperty: "orderNo") as Int? ?? 0) + 1
     }
     */
    
    func saveQuestions(realm: Realm, issueTypeId: Int, issueType: String?, descriptionIssue: String?, status: String?) {
        _ = RealmService.shared.realm
        var issueType1 = realm.objects(md_lkp_IssuesType.self)
        
        let newIssueType = md_lkp_IssuesType(issueTypeId: issueTypeId,
                                             issueType: issueType,
                                             descriptionIssue: descriptionIssue,
                                             status: status)
        RealmService.shared.create(newIssueType)
    }
    
}


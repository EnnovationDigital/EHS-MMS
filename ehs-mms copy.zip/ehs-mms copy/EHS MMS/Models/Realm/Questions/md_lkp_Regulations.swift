//
//  md_lkp_Regulations.swift
//  EHS MMS
//
//  Created by Macbook Pro on 5/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation
import RealmSwift

class md_lkp_Regulations: Object {
    
    @objc dynamic var regulationId: Int = 0
    @objc dynamic var issueTypeId: Int = 0
    @objc dynamic var regulation: Int = 0
    @objc dynamic var possibleFineAmount: Int = 0
    @objc dynamic var orderNo: Int = 0
    @objc dynamic var priority: Int = 0
    @objc dynamic var status: String? = ""
    
    convenience init (regulationId: Int, issueTypeId: Int, regulation: Int, possibleFineAmount: Int, orderNo: Int, priority: Int, status: String?) {
        self.init()
        self.regulationId = regulationId
        self.issueTypeId = issueTypeId
        self.regulation = regulation
        self.possibleFineAmount = possibleFineAmount
        self.orderNo = orderNo
        self.priority = priority
        self.status = status
    }
    
    /*
     func autoIncrementId() -> Int {
     let realm = try! Realm()
     return (realm.objects(md_lkp_Regulations.self).max(ofProperty: "orderNo") as Int? ?? 0) + 1
     }
     */
    
    func saveQuestions(realm: Realm, regulationId: Int, issueTypeId: Int, regulation: Int, possibleFineAmount: Int, orderNo: Int, priority: Int, status: String?) {
        _ = RealmService.shared.realm
        var regulation1 = realm.objects(md_lkp_IssuesType.self)
        
        let newRegulation = md_lkp_Regulations(regulationId: regulationId,
                                              issueTypeId: issueTypeId,
                                              regulation: regulation,
                                              possibleFineAmount: possibleFineAmount,
                                              orderNo: orderNo,
                                              priority: priority,
                                              status: status)
        RealmService.shared.create(newRegulation)
    }

}

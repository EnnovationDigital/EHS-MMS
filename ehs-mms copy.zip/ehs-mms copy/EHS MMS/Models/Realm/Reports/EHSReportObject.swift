//
//  EHSReportObject.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 8/6/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import RealmSwift

class EHSReportObject: Object {

    @objc dynamic var reportId : Int = 0
    @objc dynamic var questionId : Int = 0
    @objc dynamic var inspectionId : Int = 0
    @objc dynamic var answerId : Int = 0
    @objc dynamic var  createdBy : String? = ""      // allows nil
    @objc dynamic var  createdDate : String? = ""    // allows nil
    @objc dynamic var  modifiedDate : String? = ""  // allows nil
    @objc dynamic var  modifiedBy : String? = ""    // allows nil
    @objc dynamic var isSubmitted : Bool = false
    
    convenience init(questionId:Int, inspectionId:Int,answerId:Int, createdBy:String, createdDate:String, modifiedDate:String,modifiedBy:String,isSubmitted:Bool) {
        
        self.init()
        self.reportId = self.autoIncrementId()
        self.questionId = questionId
        self.inspectionId = inspectionId
        self.answerId = answerId
        self.createdBy = createdBy
        self.createdDate = createdDate
        self.modifiedDate = modifiedDate
        self.modifiedBy = modifiedBy
        self.isSubmitted = isSubmitted
    }
 
    func autoIncrementId () -> Int {
        let realm = try! Realm()
        return (realm.objects(EHSReportObject.self).max(ofProperty: "reportId") as Int? ?? 0) + 1
    }
    
    class func saveInspection(realm: Realm ,questionId:Int, inspectionId:Int,answerId:Int, createdBy:String, createdDate:String, modifiedDate:String, modifiedBy:String, isSubmitted:Bool) {
        
        _ = RealmService.shared.realm
        _ = realm.objects(EHSReportObject.self)
       
        let newReport = EHSReportObject(questionId: questionId,
                                        inspectionId: inspectionId,
                                        answerId: answerId,
                                        createdBy: createdBy,
                                        createdDate: createdDate,
                                        modifiedDate: modifiedDate,
                                        modifiedBy: modifiedBy,
                                        isSubmitted:isSubmitted)

        RealmService.shared.create(newReport)
    }
    
    class func getReportFromId(reportId: Int) -> EHSReportObject? {
        let realm = try! Realm()
        let filteredQuestion = realm.objects(EHSReportObject.self).filter("reportId == %@", reportId)
        if filteredQuestion.count > 0 {
            return filteredQuestion[0]
        }
        else {
            return nil
        }
    }
    class func getReportsForStatus(status: Bool) -> [EHSReportObject] {
        let realm = try! Realm()
        return realm.objects(EHSReportObject.self).filter("isSubmitted == %@", status).toArray(ofType: EHSReportObject.self)
    }
}











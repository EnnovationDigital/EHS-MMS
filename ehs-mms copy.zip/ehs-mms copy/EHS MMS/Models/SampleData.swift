////
////  SampleData.swift
////  EHS MMS
////
////  Created by Macbook Pro on 5/30/18.
////  Copyright © 2018 Macbook Pro. All rights reserved.
////
//
//import Foundation
//import RealmSwift
//
//class SampleData {
//
//    func saveRegions(realmService: RealmService, regionId: Int, regionName: String?, descriptionRegion: String?, orderNo: String?) {
//        let realm = RealmService.shared.realm
//        let regions = realm.objects(md_lkp_Region.self)
//
//        let newRegion = md_lkp_Region(regionId: regionId, regionName: regionName, descriptionRegion: descriptionRegion, orderNo: orderNo)
//
//        RealmService.shared.create(newRegion)
//    }
//    func saveRegions() {
//        let realm = RealmService.shared.realm // connection
//        let regions = realm.objects(md_lkp_Region.self) // access table
//
//        let newRegion =  md_lkp_Region(regionId: 1, regionName: "USA", descriptionRegion: "empty", orderNo: "1") // store
//
//        RealmService.shared.create(newRegion) // in database store
//    }
//
//
//    func saveBuilding(buildingId: Int, buildingName: String?, descriptionBuilding: String?, orderNo: String?, regionId: Int) {
//        let realm = RealmService.shared.realm
//        let buildings = realm.objects(md_lkp_Buildings.self)
//
//        let newBuilding = md_lkp_Buildings(buildingId: buildingId, buildingName: buildingName, descriptionBuilding: descriptionBuilding, orderNo: orderNo, regionId: regionId)
//
//        RealmService.shared.create(newBuilding)
//    }
//    func saveBuildings() {
//        let realm = RealmService.shared.realm
//        let buildings = realm.objects(md_lkp_Buildings.self)
//
//        let newBuilding = md_lkp_Buildings(buildingId: 1, buildingName: "1801", descriptionBuilding: "empty", orderNo: "2", regionId: 1)
//        let newBuilding1 = md_lkp_Buildings(buildingId: 2, buildingName: "1815", descriptionBuilding: "empty", orderNo: "1", regionId: 2)
//        let newBuilding2 = md_lkp_Buildings(buildingId: 3, buildingName: "E500", descriptionBuilding: "empty", orderNo: "3", regionId: 3)
//
////        RealmService.shared.create(newBuilding)
//    }
//
//    func saveFloor(floorId: Int, floorName: String?, descriptionFloor: String?, orderNo: String?, buildingId: Int?, regionId: Int?) {
//        let realm = RealmService.shared.realm
//        let floors = realm.objects(md_lkp_Floors.self)
//
//        let newFloor = md_lkp_Floors(floorId: floorId, floorName: floorName, descriptionFloor: descriptionFloor, orderNo: orderNo, buildingId: buildingId!, regionId: regionId!)
//        RealmService.shared.create(newFloor)
//    }
//    func saveFloors() {
//        let realm = RealmService.shared.realm
//        let floors = realm.objects(md_lkp_Floors.self)
//
//        //1801
//        let newFloor = md_lkp_Floors(floorId: 1, floorName: "Ground", descriptionFloor: "empty", orderNo: "1", buildingId: 1, regionId: 1)
//        let newFloor1 = md_lkp_Floors(floorId: 2, floorName: "1", descriptionFloor: "empty", orderNo: "2", buildingId: 1, regionId: 1)
//        let newFloor2 = md_lkp_Floors(floorId: 3, floorName: "2", descriptionFloor: "empty", orderNo: "3", buildingId: 1, regionId: 1)
//
////        RealmService.shared.create(newFloor)
//    }
//
//    func saveLocation (realm: RealmService, tableName: String!, locationId: Int?, locationName: String?, descriptionLocation: String?, locationTypeId: Int?, orderNumber: String?, floorId: Int?, buidlingId: Int?, regionId: Int, telephoneNo: String?  ) {}
//
//    func saveLocation () {
//
//        let realm = RealmService.shared.realm
//        let locations = realm.objects(md_lkp_Locations.self)
//
//        let phoneNumber = "yet to be provided"
//
//        // 1801
//        let newLocation =  md_lkp_Locations(locationId: 1, locationName: "1801/V306", descriptionLocation: "empty", locationTypeId: 1, orderNo: "1", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation1 =  md_lkp_Locations(locationId: 2, locationName: "1801/V307", descriptionLocation: "empty", locationTypeId: 1, orderNo: "2", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation2 =  md_lkp_Locations(locationId: 3, locationName: "1801/V308", descriptionLocation: "empty", locationTypeId: 1, orderNo: "3", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation3 =  md_lkp_Locations(locationId: 4, locationName: "1801/V309", descriptionLocation: "empty", locationTypeId: 1, orderNo: "4", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation4 =  md_lkp_Locations(locationId: 5, locationName: "1801/V310", descriptionLocation: "empty", locationTypeId: 1, orderNo: "5", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation5 =  md_lkp_Locations(locationId: 6, locationName: "1801/V311", descriptionLocation: "empty", locationTypeId: 1, orderNo: "6", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation6 =  md_lkp_Locations(locationId: 7, locationName: "1801/V312", descriptionLocation: "empty", locationTypeId: 1, orderNo: "7", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation7 =  md_lkp_Locations(locationId: 8, locationName: "1801/V313", descriptionLocation: "empty", locationTypeId: 1, orderNo: "8", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation8 =  md_lkp_Locations(locationId: 9, locationName: "1801/V314", descriptionLocation: "empty", locationTypeId: 1, orderNo: "9", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation9 =  md_lkp_Locations(locationId: 10, locationName: "1801/V315", descriptionLocation: "empty", locationTypeId: 1, orderNo: "10", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation10 =  md_lkp_Locations(locationId: 11, locationName: "1801/V316", descriptionLocation: "empty", locationTypeId: 1, orderNo: "11", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation11 =  md_lkp_Locations(locationId: 12, locationName: "1801/V317", descriptionLocation: "empty", locationTypeId: 1, orderNo: "12", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation12 =  md_lkp_Locations(locationId: 13, locationName: "1801/V318", descriptionLocation: "empty", locationTypeId: 1, orderNo: "13", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation13 =  md_lkp_Locations(locationId: 14, locationName: "1801/V319", descriptionLocation: "empty", locationTypeId: 1, orderNo: "14", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation14 =  md_lkp_Locations(locationId: 15, locationName: "1801/V320", descriptionLocation: "empty", locationTypeId: 1, orderNo: "15", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation15 =  md_lkp_Locations(locationId: 16, locationName: "1801/V321", descriptionLocation: "empty", locationTypeId: 1, orderNo: "16", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation16 =  md_lkp_Locations(locationId: 17, locationName: "1801/V322", descriptionLocation: "empty", locationTypeId: 1, orderNo: "17", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//        let newLocation17 =  md_lkp_Locations(locationId: 17, locationName: "1801/V323", descriptionLocation: "empty", locationTypeId: 1, orderNo: "18", floorId: 1, buidlingId: 1, regionId: 1, telephoneNo: phoneNumber)
//
////        RealmService.shared.create(newLocation)
//    }
//
//    func saveLocationType(realm: RealmService, tableName: Object,locationTypeId: Int, locationType: String?, descriptionLocationType: String?, orderNo: String) {
//    }
//    func saveLocationType() {
//        let realm = RealmService.shared.realm
//        let locationType = realm.objects(md_lkp_LocationType.self)
//
//        // Generic for all buildings as this is Lookup table
//        let newLocationType  = md_lkp_LocationType(locationTypeId: 1, locationType: "Office", descriptionLocationType: "empty", orderNo: "1")
//        let newLocationType1 = md_lkp_LocationType(locationTypeId: 2, locationType: "Lab", descriptionLocationType: "empty", orderNo: "2")
//        let newLocationType2 = md_lkp_LocationType(locationTypeId: 3, locationType: "Closet", descriptionLocationType: "empty", orderNo: "3")
//        let newLocationType3 = md_lkp_LocationType(locationTypeId: 4, locationType: "Conference", descriptionLocationType: "empty", orderNo: "4")
//        let newLocationType4 = md_lkp_LocationType(locationTypeId: 5, locationType: "Kitchen", descriptionLocationType: "empty", orderNo: "5")
//        let newLocationType5 = md_lkp_LocationType(locationTypeId: 6, locationType: "Facility", descriptionLocationType: "empty", orderNo: "6")
//
//     //   RealmService.shared.create(newLocationType)
//    }
//
//    func saveDepartments (realm: RealmService, tableName: Object, departmentId: Int, department: String?) {
//    }
//    func saveDepartments () {
//        let realm = RealmService.shared.realm
//        let departments = realm.objects(md_lkp_Departments.self)
//
//        // Generic for all
//        let newDepartment = md_lkp_Departments(departmentId: 1, department: "Toxicology")
//        let newDepartment1 = md_lkp_Departments(departmentId: 2, department: "DMB")
//        let newDepartment2 = md_lkp_Departments(departmentId: 3, department: "Preclinical Pharmacology")
//        let newDepartment3 = md_lkp_Departments(departmentId: 4, department: "Applied Technology")
//        let newDepartment4 = md_lkp_Departments(departmentId: 5, department: "Translational Sciences")
//
////        RealmService.shared.create(newDepartment)
//    }
//
//    func saveUsers(realm: RealmService, tableName: Object, userId: Int, userName: String?, workEmail: String?, personalEmail: String?, departmentId: Int, supervisor: String?, phoneNo: String?, orderNo: String?) {
//    }
//    func saveUsers() {
//        let realm = RealmService.shared.realm
//        let users = realm.objects(md_Users.self)
//
//        let workEmail = "yet to be provoided"
//        let personalEmail = "yet to be provided"
//        let supervisor = "empty"
//        let userOrderNo = "empty"
//        let phoneNumber = "empty"
//
//        let newUser = md_Users(userId: 1, userName: "Kristen Colangelo", workEmail: workEmail, personalEmail: personalEmail, departmentId: 1, supervisor: supervisor, phoneNo: phoneNumber, orderNo: userOrderNo)
//        let newUser1 = md_Users(userId: 2, userName: "Philip Czerniak", workEmail: workEmail, personalEmail: personalEmail, departmentId: 1, supervisor: supervisor, phoneNo: phoneNumber, orderNo: userOrderNo)
//        let newUser2 = md_Users(userId: 3, userName: "Amy Hehman", workEmail: workEmail, personalEmail: personalEmail, departmentId: 1, supervisor: supervisor, phoneNo: phoneNumber, orderNo: userOrderNo)
//
////        RealmService.shared.create(newUser2)
//    }
//
//    func saveUserLocation(realm: RealmService, tableName: Object, userLocationId: Int, locationId: Int, userId: Int, orderNo: String?) {
//    }
//    func saveUserLocation() {
//        let realm = RealmService.shared.realm
//        let userLocation = realm.objects(md_UserLocation.self)
//
//        // Kristen Colangelo
//        let newUserLocation   = md_UserLocation(userLocationId: 1, locationId: 1, userId: 1, orderNo: "1")
//        let newUserLocation1  = md_UserLocation(userLocationId: 2, locationId: 2, userId: 1, orderNo: "2")
//        let newUserLocation2  = md_UserLocation(userLocationId: 3, locationId: 3, userId: 1, orderNo: "3")
//        let newUserLocation3  = md_UserLocation(userLocationId: 4, locationId: 4, userId: 1, orderNo: "4")
//        let newUserLocation4  = md_UserLocation(userLocationId: 5, locationId: 5, userId: 1, orderNo: "5")
//        let newUserLocation5  = md_UserLocation(userLocationId: 6, locationId: 6, userId: 1, orderNo: "6")
//        let newUserLocation6  = md_UserLocation(userLocationId: 7, locationId: 7, userId: 1, orderNo: "7")
//        let newUserLocation7  = md_UserLocation(userLocationId: 8, locationId: 8, userId: 1, orderNo: "8")
//        let newUserLocation8  = md_UserLocation(userLocationId: 9, locationId: 9, userId: 1, orderNo: "9")
//        let newUserLocation9 = md_UserLocation(userLocationId: 10, locationId: 10, userId: 1, orderNo: "10")
//        let newUserLocation10 = md_UserLocation(userLocationId: 11, locationId: 11, userId: 1, orderNo: "11")
//        let newUserLocation11 = md_UserLocation(userLocationId: 12, locationId: 12, userId: 1, orderNo: "12")
//        let newUserLocation12 = md_UserLocation(userLocationId: 13, locationId: 13, userId: 1, orderNo: "13")
//        let newUserLocation13 = md_UserLocation(userLocationId: 14, locationId: 14, userId: 1, orderNo: "14")
//        let newUserLocation14 = md_UserLocation(userLocationId: 15, locationId: 15, userId: 1, orderNo: "15")
//        let newUserLocation15 = md_UserLocation(userLocationId: 16, locationId: 16, userId: 1, orderNo: "16")
//        let newUserLocation16 = md_UserLocation(userLocationId: 17, locationId: 17, userId: 1, orderNo: "17")
//        let newUserLocation17 = md_UserLocation(userLocationId: 18, locationId: 18, userId: 1, orderNo: "18")
//
//        // Philip Czerniak
//        let newUserLocation0   = md_UserLocation(userLocationId: 19, locationId: 1, userId: 2, orderNo: "19")
//        let newUserLocation01  = md_UserLocation(userLocationId: 20, locationId: 2, userId: 2, orderNo: "20")
//        let newUserLocation02  = md_UserLocation(userLocationId: 21, locationId: 3, userId: 2, orderNo: "21")
//        let newUserLocation03  = md_UserLocation(userLocationId: 22, locationId: 4, userId: 2, orderNo: "22")
//        let newUserLocation04  = md_UserLocation(userLocationId: 23, locationId: 5, userId: 2, orderNo: "23")
//        let newUserLocation05  = md_UserLocation(userLocationId: 24, locationId: 6, userId: 2, orderNo: "24")
//        let newUserLocation06  = md_UserLocation(userLocationId: 25, locationId: 7, userId: 2, orderNo: "25")
//        let newUserLocation07  = md_UserLocation(userLocationId: 26, locationId: 8, userId: 2, orderNo: "26")
//        let newUserLocation08  = md_UserLocation(userLocationId: 27, locationId: 9, userId: 2, orderNo: "27")
//        let newUserLocation09  = md_UserLocation(userLocationId: 28, locationId: 10, userId: 2, orderNo: "28")
//        let newUserLocation010 = md_UserLocation(userLocationId: 29, locationId: 11, userId: 2, orderNo: "29")
//        let newUserLocation011 = md_UserLocation(userLocationId: 30, locationId: 12, userId: 2, orderNo: "30")
//        let newUserLocation012 = md_UserLocation(userLocationId: 31, locationId: 13, userId: 2, orderNo: "31")
//        let newUserLocation013 = md_UserLocation(userLocationId: 32, locationId: 14, userId: 2, orderNo: "32")
//        let newUserLocation014 = md_UserLocation(userLocationId: 33, locationId: 15, userId: 2, orderNo: "33")
//        let newUserLocation015 = md_UserLocation(userLocationId: 34, locationId: 16, userId: 2, orderNo: "34")
//        let newUserLocation016 = md_UserLocation(userLocationId: 35, locationId: 17, userId: 2, orderNo: "35")
//        let newUserLocation017 = md_UserLocation(userLocationId: 36, locationId: 18, userId: 2, orderNo: "36")
//
//        // Amy Hehman
//        let newUserLocation00   = md_UserLocation(userLocationId: 37, locationId: 1, userId: 3, orderNo: "37")
//        let newUserLocation001  = md_UserLocation(userLocationId: 38, locationId: 2, userId: 3, orderNo: "38")
//        let newUserLocation002  = md_UserLocation(userLocationId: 39, locationId: 3, userId: 3, orderNo: "39")
//        let newUserLocation003  = md_UserLocation(userLocationId: 40, locationId: 4, userId: 3, orderNo: "40")
//        let newUserLocation004  = md_UserLocation(userLocationId: 41, locationId: 5, userId: 3, orderNo: "41")
//        let newUserLocation005  = md_UserLocation(userLocationId: 42, locationId: 6, userId: 3, orderNo: "42")
//        let newUserLocation006  = md_UserLocation(userLocationId: 43, locationId: 7, userId: 3, orderNo: "43")
//        let newUserLocation007  = md_UserLocation(userLocationId: 44, locationId: 8, userId: 3, orderNo: "44")
//        let newUserLocation008  = md_UserLocation(userLocationId: 45, locationId: 9, userId: 3, orderNo: "45")
//        let newUserLocation009  = md_UserLocation(userLocationId: 46, locationId: 10, userId: 3, orderNo: "46")
//        let newUserLocation0010 = md_UserLocation(userLocationId: 47, locationId: 11, userId: 3, orderNo: "47")
//        let newUserLocation0011 = md_UserLocation(userLocationId: 48, locationId: 12, userId: 3, orderNo: "48")
//        let newUserLocation0012 = md_UserLocation(userLocationId: 49, locationId: 13, userId: 3, orderNo: "49")
//        let newUserLocation0013 = md_UserLocation(userLocationId: 50, locationId: 14, userId: 3, orderNo: "50")
//        let newUserLocation0014 = md_UserLocation(userLocationId: 51, locationId: 15, userId: 3, orderNo: "51")
//        let newUserLocation0015 = md_UserLocation(userLocationId: 52, locationId: 16, userId: 3, orderNo: "52")
//        let newUserLocation0016 = md_UserLocation(userLocationId: 53, locationId: 17, userId: 3, orderNo: "53")
//        let newUserLocation0017 = md_UserLocation(userLocationId: 54, locationId: 18, userId: 3, orderNo: "54")
//
////        RealmService.shared.create(newUserLocation0017)
//    }
//}
//

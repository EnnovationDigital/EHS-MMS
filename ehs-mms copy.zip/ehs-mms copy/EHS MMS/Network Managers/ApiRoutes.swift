//
//  ApiRoutes.swift
//  EHS MMS
//
//  Created by Macbook Pro on 6/25/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

class ApiRoutes: NSObject {
    
    static let ENTRYPOINT = "/_api/web/lists/"
    
    //* Master Data API *//
    
    // Get Location data
        // Get Location data
    static let GET_ALL_REGIONS =  ENTRYPOINT + "getbytitle('md_lkp_Region')/items?$select=ID,RegionName,Description,OrderNo,Status"
    static let GET_ALL_BUILDINGS = ENTRYPOINT + "getbytitle('md_lkp_Buildings')/items?$select=ID,BuildingName,Description,RegionId,OrderNo,Status"
    static let GET_ALL_FLOORS = ENTRYPOINT + "getbytitle('md_lkp_Floors')/items?$select=ID,RegionId,BuildingId,FloorName,Description,OrderNo,Status"
    static let GET_ALL_LOCATIONTYPE = ENTRYPOINT + "getbytitle('md_lkp_LocationType')/items?$select=ID,LocationType,Description,OrderNo,Status"
    static let GET_ALL_LOCATIONS = ENTRYPOINT + "getbytitle('md_lkp_Locations')/items?$select=ID,RegionId,BuildingId,FloorId,LocationTypeId,LocationName,Description,TelephoneNo,OrderNo,Status"

    // Get User data
    static let GET_ALL_USERS = ENTRYPOINT + "getbytitle('md_Users')/items?$select=ID,WorkEmail,PersonalEmail,Supervisor/Title,UserName/Title,PhoneNo,Status,OrderNo,DepartmentId&$expand=Supervisor,UserName"
    static let GET_ALL_DEPARTMENT = ENTRYPOINT + "getbytitle('md_lkp_Departments')/items?$select=ID,Department,Status"
    static let GET_ALL_USERLOCATION = ENTRYPOINT + "getbytitle('md_UserLocation')/items?$select=ID,LocationId,UserNameId,OrderNo,Status"
    
    // Get Question Data
        // Get All InspectionType
        // Get All Category
        // Get All SubCategory
        // Get All Questions
        // Get All Regulation
        // Get All IssueType
        // Get All AnswerType
        // Get All AnswersToQuestions
    
    //* Mobile to Sync - Online Mode *//
    
    // Login
    
        // Login
        // Get AccessToken
    
    // Create a new staging Ticket from Mobile
        // Get RequestDigest
        // Create a new staging Inspection details
        // Update staging Inspection details
        // Update staging Inspection details
        // Delete staging Inspection details.
        // Create a new record for an answered question
        // Update a record for an answered question
        // Delete record for an answered question
        // Create a new record for tracking a ticket Progress
        // Update record for tracking a ticket Progress
        // Delete record for tracking a ticket Progress
    
    
    
    
    
}

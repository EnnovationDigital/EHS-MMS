//
//  BaseApi.swift
//  EHS MMS
//
//  Created by Macbook Pro on 6/25/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

class BaseApi: NSObject {
    
    static let BASE_URL: String = "https://incytedev.sharepoint.com/sites/EHSMMS"
}

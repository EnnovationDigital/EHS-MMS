    //
//  EHSInspectionManager.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 30/07/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class EHSInspectionManager: NSObject {

    class func fetchMDATA (params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        
        NetworkManager().postRequest(parameters: params, endPoint: API.API_GET_MASTER_DATA_CODE, completion: {(message, response) in
            
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    if let ehsResponse = response["EHSResponse"] {
                        completionBlock("SUCCESS",ehsResponse as! [String : AnyObject])
                        return
                    }
                }
                completionBlock("FAILED",[:])
            }
        })
    }

    
    
    
    //MARK: - Create Inspection
    
    class func createNewInspection(params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        
        NetworkManager().postRequest(parameters: params, endPoint: API.API_CREATE_NEW_INSPECTION_CODE, completion: {(message, response) in
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    let ehsResponse = response["EHSResponse"]
                    completionBlock("SUCCESS",ehsResponse as! [String : AnyObject])
                }
                else {
                    completionBlock(message,[:])
                }
            }
        })
    }
    
    
    
    
    //Create a new record for tracking a ticket Progress.
    class func createCRSIP (params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        
        NetworkManager().postRequest(parameters: params, endPoint: API.API_CREATE_TRACKING_TICKET_CODE, completion: {(message, response) in
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    let ehsResponse = response["EHSResponse"]
                    completionBlock("SUCCESS",ehsResponse as! [String : AnyObject])
                }
                else {
                    completionBlock(message,[:])
                }
            }
        })
    }
    
    //Create a new record for tracking a ticket Progress.
    class func createCRSIQ (params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        
        NetworkManager().postRequest(parameters: params, endPoint: API.API_CREATE_QUESTION_TICKET_CODE, completion: {(message, response) in
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    let ehsResponse = response["EHSResponse"]
                    completionBlock("SUCCESS",ehsResponse as! [String : AnyObject])
                }
                else {
                    completionBlock(message,[:])
                }
            }
        })
    }
    
    class func deleteDRSIQ (params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        
        NetworkManager().postRequest(parameters: params, endPoint: API.API_DELETE_QUESTION, completion: {(message, response) in
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    let ehsResponse = response["EHSResponse"]
                    completionBlock("SUCCESS",ehsResponse as! [String : AnyObject])
                }
                else {
                    completionBlock(message,[:])
                }
            }
        })
    }
    //Add a picture to stg_InspectionQuestionsPicture Library.
    class func createCRSIQP (params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        
        NetworkManager().postRequest(parameters: params, endPoint: API.API_SUBMIT_PICTURE_CODE, completion: {(message, response) in
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    let ehsResponse = response["EHSResponse"]
                    completionBlock("SUCCESS",ehsResponse as! [String : AnyObject])
                }
                else {
                    completionBlock(message,[:])
                }
            }
        })
    }
    
    
    //MARK: - DELETE INSPECTIONS
    class func deleteInspection (inspectionID: String, completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        NetworkManager().postRequest(parameters: ["itemid":inspectionID], endPoint: API.API_DELETE_INSPECTION, completion: {(message, response) in
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    let ehsResponse = response["EHSResponse"]
                    completionBlock("SUCCESS",ehsResponse as! [String : AnyObject])
                }
                else {
                    completionBlock(message,[:])
                }
            }
        })
    }
    
    
    
    
//    class func deleteInspection (inspectionID: String, completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
//        NetworkManager().postRequest(parameters: ["itemid":inspectionID], endPoint: API.API_DELTE_INSPECTION_CODE, completion: {(message, response) in
//            DispatchQueue.main.async {
//                if (message == "SUCCESS" ) {
//                    let ehsResponse = response["EHSResponse"]
//                    completionBlock("SUCCESS",ehsResponse as! [String : AnyObject])
//                }
//                else {
//                    completionBlock(message,[:])
//                }
//            }
//        })
//    }
    //MARK: - DELETE INSPECTIONS
    
    
    
    // MARK: - Pending Inspections
    
    class func checkPendingInspections (params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        NetworkManager().postRequest(parameters: params, endPoint: API.API_PENDING_INSPECTIONS_AT_PLACE) { (message, response) in
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    let ehsResponse = response["EHSResponse"]
                    completionBlock("SUCCESS",ehsResponse as! [String : AnyObject])
                }
                else {
                    completionBlock(message,[:])
                }
            }
        }
    }
    
    // MARK: - Update
    
    class func updateQuestion (params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        NetworkManager().postRequest(parameters: params, endPoint: API.API_UPDATE_QUESTION) { (message, response) in
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    let ehsResponse = response["EHSResponse"]
                    completionBlock("SUCCESS",ehsResponse as! [String : AnyObject])
                }
                else {
                    completionBlock(message,[:])
                }
            }
        }
    }
    
    class func updateImage (params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        NetworkManager().postRequest(parameters: params, endPoint: API.API_UPDATE_PCITURE) { (message, response) in
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    let ehsResponse = response["EHSResponse"]
                    completionBlock("SUCCESS",ehsResponse as! [String : AnyObject])
                }
                else {
                    completionBlock(message,[:])
                }
            }
        }
    }
    
    
    /*
    //MARK: - Fetch Inspection
    
     //DELTAMDATA
     
     class func fetchDELTAMDATA (params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
     
     NetworkManager().postRequest(parameters: params, endPoint: API.API_AUTHENTICATE_USER, completion: {(message, response) in
     
     DispatchQueue.main.async {
     if (message == "SUCCESS" ) {
     
     let dictData = response["data"]
     print(dictData!)
     }
     else {
     completionBlock(message,[:])
     }
     }
     })
     }
 */

}





















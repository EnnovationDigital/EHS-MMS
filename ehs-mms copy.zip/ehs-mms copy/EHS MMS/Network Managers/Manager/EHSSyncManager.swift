//
//  EHSSyncManager.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 30/07/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class EHSSyncManager: NSObject {

}

//
//  EHSUserManager.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 30/07/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class EHSUserManager: NSObject {

    
    class func signInUserWith (credentials: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        
        NetworkManager().postRequest(parameters: credentials, endPoint: API.API_AUTHENTICATE_USER_CODE, completion: {(message, response) in
            
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    print(response)
                    if let ehsResponse = response["EHSResponse"] {
                        if let accessToken = (ehsResponse["AccessToken"] as? [String:String]) {
                            if let respData = accessToken["respData"] {
                                print(respData)
                                if respData.count > 0 {
                                    UserDefaults.standard.set(respData, forKey: "AccessToken")
                                    UserDefaults.standard.set(Date(), forKey: "TokenTime")
                                    UserDefaults.standard.set(true, forKey: "UserLoggedIn")
                                    UserDefaults.standard.synchronize()
                                    completionBlock("SUCCESS",[:])
                                    
                                    return
                                }
                            }
                        }
                    }
                }
                completionBlock("FAILED",[:])
                
            }
        })
    }
    
    class func fetchUserDetails(params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        
        NetworkManager().postRequest(parameters: params, endPoint: API.API_AUTHENTICATE_USER_CODE, completion: {(message, response) in
            
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    let dictData = response["data"]
                    print(dictData!)
                }
                else {
                    completionBlock(message,[:])
                }
            }
        })
    }
    
    class func updateUserDeviceToken (params: [String:String], completionBlock:@escaping (_ message:String, _ response:[String:AnyObject]) -> Void) {
        
        NetworkManager().postRequest(parameters: params, endPoint: API.API_UPDATE_USER_PUSH_TOKEN, completion: {(message, response) in
            
            DispatchQueue.main.async {
                if (message == "SUCCESS" ) {
                    if let dictData = response["data"] {
                        print(dictData)
                        completionBlock("SUCCESS",[:])
                    }
                    else {
                        completionBlock(message,[:])
                    }                    
                }
                else {
                    completionBlock(message,[:])
                }
            }
        })
    }
    
    
    
}

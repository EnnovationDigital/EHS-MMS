
//  NetworkManager.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 30/07/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import Alamofire
import SKActivityIndicatorView
class NetworkManager: NSObject {

    var sessionManager = SessionManager()
    
    // MARK: - HTTPs
    var serverTrustPolicy : ServerTrustPolicy? = nil
    var serverTrustPolicies : NSDictionary = [:]
    
   public var completionHandler : ((String,[String: AnyObject]) -> Void)?
    
    func uploadImage (imgData:Data, imgName:String, endPoint : String,completion: @escaping (_ message: String, _ response: [String: AnyObject]) -> Void)  {
        let (apiAddress, _) = self.setUpAPIParams(endPiont: endPoint)
        Alamofire.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(imgData, withName: "fileset",fileName: imgName, mimeType: "image/jpg")
        }, to:apiAddress) { (result) in
            
            switch result {
            case .success(let upload, _, _):
                
                upload.uploadProgress(closure: { (progress) in
                    print("Upload Progress: \(progress.fractionCompleted)")
                })
                
                upload.responseJSON { response in
                    completion("FAILED",[:])
                }
                
            case .failure(let encodingError):
                print(encodingError)
            }
        }
    }
    
   
    func continueAfterLogin (urlFinal : URL) {
        makeTheNetworkCall(urlFinal: urlFinal, completion: completionHandler!)
    }
    
    private func makeTheNetworkCall(urlFinal : URL, completion: @escaping (_ message: String, _ response: [String: AnyObject]) -> Void) {
        var headers = [String:String] ()
        headers["Content-Type"] = "application/json"
        //SKActivityIndicator.show("Loading...", userInteractionStatus: false)
        AICLSessionManager.shared().manager.request(urlFinal, method: .post, parameters: nil, encoding: JSONEncoding.default, headers: headers).responseJSON {response in
//            print(response)
            //SKActivityIndicator.dismiss()
            let receivedObject = self.toJSON(data: (response.data)!)
            if (receivedObject != nil) {
                completion("SUCCESS",receivedObject as! [String : AnyObject])
                return
            }
            else {
                completion("FAILED",[:])
            }
        }
        
    }
   
    //MARK: - POST
    func postRequest (parameters : [String : String], endPoint : String, completion: @escaping (_ message: String, _ response: [String: AnyObject]) -> Void)  {
        
        if Connectivity.isConnectedToInternet {
            print("Connected")
        }
        else {
            completion("NI",[:])
            return
        }
        
        var shouldBeANetworkCall = false
        
        if UserDefaults.standard.object(forKey: "TokenTime") != nil && endPoint != API.API_AUTHENTICATE_USER_CODE {
            let tokenTime = UserDefaults.standard.object(forKey: "TokenTime") as! Date
            let currentTime = Date()
            if currentTime.timeIntervalSince(tokenTime) >= 60*60 {
                shouldBeANetworkCall = false
                UserDefaults.standard.set(parameters, forKey: "APIParams")
                UserDefaults.standard.set(endPoint, forKey: "EndPoint")
                UserDefaults.standard.synchronize()
                self.completionHandler = completion
                self.userLoginAlert()
                return
            }
            else {
                self.completionHandler = completion
                shouldBeANetworkCall = true
            }
        }
        
        let urlFinal = self.creteFinalURL(endPoint: endPoint, parameters: parameters)

        if (endPoint != API.API_AUTHENTICATE_USER_CODE && self.completionHandler != nil) && shouldBeANetworkCall == true {
            makeTheNetworkCall(urlFinal: urlFinal, completion: self.completionHandler!)
            completionHandler = nil
            
        }
        else if (endPoint == API.API_AUTHENTICATE_USER_CODE){
            makeTheNetworkCall(urlFinal: urlFinal, completion: completion)
        }
    }
    

    func creteFinalURL(endPoint: String, parameters : [String : String]) -> URL {
        let (apiAddress, _) = self.setUpAPIParams(endPiont: endPoint)
        
        let strParameters = (parameters.compactMap({ (key, value) -> String in
            return "\(key)=\(value)"
        }) as Array).joined(separator: "&")
        print(strParameters)
        
        let urlFinal = strParameters.count > 0 ? URL(string: String(format: "%@&%@", apiAddress,strParameters)) : URL(string: apiAddress)
        print(urlFinal!)
        return urlFinal!
    }
    
    //MARK: - Helper Functions
    func toJSON(data: Data) -> AnyObject? {
        do {
            return try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as AnyObject
        }
        catch let myJSONError {
            print(myJSONError)
        }
        
        return nil
    }
    
    
    
    func setUpAPIParams(endPiont:String) -> (String,[String:String]) {
        
        var strServerURL = String(format: API.API_BASE_URL,endPiont,API.API_AUTH_KEY)
        
        if endPiont == API.API_AUTHENTICATE_USER_CODE {
            
        }
        else {
            if (UserDefaults.standard.object(forKey: "AccessToken") != nil) {
                strServerURL = String(format: "%@&accesstoken=%@", strServerURL,UserDefaults.standard.object(forKey: "AccessToken") as! String)
            }
            
        }
        
        var headers = [String:String] ()
        headers["Content-Type"] = "application/json"
        
        return(strServerURL ,headers)
    }
    
    func userLoginAlert () {
        
        let alertController = UIAlertController(title: "Login", message: "Your session has expired. Enter your credentials to login again", preferredStyle: .alert)
        
        alertController.addTextField { (textField) in
            textField.placeholder = "Email"
            textField.keyboardType = .emailAddress
        }
        
        alertController.addTextField { (textField) in
            textField.placeholder = "Password"
            textField.isSecureTextEntry = true
        }
        
        var currentController :UIViewController? =  nil
        
        if var topController = UIApplication.shared.keyWindow?.rootViewController {
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            currentController = topController
        }
        
        let loginAction = UIAlertAction(title: "Login", style: .default) { (_) in
            let emailField = alertController.textFields![0]
            let passwordField = alertController.textFields![1]
            
            //Perform validation or whatever you do want with the text of textfield
            
            if emailField.text == "" && passwordField.text == "" {
                Constants().displayAlert(title: "", message: "Credentials are required", dismiss: "Dismiss", view: currentController!)
            }
            else if emailField.text == "" {
                Constants().displayAlert(title: "Email is empty", message: "Email or username is required", dismiss: "Dismiss", view: currentController!)
            }
            else if passwordField.text == "" {
                Constants().displayAlert(title: "Password is empty", message: "Password is required", dismiss: "Dismiss", view: currentController!)
            }
            else {
                let params = ["username":emailField.text!,"password":passwordField.text!]
                
                UserDefaults.standard.set(emailField.text, forKey: "UserEmailAddress")
                UserDefaults.standard.set(params, forKey: "Credentials")
                UserDefaults.standard.synchronize()
                self.postRequest(parameters: params, endPoint: API.API_AUTHENTICATE_USER_CODE, completion: { (message, response) in
                    if message == "FAILED" {
                        Constants().displayAlert(title: "Sign in Failed", message: "Please sign in again.", dismiss: "Ok", view: currentController!)
                    }
                    else {
                        if let ehsResponse = response["EHSResponse"] {
                            if let accessToken = (ehsResponse["AccessToken"] as? [String:String]) {
                                if let respData = accessToken["respData"] {
                                    if respData.count > 0 {
                                        UserDefaults.standard.set(respData, forKey: "AccessToken")
                                        UserDefaults.standard.set(Date(), forKey: "TokenTime")
                                        UserDefaults.standard.set(true, forKey: "UserLoggedIn")
                                        UserDefaults.standard.synchronize()
                                        if UserDefaults.standard.object(forKey: "EndPoint") != nil {
                                            let parameters = UserDefaults.standard.object(forKey: "APIParams")
                                            let endPoint = UserDefaults.standard.string(forKey: "EndPoint")
                                            if endPoint != nil && parameters != nil {
                                                let urlFinal = self.creteFinalURL(endPoint: endPoint!, parameters: parameters as! [String : String])
                                                self.continueAfterLogin(urlFinal: urlFinal)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                })
            }
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(loginAction)
        alertController.addAction(cancelAction)
        
        currentController!.present(alertController, animated: true, completion: nil)
        
        
//        UIApplication.shared.keyWindow?.rootViewController?.present(alertController, animated: true, completion: nil)
    }
    
    
    
}
























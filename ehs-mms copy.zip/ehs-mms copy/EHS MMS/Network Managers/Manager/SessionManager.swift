//
//  SessionManager.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 30/07/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import Alamofire

class AICLSessionManager: NSObject {

    
    let manager: Alamofire.SessionManager = {
//        let serverTrustPolicies: [String: ServerTrustPolicy] = [
//            API.SERVER_URL: .disableEvaluation
//        ]
        
        let configuration = URLSessionConfiguration.default
        configuration.httpAdditionalHeaders = Alamofire.SessionManager.defaultHTTPHeaders
        
        return Alamofire.SessionManager(
            configuration: configuration
//            serverTrustPolicyManager:CustomServerTrustPolicyManager()
        )
    }()
    
    private struct Static {
        static let instance : AICLSessionManager = AICLSessionManager()  //static one instance only
    }
    
    class func shared() -> AICLSessionManager {
        return Static.instance   // return the shared instance
    }
    
    override init() {
        super.init()
        
    }
    
}

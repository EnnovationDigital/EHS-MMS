//
//  Questions.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/22/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import DLRadioButton

class Questions: UIViewController, UITextViewDelegate {
    
    // outlet
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var questionNumber: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet var addText: UITextView!
    
    @IBOutlet var submitBtn: UIButton!
    @IBOutlet var nextBtn: UIButton!
    @IBOutlet var uploadBtn: UIButton!
    
    @IBOutlet weak var menuImage: UIImageView!
    
    @IBOutlet var optionBtn: DLRadioButton!
    
    @IBOutlet var sideWidth: NSLayoutConstraint!
    var question = [String]()
    var indexShowing = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        question.append("Statement for first question")
        question.append("Statement for second question")
        question.append("Statement for third question")
        question.append("Statement for fourth question")
        question.append("Statement for fifth question")
        question.append("Statement for sixth question")
        questionLabel.text = question[0]
        questionNumber.text = "Question Number : 1"
        nextButton.isHidden = false
        self.addText.delegate = self
        setSideMenu()
    }
    override func viewWillAppear(_ animated: Bool) {
        ButtonHelper.setRoundCornerButton(button: nextButton)
        ButtonHelper.setRoundCornerButton(button: submitBtn)
        uploadBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 20);
    }
    override func viewWillDisappear(_ animated: Bool) {
        if #available(iOS 11.0, *) {
            self.navigationController?.navigationBar.prefersLargeTitles = true
        } else {
            // Fallback on earlier versions
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }

    func setSideMenu() {
        if #available(iOS 11.0, *) {
            self.navigationController?.navigationBar.prefersLargeTitles = false
        } else {
            // Fallback on earlier versions
        }
        if UI_USER_INTERFACE_IDIOM() == .pad {
            self.navigationItem.rightBarButtonItem = nil
            menuImage.isHidden = true
        } else {
            self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
    }
    
    
    @objc func rightReveal() {
        Constants().actionSheet(view: self, title: "EHS MMS", message: "Perform Actions", mainMenuCompletion: { (main) in
            self.performSegue(withIdentifier: "goToMenu", sender: self)
        }, saveCompletion: { (save) in
            print("save")
        }) { (discard) in
            print("dis")
        }
    }
    

    
    @IBAction func nextAct(_ sender: Any) {
        // let nextIndex = indexShowing + 1
        self.indexShowing = self.indexShowing + 1
        print(indexShowing)
        // print(nextIndex)
        print(question.count)
        if indexShowing == question.count {
            print("index greater than questioons")
        } else {
            self.questionNumber.text = "Question Number : \(self.indexShowing + 1)"
            self.questionLabel.text = self.question[self.indexShowing]
            if indexShowing == question.count - 1 {
                nextButton.isHidden = true
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        UIView.animate(withDuration: 0.5) {
            self.view.frame.origin.y += 180
        }
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        UIView.animate(withDuration: 0.5) {
            self.view.frame.origin.y -= 180
        }
    }
    
    // action
    @IBAction func submitAction(_ sender: Any) {
        let options = UIAlertController.init(title: "Select Another Sub-Category ?", message: "", preferredStyle: .actionSheet)
        let another = UIAlertAction.init(title: "Select Another", style: .default) { (action) in
            self.performSegue(withIdentifier: "unwindToSubCat", sender: self)
        }
        let submit = UIAlertAction.init(title: "Submit", style: .destructive) { (act) in
            self.submitData()
        }
        let cancel = UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil)
        options.addAction(another)
        options.addAction(submit)
        options.addAction(cancel)
        options.popoverPresentationController?.sourceView = self.view
        self.present(options, animated: true, completion: nil)
    }
    
    func submitData() {
        let alert = UIAlertController.init(title: "Success", message: "Inspection has been submitted", preferredStyle: .alert)
        alert.addAction(UIAlertAction.init(title: "Done", style: .destructive, handler: { (act) in
            self.performSegue(withIdentifier: "goToMenu", sender: self)
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func uploadAction(_ sender: Any) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        
        let actionSheet = UIAlertController(title: "Photo Source", message: "Choose a source", preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action: UIAlertAction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                imagePickerController.sourceType = .camera
                self.present(imagePickerController, animated: true, completion:  nil)
            } else {
                print("Not Available")
            }
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action: UIAlertAction) in
            imagePickerController.sourceType = .photoLibrary
            self.present(imagePickerController, animated: true, completion:  nil)
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    
    @IBAction func saveAction(_ sender: Any) {
        Constants().displayAlert(title: "Save", message: "Saved Inspection", dismiss: "ok", view: self)
    }
    
    @IBAction func discardAction(_ sender: Any) {
        Constants().displayAlert(title: "Discard", message: "Are you sure you want to discard?", dismiss: "No", view: self)
    }
    
    @IBAction func menuAction(_ sender: Any) {
        let vC = self.storyboard?.instantiateViewController(withIdentifier: "EntryView")
        self.show(vC!, sender: self)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

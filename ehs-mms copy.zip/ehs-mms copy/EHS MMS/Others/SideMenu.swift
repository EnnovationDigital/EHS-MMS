//
//  SideMenu.swift
//  EHS MMS
//
//  Created by Macbook Pro on 3/6/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class SideMenu: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func settingsAction(_ sender: Any) {
        changeViewControllerHelper.changeScreen(screenId: "Settings", controller: self)
    }
    
    @IBAction func mainAction(_ sender: Any) {
        changeViewControllerHelper.changeScreen(screenId: "LandingView", controller: self)
    }
    
    @IBAction func logoutAct(_ sender: Any) {
        performSegue(withIdentifier: "sideMenuToLogin", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

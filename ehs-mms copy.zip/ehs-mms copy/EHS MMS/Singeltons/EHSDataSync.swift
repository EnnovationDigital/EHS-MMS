//
//  EHSDataSync.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 9/3/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class EHSDataSync: NSObject {

//    let manager: Alamofire.SessionManager = {
//        //        let serverTrustPolicies: [String: ServerTrustPolicy] = [
//        //            API.SERVER_URL: .disableEvaluation
//        //        ]
//
//        let configuration = URLSessionConfiguration.default
//        configuration.httpAdditionalHeaders = Alamofire.SessionManager.defaultHTTPHeaders
//
//        return Alamofire.SessionManager(
//            configuration: configuration
//            //            serverTrustPolicyManager:CustomServerTrustPolicyManager()
//        )
//    }()
    
    private struct Static {
        static let instance : EHSDataSync = EHSDataSync()  //static one instance only
    }
    
    class func shared() -> EHSDataSync {
        return Static.instance   // return the shared instance
    }
    
    override init() {
        super.init()
        
    }
    
    func fetchMData () {
//        EHSInspectionManager.fetchMDATA(params: [:]) { (message, response) in
//            if message == "SUCCESS" {
//                //MARK: - Regions
//                if let allRegions = response["md_lkp_Region"] as? [String:AnyObject] {
//                    md_lkp_Region().saveRegtionsMData(data: allRegions)
//                }
//                if let allBuildings = response["md_lkp_Buildings"] as? [String:AnyObject] {
//                    md_lkp_Buildings().saveBuildingsMDATA(data: allBuildings)
//                }
//                
//                if let allFloors = response["md_lkp_Floors"] as? [String:AnyObject] {
//                    md_lkp_Floors().saveFloorsMDATA(data: allFloors)
//                }
//                
//                if let allLocationTypes = response["md_lkp_LocationType"] as? [String:AnyObject] {
//                    md_lkp_LocationType().saveLocationTypesMData(data: allLocationTypes)
//                }
//                
//                if let allLocations = response["md_lkp_Locations"] as? [String:AnyObject] {
//                    md_lkp_Locations().saveLocationsMDATA(data: allLocations)
//                }
//                
//                if let allDepartments = response["md_lkp_Departments"] as? [String:AnyObject] {
//                    md_lkp_Departments().saveDepartmentsMData(data: allDepartments)
//                }
//                
//                if let allUsers = response["md_Users"] as? [String:AnyObject] {
//                    md_Users().saveUsersMData(data: allUsers)
//                }
//                
//                if let allUserLocations = response["md_UserLocation"] as? [String:AnyObject] {
//                    md_UserLocation().saveUserLocationsMData(data: allUserLocations)
//                }
//                
//                if let allInspections = response["md_lkp_InspectionType"] as? [String:AnyObject] {
//                    md_lkp_InspectionType().saveInspectionMData(data: allInspections)
//                }
//               
//                if let allCategories = response["md_lkp_Category"] as? [String:AnyObject] {
//                    md_lkp_Category().saveCategoryMData(data: allCategories)
//                }
//                
//                if let allSubCategories = response["md_lkp_SubCategory"] as? [String:AnyObject] {
//                    md_lkp_SubCategory().saveSubCategoryMData(data: allSubCategories)
//                }
//                
//                
//                UserDefaults.standard.set(true, forKey: "Sync")
//                UserDefaults.standard.synchronize()
//                
//            }
//            else {
//                UserDefaults.standard.set(false, forKey: "Sync")
//                UserDefaults.standard.synchronize()
//            }
//        }
    }
}



































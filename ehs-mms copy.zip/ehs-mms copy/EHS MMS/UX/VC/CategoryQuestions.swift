//
//  CategoryQuestions.swift
//  EHS MMS
//
//  Created by Macbook Pro on 3/7/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import DLRadioButton

class CategoryQuestions: EHSBaseVC, UIPickerViewDelegate, UITextViewDelegate  {
    
    @IBOutlet weak var categoryLabel: UILabel!
    @IBOutlet var sideWidth: NSLayoutConstraint!
    @IBOutlet var addText: UITextView!
    
    @IBOutlet var submitBtn: UIButton!
    @IBOutlet var nextBtn: UIButton!
    @IBOutlet var optionBtn: DLRadioButton!
    
    var categoryText = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        categoryLabel.text = categoryText
        // Do any additional setup after loading the view.
        self.addText.delegate = self
    }
    override func viewWillAppear(_ animated: Bool) {
        // self.navigationItem.title = titleToShow
        if Constants().isPad {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .always
            } else {
                // Fallback on earlier versions
            }
        } else {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .never
            } else {
                // Fallback on earlier versions
            }
        }
        ButtonHelper.setRoundCornerButton(button: nextBtn)
        ButtonHelper.setRoundCornerButton(button: submitBtn)
    }
    override func viewWillDisappear(_ animated: Bool) {
    }
    override func viewWillLayoutSubviews() {
        setSideMenu()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }

    func setSideMenu() {
        if #available(iOS 11.0, *) {
            self.navigationController?.navigationBar.prefersLargeTitles = false
        } else {
            // Fallback on earlier versions
        }
        if UI_USER_INTERFACE_IDIOM() == .pad {
            self.navigationItem.rightBarButtonItem = nil
        } else {
            self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        /*
         if UI_USER_INTERFACE_IDIOM() == .pad {
         if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
         sideWidth.constant = 0
         self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu-button"), style: .plain, target: self, action: #selector(rightReveal))
         } else {
         sideWidth.constant = 250
         navigationItem.rightBarButtonItem = nil
         }
         } else {
         self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu-button"), style: .plain, target: self, action: #selector(rightReveal))
         }
         */
    }
    
    @objc func rightReveal() {
        Constants().actionSheet(view: self, title: "EHS MMS", message: "Perform Actions", mainMenuCompletion: { (main) in
            self.performSegue(withIdentifier: "goToMenu", sender: self)
        }, saveCompletion: { (save) in
            print("save")
        }) { (discard) in
            print("dis")
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        UIView.animate(withDuration: 0.5) {
            self.view.frame.origin.y += 180
        }
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        UIView.animate(withDuration: 0.5) {
            self.view.frame.origin.y -= 180
        }
    }

    // Action
    @IBAction func submitButton(_ sender: Any) {
        let subCat = self.storyboard?.instantiateViewController(withIdentifier: "InspectionSubCategory") as! InspectionSubCategory
        subCat.titleToShow = categoryText
        self.show(subCat, sender: self)
    }
    
    @IBAction func uploadBtn(_ sender: Any) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        
        let actionSheet = UIAlertController(title: "Photo Source", message: "Choose a source", preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action: UIAlertAction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                imagePickerController.sourceType = .camera
                self.present(imagePickerController, animated: true, completion:  nil)
            } else {
                print("Not Available")
            }
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action: UIAlertAction) in
            imagePickerController.sourceType = .photoLibrary
            self.present(imagePickerController, animated: true, completion:  nil)
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
}



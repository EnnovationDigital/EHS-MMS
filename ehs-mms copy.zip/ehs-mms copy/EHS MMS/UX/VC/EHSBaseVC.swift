//
//  EHSBaseVC.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 28/10/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class EHSBaseVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("ServerCall"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(loginPopUp), name: NSNotification.Name("ServerCall"), object: nil)
        
        if Connectivity.isConnectedToInternet {
            print("Connected")
        }
        else {
            print("No Internet")
        }
    }
    
    
    @objc func loginPopUp () {
        
        let alertController = UIAlertController(title: "Login", message: "Your session has expired. Enter your credentials to login again", preferredStyle: .alert)
        
        alertController.addTextField { (textField) in
            textField.placeholder = "Email"
            textField.keyboardType = .emailAddress
        }
        
        alertController.addTextField { (textField) in
            textField.placeholder = "Password"
            textField.isSecureTextEntry = true
        }
        
        let loginAction = UIAlertAction(title: "Login", style: .default) { (_) in
            let emailField = alertController.textFields![0]
            let passwordField = alertController.textFields![1]
            
            //Perform validation or whatever you do want with the text of textfield
            
            if emailField.text == "" && passwordField.text == "" {
                Constants().displayAlert(title: "", message: "Credentials are required", dismiss: "Dismiss", view: self)
            }
            else if emailField.text == "" {
                Constants().displayAlert(title: "Email is empty", message: "Email or username is required", dismiss: "Dismiss", view: self)
            }
            else if passwordField.text == "" {
                Constants().displayAlert(title: "Password is empty", message: "Password is required", dismiss: "Dismiss", view: self)
            }
            else {
                let params = ["username":emailField.text!,"password":passwordField.text!]
                UserDefaults.standard.set(params, forKey: "Credentials")
                EHSUserManager.signInUserWith(credentials: params) { (message, response) in
                    print(response)
                    if message == "FAILED" {
                        Constants().displayAlert(title: "Sign in Failed", message: "Please sign in again.", dismiss: "Ok", view: self)
                    }
                    else {
//                       NetworkManager.con
                    }
                }
            }
            
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(loginAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    
//    func updateUserInterface() {
//        guard let status = Network.reachability?.status else { return }
//        switch status {
//        case .unreachable:
//            UINavigationBar.appearance().backgroundColor = UIColor.lightGray
//            break
//        case .wifi:
//            UINavigationBar.appearance().backgroundColor = UIColor(hexString: "#343399")
//            break
//        case .wwan:
//            // 52,51,153
//            UINavigationBar.appearance().backgroundColor = UIColor(hexString: "#343399")
//            break
//        }
//
//        print("Reachability Summary")
//        print("Status:", status)
//        print("HostName:", Network.reachability?.hostname ?? "nil")
//        print("Reachable:", Network.reachability?.isReachable ?? "nil")
//        print("Wifi:", Network.reachability?.isReachableViaWiFi ?? "nil")
//    }
//
//    @objc func statusManager(_ notification: Notification) {
//        updateUserInterface()
//    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    
    
}

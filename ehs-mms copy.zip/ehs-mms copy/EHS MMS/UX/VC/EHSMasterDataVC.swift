    //
//  EHSMasterDataVC.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 9/5/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class EHSMasterDataVC: EHSBaseVC {

    override func viewDidLoad() {
        super.viewDidLoad()

        fetchMData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // 7AD0BEE9-11DA-432A-9C08-7B25E7A4875B
    
    // FB0C4EB6-5FF1-4FF2-8960-F2EB8740DC13
    
    func fetchMData () {
        
        let deviceType = UI_USER_INTERFACE_IDIOM() == .pad ? "Ipad" : "Iphone"
        var userName = ""
        if UserDefaults.standard.value(forKey: "UserEmailAddress") == nil {
            return
        }
        else {
            userName = UserDefaults.standard.string(forKey: "UserEmailAddress")!
        }
        let params = ["UUIDNumber":UserDefaults.standard.string(forKey: "UUID"),
                      "username":userName,
                      "DeviceType":deviceType]
        
        EHSInspectionManager.fetchMDATA(params:params as! [String : String]) { (message, response) in
            if message == "SUCCESS" {
                //MARK: - Regions
                if let allRegions = response["md_lkp_Region"] as? [String:AnyObject] {
                    md_lkp_Region().saveRegtionsMData(data: allRegions)
                }
                if let allBuildings = response["md_lkp_Buildings"] as? [String:AnyObject] {
                    md_lkp_Buildings().saveBuildingsMDATA(data: allBuildings)
                }
                
                if let allFloors = response["md_lkp_Floors"] as? [String:AnyObject] {
                    md_lkp_Floors().saveFloorsMDATA(data: allFloors)
                }
                
                if let allLocationTypes = response["md_lkp_LocationType"] as? [String:AnyObject] {
                    md_lkp_LocationType().saveLocationTypesMData(data: allLocationTypes)
                }
                
                if let allLocations = response["md_lkp_Locations"] as? [String:AnyObject] {
                    md_lkp_Locations().saveLocationsMDATA(data: allLocations)
                }
                
                if let allDepartments = response["md_lkp_Departments"] as? [String:AnyObject] {
                    md_lkp_Departments().saveDepartmentsMData(data: allDepartments)
                }
                
                if let allUsers = response["md_Users"] as? [String:AnyObject] {
                    md_Users().saveUsersMData(data: allUsers)
                }
                
                if let allUserLocations = response["md_UserLocation"] as? [String:AnyObject] {
                    md_UserLocation().saveUserLocationsMData(data: allUserLocations)
                }
                
                if let allInspections = response["md_lkp_InspectionType"] as? [String:AnyObject] {
                    md_lkp_InspectionType().saveInspectionMData(data: allInspections)
                }
                
                if let allCategories = response["md_lkp_Category"] as? [String:AnyObject] {
                    md_lkp_Category().saveCategoryMData(data: allCategories)
                }
                
                if let allSubCategories = response["md_lkp_SubCategory"] as? [String:AnyObject] {
                    md_lkp_SubCategory().saveSubCategoryMData(data: allSubCategories)
                }
                
                if let allQuestions = response["md_Questions"] as? [String:AnyObject] {
                    md_Questions().saveQuestionsData(data: allQuestions)
                }
                if let allAnswers = response["md_AnswersToQuestions"] as? [String:AnyObject] {
                    md_AnswersToQuestions().saveAnswersData(data: allAnswers)
                }
                if let allAnswerTypes = response["md_lkp_AnswerType"] as? [String:AnyObject] {
                    md_lkp_AnswerType().saveAnswerTypesData(data: allAnswerTypes)
                }
                
                UserDefaults.standard.set(true, forKey: "Sync")
                UserDefaults.standard.synchronize()
                
                
                if UserDefaults.standard.object(forKey: "APNKey") != nil {
                    let params = ["UUIDNumber":UserDefaults.standard.string(forKey: "UUID"),
                                  "DeviceToken":UserDefaults.standard.string(forKey: "APNKey"),
                                  "NotificationsEnabled":"true"]
                    
                    // This should be called After SYNCDATA ---
                    
                    EHSUserManager.updateUserDeviceToken(params: params as! [String : String], completionBlock: { (message, response) in
                        if message == "FAILED" {
                            print("TOKEN FAILED")
                        }
                        else {
                            self.performSegue(withIdentifier: "TO_HOME_VC", sender: nil)
                        }
                    })
                }
                else {
                    self.performSegue(withIdentifier: "TO_HOME_VC", sender: nil)
                }
                
            }
            else {
                UserDefaults.standard.set(false, forKey: "Sync")
                UserDefaults.standard.synchronize()
                
                let alert  = UIAlertController(title: "Data Downloading Failed", message: "Master Data is not downloaded. Please try again later.", preferredStyle: .alert)
                let action = UIAlertAction(title: "Okay", style: .default, handler: { (action) in
                    self.dismiss(animated: true, completion: nil)
                })
                alert.addAction(action)
                self.present(alert, animated: true, completion: nil)
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

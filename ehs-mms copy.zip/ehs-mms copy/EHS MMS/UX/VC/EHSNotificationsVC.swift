//
//  EHSNotificationsVC.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 06/11/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import UserNotifications
import SKActivityIndicatorView

class EHSNotificationsVC: UIViewController {

    @IBOutlet weak var toggle: UISwitch!
    var toggleCheck: Bool = false
    @IBOutlet weak var lblToken: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if (UserDefaults.standard.value(forKey: "APNKey") != nil) {
            lblToken.text = UserDefaults.standard.value(forKey: "APNKey") as? String
            toggle.isOn = true
        }
        else {
            lblToken.text = "No Token"
            toggle.isOn = false
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func toggleAction(_ sender: Any) {
        updateState()
    }
    
    func updateState() {
        var swValue = "true"
        if toggle.isOn {
            UNUserNotificationCenter.current().getNotificationSettings { (settings) in
                guard settings.authorizationStatus == .authorized else { return }
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            }
        } else {
            print("Switch is off")
            swValue = "false"
            UIApplication.shared.unregisterForRemoteNotifications()
        }

        var deviceToken = ""
        
        if let token = UserDefaults.standard.string(forKey: "APNKey") {
            deviceToken = token
        }
        let params = ["UUIDNumber":UserDefaults.standard.string(forKey: "UUID"),
                      "DeviceToken":deviceToken,
                      "NotificationsEnabled":swValue]

        SKActivityIndicator.show("Updating ...", userInteractionStatus: false)
        EHSUserManager.updateUserDeviceToken(params: params as! [String : String], completionBlock: { (message, response) in
            SKActivityIndicator.dismiss()
            if message == "FAILED" {
                print("TOKEN FAILED")
            }
            else {
                print("SUCCESS")
            }
        })
    }

    
    func updateURDT (tokenEnabled:String, deviceToken:String) {
     
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}



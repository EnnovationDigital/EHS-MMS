//
//  EHSPhotoGridVC.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 01/08/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import SKPhotoBrowser

class PhotoGridCell : UICollectionViewCell {
    
    @IBOutlet weak var imgPhoto: UIImageView!
}

class EHSPhotoGridVC: EHSBaseVC {

    @IBOutlet weak var cvPhotos: UICollectionView!
    
    var arrPhotos = [UIImage]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        cvPhotos.delegate = self
        cvPhotos.dataSource = self
        
        cvPhotos.reloadData()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension EHSPhotoGridVC : UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrPhotos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ID_GRID_CELL", for: indexPath) as! PhotoGridCell
        cell.imgPhoto.image = arrPhotos[indexPath.item]
        return cell
    
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if UI_USER_INTERFACE_IDIOM() == .pad {
            return CGSize(width: 200.0, height: 200.0)
        }
        else {            
            return CGSize(width: 140.0, height: 140.0)
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
            var images = [SKPhoto]()
            
            for imgSelected in arrPhotos {
                let photo = SKPhoto.photoWithImage(imgSelected)
                images.append(photo)
            }
            
            // 2. create PhotoBrowser Instance, and present from your viewController.
            let browser = SKPhotoBrowser(photos: images)
            browser.initializePageIndex(0)
            
            //Customisation
            
            /*
             SKPhotoBrowserOptions.displayToolbar = false                              // all tool bar will be hidden
             SKPhotoBrowserOptions.displayCounterLabel = false                         // counter label will be hidden
             SKPhotoBrowserOptions.displayBackAndForwardButton = false                 // back / forward button will be hidden
             SKPhotoBrowserOptions.displayAction = false                               // action button will be hidden
             SKPhotoBrowserOptions.displayHorizontalScrollIndicator = false            // horizontal scroll bar will be hidden
             SKPhotoBrowserOptions.displayVerticalScrollIndicator = false              // vertical scroll bar will be hidden
             */
            
            
            present(browser, animated: true, completion: nil)
            
        
        
    }
    
}














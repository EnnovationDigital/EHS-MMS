//
//  InspectionCategory.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import RealmSwift
import Realm

class InspectionCategory: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var collectionview: UICollectionView!
    @IBOutlet var sideWidth: NSLayoutConstraint!
    
    @IBOutlet weak var collectionViewPadding: NSLayoutConstraint!
    @IBOutlet weak var collectionViewPaddingRight: NSLayoutConstraint!
    
    @IBOutlet weak var menuImage: UIImageView!
    
    var notificationToken : NotificationToken!
    var realm = try! Realm()
    var filteredCategory: Results<md_lkp_Category>?
    var inspectionTypeId : Int = -1
    var titleToShow : String? = ""
    var number : Int = 0
    var inspectionID : String = ""
    var inspectionItemID : Int = 0
    var locationID : Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "back_Btn")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back_Btn")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)

        let nibFile = UINib.init(nibName: "GridCellCustom", bundle: nil)
        collectionview.register(nibFile, forCellWithReuseIdentifier: "GridCellCustom")
        // handleRealmNotification()
        self.title = titleToShow!
        self.filteredCategory = md_lkp_Category.filterCategory(inspectionID: inspectionTypeId)
    }
    override func viewWillAppear(_ animated: Bool) {
        //configureTitleView()
        if Constants().isPad {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .always
            } else {
                // Fallback on earlier versions
            }
        } else {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .never
            } else {
                // Fallback on earlier versions
            }
        }
        collectionview.backgroundColor = UIColor.clear
    }
    override func viewWillDisappear(_ animated : Bool) {
        super.viewWillDisappear(animated)
        
        guard let stack = self.navigationController?.viewControllers else { return }
        //get the mainMenu VC
        let mainVC = stack.last!
        
        // Rearrange your stack
        // self.navigationController?.viewControllers = [mainVC, self]
        // NSLog("\(self.navigationController?.viewControllers = [mainVC, self])")
        
        mainVC.isEditing = false
        print(self.isMovingFromParentViewController)
        
        if self.isMovingFromParentViewController {
            // Your code...
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
//        setSideMenu()
//        self.viewWillTransition(to: CGSize.zero, with: self.transitionCoordinator!)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        setSideMenu()
    }
    
    /*
    override func viewWillDisappear(_ animated: Bool) {
        if (self.isMovingFromParentViewController || self.isBeingDismissed) {
            NSLog("Inspection Category")
        }
    }
     */
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }
    
    func configureTitleView() {
        let tlabel = UILabel()
        tlabel.text = self.title
        tlabel.textColor = UIColor.white
        tlabel.font = UIFont(name: "Helvetica-Bold", size: 15.0)
        tlabel.backgroundColor = UIColor.clear
        tlabel.adjustsFontSizeToFitWidth = true
        tlabel.textAlignment = .center
        self.navigationItem.titleView = tlabel
    }

    func handleRealmNotification() {
        /*
         notificationToken = categories?.observe({ [weak self] (changes) in
         switch changes {
         case .initial:
         // Results are now populated and can be accessed without blocking the UI
         self?.collectionview.reloadData()
         case .update(_, let deletions, let insertions, let modifications):
         // Query results have changed, so apply them to the UITableView
         self?.collectionview.performBatchUpdates({
         self?.collectionview.insertItems(at: insertions.map({ IndexPath(row: $0, section: 0) }))
         self?.collectionview.deleteItems(at: deletions.map({ IndexPath(row: $0, section: 0) }))
         self?.collectionview.reloadItems(at: modifications.map({ IndexPath(row: $0, section: 0) }))
         }, completion: nil)
         case .error(let error):
         // An error occurred while opening the Realm file on the background worker thread
         fatalError("\(error)")
         }
         })
         */
    }
    
    // Side Menu
    func setSideMenu() {
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                sideWidth.constant = 0
                collectionViewPadding.constant = 170
                collectionViewPaddingRight.constant = 170
                menuImage.isHidden = true
                self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
            } else {
                self.navigationItem.rightBarButtonItem = nil
                menuImage.isHidden = false
                sideWidth.constant = 250
                collectionViewPadding.constant = 30
                collectionViewPaddingRight.constant = 30
            }
        } else {
            collectionViewPadding.constant = 0
            collectionViewPaddingRight.constant = 0
            self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
    }
    @objc func rightReveal() {
        Constants().actionSheet(view: self, title: "EHS MMS", message: "Perform Actions", mainMenuCompletion: { (main) in
            self.performSegue(withIdentifier: "goToMenu", sender: self)
        }, saveCompletion: { (save) in
            print("save")
        }) { (discard) in
            print("dis")
        }
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                sideWidth.constant = 0
                collectionViewPadding.constant = 150
                collectionViewPaddingRight.constant = 150
                menuImage.isHidden = true
                self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
            } else {
                    self.navigationItem.rightBarButtonItem = nil
                    sideWidth.constant = 250
                    menuImage.isHidden = false
                    collectionViewPadding.constant = 30
                    collectionViewPaddingRight.constant = 30
            }
        } else {
            collectionViewPadding.constant = 0
            collectionViewPaddingRight.constant = 0
            self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
        self.collectionview.reloadData()
    }
    
    func getCategories(inspectionTypeId: Int) -> Results<md_lkp_Category> {
        let filteredCategories = realm.objects(md_lkp_Category.self).filter("inspectionTypeId == %@", inspectionTypeId)
        print(filteredCategories)
        return filteredCategories
    }
    
    // Actions
    @IBAction func saveAction(_ sender: Any) {
        Constants().displayAlert(title: "Save", message: "Saved Inspection", dismiss: "ok", view: self)
    }
    @IBAction func discardAction(_ sender: Any) {
        Constants().displayAlert(title: "Discard", message: "Are you sure you want to discard?", dismiss: "No", view: self)
    }
    @IBAction func menuAction(_ sender: Any) {
        let vC = self.storyboard?.instantiateViewController(withIdentifier: "EntryView")
        self.show(vC!, sender: self)
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return filteredCategory!.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionview.dequeueReusableCell(withReuseIdentifier: "GridCellCustom", for: indexPath) as! GridCellCustom
        
        cell.label.text = filteredCategory?[indexPath.row].categoryName
        cell.imageView.image = #imageLiteral(resourceName: "category")
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        _ = self.collectionview.cellForItem(at: indexPath) as! GridCellCustom
        
        if realm.objects(md_lkp_SubCategory.self).filter("categoryId == %@", (filteredCategory?[indexPath.row].categoryId)!).count > 0 {
            let subCategory = self.storyboard?.instantiateViewController(withIdentifier: "InspectionSubCategory") as! InspectionSubCategory
            subCategory.titleToShow = filteredCategory?[indexPath.row].categoryName
            //subCategory.number = (filteredCategory?[indexPath.row].categoryId)!
            subCategory.categoryId = (filteredCategory?[indexPath.row].categoryId)!            
            subCategory.inspectionTypeId = self.inspectionTypeId
            subCategory.inspectionID = self.inspectionID
            subCategory.locationID = self.locationID
            self.show(subCategory, sender: self)
        }
        else {
            let questions = self.storyboard?.instantiateViewController(withIdentifier: "QuestionVC") as! QuestionVC
            questions.categoryID = (filteredCategory?[indexPath.row].categoryId)!
            questions.categoryName = (filteredCategory?[indexPath.row].categoryName)!
            questions.inspectionTypeId = self.inspectionTypeId
            questions.inspectionID = self.inspectionID
            questions.locationID = self.locationID
            self.show(questions, sender: self)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if UI_USER_INTERFACE_IDIOM() == .pad {
            return CGSize(width: 200.0, height: 200.0)
        }
        else {
            return CGSize.init(width: collectionview.frame.width/2.5, height: 110)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
      
        if UI_USER_INTERFACE_IDIOM() == .phone {
            return UIEdgeInsets(top: 10, left: 20, bottom: 20, right: 20)
        }
        else {
            return UIEdgeInsets(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        }
        
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
}

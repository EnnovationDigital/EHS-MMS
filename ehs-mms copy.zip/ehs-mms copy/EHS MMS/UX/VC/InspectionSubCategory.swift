//
//  InspectionSubCategory.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import RealmSwift

class InspectionSubCategory: EHSBaseVC {
    
    @IBOutlet weak var collectionview: UICollectionView!
    @IBOutlet var sideWidth: NSLayoutConstraint!
    
    @IBOutlet weak var collectionViewPadding: NSLayoutConstraint!
    @IBOutlet weak var collectionViewPaddingRight: NSLayoutConstraint!
    
    @IBOutlet weak var menuImage: UIImageView!
    
    var inspections : [String]? = [String]()
    
    var notificationToken : NotificationToken!
    var realm = try! Realm()
    var filteredSubCategory: Results<md_lkp_SubCategory>?
    
    var titleToShow : String? = ""
    
    var inspectionTypeId : Int = -1
    var inspectionID : String = ""
    var inspectionItemId : Int = 0
    var locationID : Int = 0
    
    var categoryId : Int = 0
    var prevCategoryId : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "back_Btn")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back_Btn")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)

        
        
        let nibFile = UINib.init(nibName: "GridCellCustom", bundle: nil)
        collectionview.register(nibFile, forCellWithReuseIdentifier: "GridCellCustom")
        self.filteredSubCategory = getSubCategories(categoryId: categoryId)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = titleToShow
        if Constants().isPad {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .always
            } else {
                // Fallback on earlier versions
            }
        } else {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .never
            } else {
                // Fallback on earlier versions
            }
        }
        collectionview.backgroundColor = UIColor.clear
    }
    override func viewWillDisappear(_ animated: Bool) {
        if (self.isMovingFromParentViewController || self.isBeingDismissed) {
            NSLog("Inspection Sub Category")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        setSideMenu()
    }
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }
    
    func setSideMenu() {
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                sideWidth.constant = 0
                collectionViewPadding.constant = 150
                collectionViewPaddingRight.constant = 150
                menuImage.isHidden = true
                self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
            } else {
                sideWidth.constant = 250
                menuImage.isHidden = false
                collectionViewPadding.constant = 30
                collectionViewPaddingRight.constant = 30
                navigationItem.rightBarButtonItem = nil
            }
        } else {
            collectionViewPadding.constant = 0
            collectionViewPaddingRight.constant = 0
            self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
    }
    
    @objc func rightReveal() {
        Constants().actionSheet(view: self, title: "EHS MMS", message: "Perform Actions", mainMenuCompletion: { (main) in
            self.performSegue(withIdentifier: "goToMenu", sender: self)
        }, saveCompletion: { (save) in
            print("save")
        }) { (discard) in
            print("dis")
        }
    }
    
    // Segue
    @IBAction func unwindToSubCat(segue : UIStoryboardSegue) {}
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                sideWidth.constant = 0
                collectionViewPadding.constant = 150
                collectionViewPaddingRight.constant = 150
                menuImage.isHidden = true
                self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
            } else {
                self.navigationItem.rightBarButtonItem = nil
                menuImage.isHidden = false
                sideWidth.constant = 250
                collectionViewPadding.constant = 30
                collectionViewPaddingRight.constant = 30
            }
        } else {
            collectionViewPadding.constant = 0
            collectionViewPaddingRight.constant = 0
            self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
        self.collectionview.reloadData()
    }

    func getSubCategories(categoryId: Int) -> Results<md_lkp_SubCategory>{
        let filteredSubCategories = realm.objects(md_lkp_SubCategory.self).filter("categoryId == %@", categoryId).sorted(byKeyPath: "orderNo", ascending: true)
        print(filteredSubCategories)
        return filteredSubCategories
    }
    
    // Actions
    @IBAction func saveAction(_ sender: Any) {
        Constants().displayAlert(title: "Save", message: "Saved Inspection", dismiss: "ok", view: self)
    }
    @IBAction func discardAction(_ sender: Any) {
        Constants().displayAlert(title: "Discard", message: "Are you sure you want to discard?", dismiss: "No", view: self)
    }
    @IBAction func menuAction(_ sender: Any) {
        let vC = self.storyboard?.instantiateViewController(withIdentifier: "EntryView")
        self.show(vC!, sender: self)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
}

extension InspectionSubCategory: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return filteredSubCategory?.count ?? 0
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionview.dequeueReusableCell(withReuseIdentifier: "GridCellCustom", for: indexPath) as! GridCellCustom
        cell.label.text = filteredSubCategory?[indexPath.row].subCategoryName
        
        cell.imageView.image = #imageLiteral(resourceName: "icon_subcategory")
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let select = self.collectionview.cellForItem(at: indexPath) as! GridCellCustom
        select.imageView.image = #imageLiteral(resourceName: "icon_subcategory")
        
        let questions = self.storyboard?.instantiateViewController(withIdentifier: "QuestionVC") as! QuestionVC
        questions.categoryName = self.titleToShow!
        questions.subCategoryName = (filteredSubCategory?[indexPath.item].subCategoryName)!
        questions.categoryID = categoryId
        questions.subCategoryID = (filteredSubCategory?[indexPath.item].subCategoryId)!
        questions.inspectionTypeId = self.inspectionTypeId
        questions.inspectionID = self.inspectionID
        questions.locationID = self.locationID
        self.show(questions, sender: self)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if UI_USER_INTERFACE_IDIOM() == .pad {
            return CGSize(width: 200.0, height: 200.0)
        }
        else {
            return CGSize.init(width: collectionview.frame.width/2.5, height: 110)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        if UI_USER_INTERFACE_IDIOM() == .phone {
            return UIEdgeInsets(top: 10, left: 20, bottom: 20, right: 20)
        }
        else {
            return UIEdgeInsets(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        }
        
    }
    
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
//        if section == 1 {
//            //80
//            let totalCellWidth = 40 * collectionview.numberOfItems(inSection: 1)
//            let totalSpacingWidth = 10 * (collectionview.numberOfItems(inSection: 1) - 1)
//
//            let leftInset = (collectionview.layer.frame.size.width - CGFloat(totalCellWidth + totalSpacingWidth)) / 2
//            let rightInset = leftInset
//            print("0")
//            return UIEdgeInsetsMake(0, leftInset, 0, rightInset)
//        } else {
//            if self.interfaceOrientation == UIInterfaceOrientation.landscapeLeft || self.interfaceOrientation == UIInterfaceOrientation.landscapeRight || UI_USER_INTERFACE_IDIOM() == .pad {
//                if view.frame.height > view.frame.width {
//                    print("yes")
//                    return UIEdgeInsets.init(top: 10, left: 20, bottom: 50, right: 20)
//                } else {
//                    if (UI_USER_INTERFACE_IDIOM() == .pad) {
//                        print("yes-no iPad")
//                        return UIEdgeInsets.init(top: 10, left: 150, bottom: 50, right: 150)
//                    } else {
//                        print("yes-no iPhone")
//                        return UIEdgeInsets.init(top: 10, left: 120, bottom: 50, right: 120)
//                    }
//                }
//            } else {
//                print("no")
//                return UIEdgeInsets.init(top: 10, left: 20, bottom: 20, right: 20)
//            }
//        }
//    }
    
}

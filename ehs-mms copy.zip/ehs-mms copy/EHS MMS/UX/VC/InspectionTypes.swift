//
//  InspectionTypes.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/20/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import RealmSwift
import Realm

class InspectionTypes: UIViewController {

    @IBOutlet weak var collectionview: UICollectionView!
    @IBOutlet var SideConstraint: NSLayoutConstraint!
    @IBOutlet weak var naviagtionController: UICollectionView!


    @IBOutlet var leadingSideMenuConstraint: NSLayoutConstraint!
    var notificationToken : NotificationToken!
    var realm = try! Realm()
    var inspectionTypes: Results<md_lkp_InspectionType>?
    var inspectionTypes1 = ["Research Labs", "Manufacturing", "Faclities", "Office Safety", "Program Review"]
    var menuShowing = false

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "back_Btn")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back_Btn")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)

        let nibFile = UINib.init(nibName: "GridCell", bundle: nil)
        collectionview.register(nibFile, forCellWithReuseIdentifier: "GridCell")
        inspectionTypes = realm.objects(md_lkp_InspectionType.self)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.title = "Inspection Types"
        if #available(iOS 11.0, *) {
            self.navigationItem.largeTitleDisplayMode = .never
        } else {
            // Fallback on earlier versions
        }
    }
    override func viewWillLayoutSubviews() {
        setSideMenu()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }
    
    // Side Menu
    func setSideMenu() {
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
                self.SideConstraint.constant = 0
            } else {
                self.navigationItem.rightBarButtonItem = nil
                self.SideConstraint.constant = 250
            }
        } else {
            self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
    }
    @objc func rightReveal() {
        Constants().actionSheet(view: self, title: "EHS MMS", message: "Perform Actions", mainMenuCompletion: { (main) in
            self.performSegue(withIdentifier: "goToMenu", sender: self)
        }, saveCompletion: { (save) in
            print("save")
        }) { (discard) in
            print("dis")
        }
    }

    // Rotation
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
                self.SideConstraint.constant = 0
            } else {
                self.navigationItem.rightBarButtonItem = nil
                self.SideConstraint.constant = 250
            }
        } else {
            self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
        self.collectionview.reloadData()
    }

    // Action
    @IBAction func saveAction(_ sender: Any) {
        Constants().displayAlert(title: "Save", message: "Saved Inspection", dismiss: "ok", view: self)
    }

    @IBAction func discardAction(_ sender: Any) {
        Constants().displayAlert(title: "Discard", message: "Are you sure you want to discard?", dismiss: "No", view: self)
    }

    @IBAction func menuAction(_ sender: Any) {
        let vC = self.storyboard?.instantiateViewController(withIdentifier: "EntryView")
        self.show(vC!, sender: self)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension InspectionTypes: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout  {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return inspectionTypes?.count ?? 0
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionview.dequeueReusableCell(withReuseIdentifier: "GridCell", for: indexPath) as! GridCell
        
        cell.label.text = inspectionTypes?[indexPath.row].inspectionTypeName
        cell.label.textColor = UIColor.black
        cell.label.sizeToFit()
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let category = self.storyboard?.instantiateViewController(withIdentifier: "InspectionCategory") as! InspectionCategory
        category.titleToShow = inspectionTypes?[indexPath.row].inspectionTypeName
        category.number = (inspectionTypes?[indexPath.row].inspectionTypeId)!
        self.show(category, sender: self)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if self.interfaceOrientation == UIInterfaceOrientation.landscapeLeft || self.interfaceOrientation == UIInterfaceOrientation.landscapeRight || UI_USER_INTERFACE_IDIOM() == .pad {
            if view.frame.height > view.frame.width {
                print("-50")
                return CGSize.init(width: (collectionview.frame.width/2) - 50, height: (collectionview.frame.width/2) - 100)
            } else {
                if (UI_USER_INTERFACE_IDIOM() == .pad) {
                    print("-100")
                    // return CGSize.init(width: (collectionview.frame.width/2) - 190, height: 150)
                    return CGSize.init(width: (collectionview.frame.width/2) - 230, height: 200)
                } else {
                    return CGSize.init(width: (collectionview.frame.width/2) - 150, height: 150)
                }
            }
        } else {
            return CGSize.init(width: collectionview.frame.width/2.5, height: 110)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if section == 1 {
            //80
            let totalCellWidth = 40 * collectionview.numberOfItems(inSection: 1)
            let totalSpacingWidth = 10 * (collectionview.numberOfItems(inSection: 1) - 1)
            
            let leftInset = (collectionview.layer.frame.size.width - CGFloat(totalCellWidth + totalSpacingWidth)) / 2
            let rightInset = leftInset
            print("0")
            return UIEdgeInsetsMake(0, leftInset, 0, rightInset)
        } else {
            if self.interfaceOrientation == UIInterfaceOrientation.landscapeLeft || self.interfaceOrientation == UIInterfaceOrientation.landscapeRight || UI_USER_INTERFACE_IDIOM() == .pad {
                if view.frame.height > view.frame.width {
                    print("yes")
                    return UIEdgeInsets.init(top: 10, left: 20, bottom: 50, right: 20)
                } else {
                    if (UI_USER_INTERFACE_IDIOM() == .pad) {
                        print("yes-no iPad")
                        return UIEdgeInsets.init(top: 10, left: 150, bottom: 50, right: 150)
                    } else {
                        print("yes-no iPhone")
                        return UIEdgeInsets.init(top: 10, left: 120, bottom: 50, right: 120)
                    }
                }
            } else {
                print("no")
                return UIEdgeInsets.init(top: 10, left: 20, bottom: 20, right: 20)
            }
        }
    }
}

/*
 func handleRealmNotification() {
 notificationToken = inspectionTypes?.observe({ [weak self] (changes) in
 switch changes {
 case .initial:
 // Results are now populated and can be accessed without blocking the UI
 self?.collectionview.reloadData()
 case .update(_, let deletions, let insertions, let modifications):
 // Query results have changed, so apply them to the UITableView
 self?.collectionview.performBatchUpdates({
 self?.collectionview.insertItems(at: insertions.map({ IndexPath(row: $0, section: 0) }))
 self?.collectionview.deleteItems(at: deletions.map({ IndexPath(row: $0, section: 0) }))
 self?.collectionview.reloadItems(at: modifications.map({ IndexPath(row: $0, section: 0) }))
 }, completion: nil)
 // tableView.beginUpdates()
 // tableView.insertRows(at: insertions.map({ IndexPath(row: $0, section: 0) }), with: .automatic)
 // tableView.deleteRows(at: deletions.map({ IndexPath(row: $0, section: 0)}), with: .automatic)
 // tableView.reloadRows(at: modifications.map({ IndexPath(row: $0, section: 0) }), with: .automatic)
 // tableView.endUpdates()
 case .error(let error):
 // An error occurred while opening the Realm file on the background worker thread
 fatalError("\(error)")
 }
 })
 }
 */


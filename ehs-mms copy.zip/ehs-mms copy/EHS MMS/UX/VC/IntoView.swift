//
//  IntoView.swift
//  EHS MMS
//
//  Created by Macbook Pro on 3/7/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class IntoView: EHSBaseVC, UIScrollViewDelegate {
    
    // Outlet
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var startButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        textView.textAlignment = .center
        textView.text = "Depiciting all the functions to be performed in the app"
        textView.textColor = UIColor.black
        self.startButton.layer.cornerRadius = 4.0
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.scrollView.frame = CGRect(x:0, y:0, width:self.view.frame.width, height:self.view.frame.height)
        let scrollViewWidth:CGFloat = self.scrollView.frame.width
        let scrollViewHeight:CGFloat = self.scrollView.frame.height

        
        // 3
        let imgOne = UIImageView(frame: CGRect(x:0,
                                               y:scrollViewHeight/4,
                                               width:scrollViewWidth,
                                               height:scrollViewHeight/2))
        imgOne.image = #imageLiteral(resourceName: "Intro_1")
        imgOne.contentMode = .scaleAspectFit
        let imgTwo = UIImageView(frame: CGRect(x:scrollViewWidth,
                                               y:scrollViewHeight/4,
                                               width:scrollViewWidth,
                                               height:scrollViewHeight/2))
        imgTwo.image = #imageLiteral(resourceName: "Intro_2")
        imgTwo.contentMode = .scaleAspectFit
        
        let imgThree = UIImageView(frame: CGRect(x:scrollViewWidth*2,
                                                 y:scrollViewHeight/4,
                                                 width:scrollViewWidth,
                                                 height:scrollViewHeight/2))
        imgThree.image = #imageLiteral(resourceName: "Intro_4")
        imgThree.contentMode = .scaleAspectFit
        
        let imgFour = UIImageView(frame: CGRect(x:scrollViewWidth*3,
                                                y:scrollViewHeight/4,
                                                width:scrollViewWidth,
                                                height:scrollViewHeight/2))
        imgFour.image = #imageLiteral(resourceName: "Intro_3")
        imgFour.contentMode = .scaleAspectFit
        
        let imgFive = UIImageView(frame: CGRect(x:scrollViewWidth*4,
                                                y:scrollViewHeight/4,
                                                width:scrollViewWidth,
                                                height:scrollViewHeight/2))
        
        imgFive.image = #imageLiteral(resourceName: "Intro_5")
        imgFive.contentMode = .scaleAspectFit
        
        self.scrollView.addSubview(imgOne)
        self.scrollView.addSubview(imgTwo)
        self.scrollView.addSubview(imgThree)
        self.scrollView.addSubview(imgFour)
        self.scrollView.addSubview(imgFive)
        
        // 4
        self.scrollView.contentSize = CGSize(width:self.scrollView.frame.width * 4, height:self.scrollView.frame.height)
        self.scrollView.delegate = self
        self.pageControl.currentPage = 0
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }

    // Actions
    @IBAction func enterBtn(_ sender: Any) {
        let check = UserDefaults.standard.bool(forKey: "UserLoggedIn")
        print(check)
        if  (check == true) {
             let vC = self.storyboard?.instantiateViewController(withIdentifier: "EntryView")
             self.show(vC!, sender: self)
        }
        else {
            let vC = self.storyboard?.instantiateViewController(withIdentifier: "loginView")
            self.show(vC!, sender: self)
        }
        
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView){
        // Test the offset and calculate the current page after scrolling ends
        let pageWidth:CGFloat = scrollView.frame.width
        let currentPage:CGFloat = floor((scrollView.contentOffset.x-pageWidth/2)/pageWidth)+1
        // Change the indicator
        self.pageControl.currentPage = Int(currentPage);
        // Change the text accordingly
        if Int(currentPage) == 0 {
            textView.text = "Depiciting all the functions to be performed in the app"
        } else if Int(currentPage) == 1 {
            textView.text = "Helps you generate a report of your specified inspections"
        } else if Int(currentPage) == 2 {
            textView.text = "Helps you sync your data with the Master server and edit your region"
        }
            // else if Int(currentPage) == 3 {
            // textView.text == "sample"
            // }
        else {
            textView.text = "You can make a new inspection, save data for later or discard the changes you have done :)"
            // Show the "Let's Start" button in the last slide (with a fade in animation)
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                self.startButton.alpha = 1.0
            })
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

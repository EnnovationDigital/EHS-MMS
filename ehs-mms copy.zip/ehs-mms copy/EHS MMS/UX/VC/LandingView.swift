//
//  LandingView.swift
//  EHS MMS
//
//  Created by Macbook Pro on 6/29/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import RealmSwift
import Realm

class LandingView: EHSBaseVC {
    
    @IBOutlet weak var collectionview: UICollectionView!
    
    var initialzeCellNames : [String]? = ["New Inspection", "Manage Inspections", "Settings", "Logout"] //"Recall Inspection",
    var initializeCellImages : [UIImage]? = [#imageLiteral(resourceName: "new_inspection_updated"), #imageLiteral(resourceName: "reports_updated"), #imageLiteral(resourceName: "settings_updated"), #imageLiteral(resourceName: "logout_updated")]     //#imageLiteral(resourceName: "recall_inspection_updated")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let nibFile = UINib.init(nibName: "GridCell", bundle: nil)
        collectionview.register(nibFile, forCellWithReuseIdentifier: "GridCell")
        print(Realm.Configuration.defaultConfiguration.description)
        
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "back_Btn")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back_Btn")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = "Welcome User"
        
        if #available(iOS 11.0, *) {
            navigationController?.navigationBar.prefersLargeTitles = true
        } else {
            // Fallback on earlier versions
        }
        if Constants().isPad {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .always
            } else {
                // Fallback on earlier versions
            }
        }
        collectionview.backgroundColor = .clear
    }
    override func viewWillLayoutSubviews() {
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if (UI_USER_INTERFACE_IDIOM() == .pad) {
            return .allButUpsideDown
        } else {
            return .portrait
        }
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if UI_USER_INTERFACE_IDIOM() == .pad {
            self.collectionview.reloadData()
        } else {
            self.collectionview.reloadData()
        }
    }
    
    func logout() {
        let alert = UIAlertController.init(title: "LogOut?", message: "Are you sure", preferredStyle: .alert)
        let confirm = UIAlertAction.init(title: "LogOut", style: .destructive) { (action) in
            self.initialzeCellNames = nil
            self.initializeCellImages = nil
            UserDefaults.standard.set(false, forKey: "UserLoggedIn") //Bool
            let entry = self.storyboard?.instantiateViewController(withIdentifier: "loginView")
            self.present(entry!, animated: true, completion: nil)
        }
        let cancel = UIAlertAction.init(title: "Cancel", style: .default, handler: nil)
        alert.addAction(confirm)
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension LandingView: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return section == 0 ? 4 : 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let gridCell = collectionview.dequeueReusableCell(withReuseIdentifier: "GridCell", for: indexPath) as! GridCell
        
        if indexPath.section == 0 {
            gridCell.label.text = initialzeCellNames?[indexPath.row]
            gridCell.imageView.image = initializeCellImages?[indexPath.row]
        } else {
            gridCell.label.text = initialzeCellNames?[4]
            gridCell.imageView.image = initializeCellImages?[4]
        }
        return gridCell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                //new inspec
                let new = self.storyboard?.instantiateViewController(withIdentifier: "NewInspec") as! NewInspectionView
                new.isNewInspection = true
                self.show(new, sender: self)
            } else if indexPath.row == 1 {
                // recall inspec
                let recall = self.storyboard?.instantiateViewController(withIdentifier: "ReportVC") as! ReportVC
                self.show(recall, sender: self)
            } else if indexPath.row == 2 {
                // settings
                let setting = self.storyboard?.instantiateViewController(withIdentifier: "Settings")
                self.show(setting!, sender: self)
            }
            else if indexPath.row == 3 {
                // logout
                logout()
            }
            // report
            // let reports = self.storyboard?.instantiateViewController(withIdentifier: "ReportsList") as! ReportsList
            // self.show(reports, sender: self)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if UI_USER_INTERFACE_IDIOM() == .pad {
            return CGSize(width: 175.0, height: 150.0)
        } else {
            return CGSize.init(width: collectionview.frame.width/2.5, height: 110)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
        //40
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
        //20
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if section == 1 {
            //80
            let totalCellWidth = 40 * collectionview.numberOfItems(inSection: 1)
            let totalSpacingWidth = 10 * (collectionview.numberOfItems(inSection: 1) - 1)
            
            let leftInset = (collectionview.layer.frame.size.width - CGFloat(totalCellWidth + totalSpacingWidth)) / 2
            let rightInset = leftInset
            print("0")
            return UIEdgeInsetsMake(0, leftInset, 0, rightInset)
        } else {
            if self.interfaceOrientation == UIInterfaceOrientation.landscapeLeft || self.interfaceOrientation == UIInterfaceOrientation.landscapeRight || UI_USER_INTERFACE_IDIOM() == .pad {
                if view.frame.height > view.frame.width {
                    print("yes")
                    return UIEdgeInsets.init(top: 10, left: 20, bottom: 50, right: 20)
                } else {
                    if (UI_USER_INTERFACE_IDIOM() == .pad) {
                        print("yes-no iPad")
                        return UIEdgeInsets.init(top: 10, left: 150, bottom: 50, right: 150)
                    } else {
                        print("yes-no iPhone")
                        return UIEdgeInsets.init(top: 10, left: 120, bottom: 50, right: 120)
                    }
                }
            } else {
                print("no")
                return UIEdgeInsets.init(top: 10, left: 20, bottom: 20, right: 20)
            }
        }
    }
}

//
//  LaunchVC.swift
//  EHS MMS
//
//  Created by Macbook Pro on 6/22/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class LaunchVC: EHSBaseVC {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let check = UserDefaults.standard.bool(forKey: "UserLoggedIn")
        let sync = UserDefaults.standard.bool(forKey: "Sync")
        let walkthrough = UserDefaults.standard.bool(forKey: "WalkThrough")
        if check && sync {
            if walkthrough {
                let vC = self.storyboard?.instantiateViewController(withIdentifier: "IntoView")
                self.show(vC!, sender: self)
            }
            else {
                self.performSegue(withIdentifier: "TO_HOME_VC", sender: nil)
            }
        }
        else {
            if walkthrough {
                let vC = self.storyboard?.instantiateViewController(withIdentifier: "IntoView")
                self.show(vC!, sender: self)
            }
            else {
                self.performSegue(withIdentifier: "TO_LOGIN_VC", sender: nil)
            }
            
        }
    }
        
//        let check = UserDefaults.standard.bool(forKey: "UserLoggedIn")
        
  
//        if (check == true) { // check want tutorial
//            if (walkthrough == true) {
//                let vC = self.storyboard?.instantiateViewController(withIdentifier: "IntoView")
//                self.show(vC!, sender: self)
//            } else {
//                let vC = self.storyboard?.instantiateViewController(withIdentifier: "EntryView")
//                self.show(vC!, sender: self)
//            }
//        } else {
//            if (walkthrough == true) {
//                let vC = self.storyboard?.instantiateViewController(withIdentifier: "IntoView")
//                self.show(vC!, sender: self)
//            } else {
//                let vC = self.storyboard?.instantiateViewController(withIdentifier: "loginView")
//                self.show(vC!, sender: self)
//            }
//        }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

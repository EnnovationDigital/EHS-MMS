//
//  LoginView.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/19/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import Realm
import RealmSwift
import SkyFloatingLabelTextField
import SKActivityIndicatorView
class LoginView: EHSBaseVC, UITextFieldDelegate {

    // outlets
    @IBOutlet weak var emailField: SkyFloatingLabelTextField!
    @IBOutlet weak var passwordField: SkyFloatingLabelTextField!
    
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var remember: UISwitch!
    
    @IBOutlet weak var userNameView: UIView!
    @IBOutlet weak var passwordView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()        
        emailField.delegate = self
        passwordField.delegate = self
        print(Realm.Configuration.defaultConfiguration.description)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        ButtonHelper.setRoundCornerButton(button: loginButton)
        viewHelper.setBorderToViewWithRoundCorners(view: userNameView, color: UIColor.gray.cgColor)
        viewHelper.setBorderToViewWithRoundCorners(view: passwordView, color: UIColor.gray.cgColor)
    }
    
    override func viewDidAppear(_ animated: Bool) {

//        emailField.text = "asaeed@incytetest.com"
//        passwordField.text = "control1124!@"
        
        if (emailField.text?.count)! > 0 {
            UserDefaults.standard.set(emailField.text, forKey: "UserEmailAddress")
            UserDefaults.standard.synchronize()
        }
    }
    override func viewWillLayoutSubviews() {
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }
    
    // segue
    @IBAction func unwindToLogin(segue : UIStoryboardSegue) { }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        UIView.animate(withDuration: 0.5) {
            self.view.frame.origin.y -= 110
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        UIView.animate(withDuration: 0.5) {
            self.view.frame.origin.y += 110
        }
        
        if textField == emailField {
            UserDefaults.standard.set(textField.text, forKey: "UserEmailAddress")
            UserDefaults.standard.synchronize()
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    // actions
    @IBAction func loginAction(_ sender: Any) {

        if emailField.text == "" && passwordField.text == "" {
            Constants().displayAlert(title: "", message: "Credentials are required", dismiss: "Dismiss", view: self)
        }
        else if emailField.text == "" {
            Constants().displayAlert(title: "Email is empty", message: "Email or username is required", dismiss: "Dismiss", view: self)
        }
        else if passwordField.text == "" {
            Constants().displayAlert(title: "Password is empty", message: "Password is required", dismiss: "Dismiss", view: self)
        }
        else {
            
            let params = ["username":emailField.text!,"password":passwordField.text!]
            UserDefaults.standard.set(params, forKey: "Credentials")
            SKActivityIndicator.show("Signing in...", userInteractionStatus: false)
            EHSUserManager.signInUserWith(credentials: params) { (message, response) in
                SKActivityIndicator.dismiss()
                if message == "FAILED" {
                    Constants().displayAlert(title: "Sign in Failed", message: "Please sign in again.", dismiss: "Ok", view: self)
                }
                else {
                    self.navigateToNextScreen()
//                    if UserDefaults.standard.object(forKey: "APNKey") != nil {
//                        let params = ["UUIDNumber":UUID().uuidString,
//                                      "DeviceToken":UserDefaults.standard.string(forKey: "APNKey"),
//                                      "NotificationsEnabled":"true"]
//
//                        // This should be called After SYNCDATA ---
//
//                        EHSUserManager.updateUserDeviceToken(params: params as! [String : String], completionBlock: { (message, response) in
//                            if message == "FAILED" {
//                                print("TOKEN FAILED")
//                            }
//                            else {
//                                self.navigateToNextScreen()
//                            }
//                        })
//                    }
//                    else {
//                        self.navigateToNextScreen()
//                    }
                }
            }
        }
    }
    
    func navigateToNextScreen () {
        if UserDefaults.standard.bool(forKey: "Sync") == false {
            self.performSegue(withIdentifier: "TO_DATA_VC", sender: nil)
        }
        else {
            self.performSegue(withIdentifier: "TO_HOME_VC", sender: nil)
        }
    }
    
    func login(userName: String?, password: String?) {
        let backendEmail = "admin"
        let backendPassword = "123"
        
        
//        EHSUserManager.signInUserWith(credentials: [:]) { (message, response) in
//
//            if message == "" {
//
//            }
//            else {
//
//            }
//
//        }
        
        if (userName == backendEmail && password == backendPassword) {
            let entry = self.storyboard?.instantiateViewController(withIdentifier: "EntryView")
            self.present(entry!, animated: true, completion: nil)
            UserDefaults.standard.set(true, forKey: "UserLoggedIn") //Bool
        } else {        //"Invalid Email or Password"
            Constants().displayAlert(title: "Try Again", message: ApiErrors.invalidCredentials.rawValue, dismiss: "Ok", view: self)
        }
        
        
        // let creds = SyncCredentials.nickname("KazimAhmad", isAdmin: true)
        // SyncUser.logIn(with: creds, server: RealmConstants.AUTH_URL, onCompletion: { [weak self](user, err) in
        // if let _ = user {
        // let entry = self?.storyboard?.instantiateViewController(withIdentifier: "EntryView")
        // self?.present(entry!, animated: true, completion: nil)
        // } else if let error = err {
        // Constants().displayAlert(title: error.localizedDescription, message: "", dismiss: "Okay", view: self!)
        // fatalError(error.localizedDescription)
        // }
        // })
        // }))
        // let entry = self.storyboard?.instantiateViewController(withIdentifier: "EntryView")
        // self.present(entry!, animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

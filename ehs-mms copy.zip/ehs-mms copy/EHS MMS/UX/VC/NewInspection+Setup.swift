//
//  NewInspection+Setup.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 12/11/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

extension NewInspectionView {

    func setupUI () {
        // Do any additional setup after loading the view.
        checkParentCalling = false
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "back_Btn")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back_Btn")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        
        if self.navigationController != nil {
            self.navigationController?.delegate = self
        } else {
            print("navigation controller does not exist")
        }
        regions = realm.objects(md_lkp_Region.self)
        
        self.inspectionTypes = realm.objects(md_lkp_InspectionType.self)
        
        regionField.inputView = picker
        buildingField.inputView = picker
        floorField.inputView = picker
        locationTypeField.inputView = picker
        locationField.inputView = picker
        inspectionTypeField.inputView = picker
        
        picker.delegate = self
        picker.dataSource = self
        picker.backgroundColor = UIColor.white
        picker.showsSelectionIndicator = true
        
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor(red: 92/255, green: 216/255, blue: 255/255, alpha: 1)
        toolBar.sizeToFit()
        
        // Adding Button ToolBar
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(NewInspectionView.doneClick))
        toolBar.setItems([doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        regionField.inputAccessoryView = toolBar
        buildingField.inputAccessoryView = toolBar
        floorField.inputAccessoryView = toolBar
        locationField.inputAccessoryView = toolBar
        locationTypeField.inputAccessoryView = toolBar
        inspectionTypeField.inputAccessoryView = toolBar

    }
    
    func setupScreenElements () {
        self.title = "Inspection"
        if Constants().isPad {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .always
            } else {
                // Fallback on earlier versions
            }
        } else {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .never
            } else {
                // Fallback on earlier versions
            }
        }
        
        ButtonHelper.setRoundCornerButton(button: nextBtn)
        
        viewHelper.setBorderToView(view: regionView, color: UIColor.gray.cgColor)
        viewHelper.setBorderToView(view: buildingView, color: UIColor.gray.cgColor)
        viewHelper.setBorderToView(view: floorView, color: UIColor.gray.cgColor)
        viewHelper.setBorderToView(view: locationTypeView, color: UIColor.gray.cgColor)
        viewHelper.setBorderToView(view: locationView, color: UIColor.gray.cgColor)
        viewHelper.setBorderToView(view: inspectionTypeView1, color: UIColor.gray.cgColor)
        
        // Check for Default Region
        
        let regionUD = UserDefaults.standard.string(forKey: "defaultRegion")
        if (regionUD != nil ) {
            regionField?.text = regionUD
            let id = md_lkp_Region().getRegionId(regionName: regionUD!)
            getRegionId(regionName: regionField.text!, regionId: id)
        }
        
        if (checkParentCalling == true) {
            
            regionField.isEnabled = false
            buildingField.isEnabled = false
            floorField.isEnabled = false
            locationTypeField.isEnabled = false
            locationField.isEnabled = false
            inspectionTypeField.isEnabled = false
            locationTypeField.isEnabled = false
            
            regionView.backgroundColor = UIColor.lightGray
            buildingView.backgroundColor = UIColor.lightGray
            floorView.backgroundColor = UIColor.lightGray
            locationView.backgroundColor = UIColor.lightGray
            locationTypeView.backgroundColor = UIColor.lightGray
            locationView.backgroundColor = UIColor.lightGray
            inspectionTypeView1.backgroundColor = UIColor.lightGray
        }
    }
    
    //MARK: - Rotate
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        self.navigationItem.leftBarButtonItem = nil
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                //self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
                self.sideWidth.constant = 0
            } else {
                self.navigationItem.rightBarButtonItem = nil
                self.sideWidth.constant = 0
            }
        } else {
            // self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
    }
    func setSideMenu() {
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                //self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
                self.sideWidth.constant = 0
            } else {
                self.navigationItem.rightBarButtonItem = nil
                self.sideWidth.constant = 0
            }
        } else {
            //self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
    }
    @objc func rightReveal() {
        Constants().actionSheet(view: self, title: "EHS MMS", message: "Perform Actions", mainMenuCompletion: { (main) in
            self.performSegue(withIdentifier: "goToMenu", sender: self)
        }, saveCompletion: { (save) in
            print("save")
        }) { (discard) in
            print("dis")
        }
    }
    // MARK: - Touch handler
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    //MARK: -  Date and Time
    func getCurrentDateTime() -> String{
        
        let formatter = DateFormatter()
        formatter.dateFormat = "MM/dd/yy-hh:mm:ssa"
        let date = Date()
        return formatter.string(from:date)
        
    }
    
    func sqlDateString(date:Date) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        var strDate =  dateFormatter.string(from: date)
        strDate = strDate.replacingOccurrences(of: "+0000", with: "Z")
        return strDate
    }

}

////
////  NewInspection.swift
////  EHS MMS
////
////  Created by Macbook Pro on 2/20/18.
////  Copyright © 2018 Macbook Pro. All rights reserved.
////

/*
import UIKit
import RealmSwift
import Realm

class NewInspection: UIViewController, UITableViewDelegate, UITableViewDataSource, CollapsibleTableViewHeaderDelegate, UIPickerViewDelegate, UIPickerViewDataSource {

    // outlet
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet var upperLabel: UILabel!
    @IBOutlet weak var theTextfield: UITextField!
    @IBOutlet var menuButton: UIBarButtonItem!

    var upperText = "Inspection"
    var realm: Realm!
    var sections : [Section] = [Section]()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        upperLabel.text = upperText
        sections = [
            Section(name: "Select Region", items: [
                Regions(value: ["regionName" : "New England (Northeast)"]),
                Regions(value: ["regionName" : "Mid-Atlantic"]),
                Regions(value: ["regionName" : "South"]),
                Regions(value: ["regionName" : "Midwest"]),
                Regions(value: ["regionName" : "Southwest"]),
                Regions(value: ["regionName" : "West"])
                ]),
            Section(name: "Select Building", items: [Building]()),
            Section(name: "Select Floor", items: [Floor]()),
            Section(name: "Select Location", items: [Location]())
        ]
        // try! sections.realm?.write {
        // sections.append(Section.init(value: ["name" : "Select Region", "items" : [Regions]()]))
        // sections.append(Section.init(value: ["name" : "Select Building", "items" : [Building]()]))
        // sections.append(Section.init(value: ["name" : "Select Floor", "items" : [Floor]()]))
        // sections.append(Section.init(value: ["name" : "Select Location", "items" : [Location]()]))
        // }
        setSideMenu()
        tableview.estimatedRowHeight = 44.0
        tableview.rowHeight = UITableViewAutomaticDimension

        //testing
        print (realm)

        let thePicker = UIPickerView()
        theTextfield.inputView = thePicker
        thePicker.delegate = self
    }

    // action
    @IBAction func menuAction(_ sender: Any) {
        Constants().actionSheet(view: self, title: "EHS MMS", message: "Perform Actions", mainMenuCompletion: { (main) in
            self.performSegue(withIdentifier: "goToMenu", sender: self)
        }, saveCompletion: { (save) in
            print("save")
        }) { (discard) in
            print("dis")
        }
    }

    func setSideMenu() {
        self.navigationItem.leftBarButtonItem = nil
        if UI_USER_INTERFACE_IDIOM() == .pad {
            self.navigationItem.rightBarButtonItem = nil
        } else {
            self.navigationItem.rightBarButtonItem = self.menuButton
        }
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if UI_USER_INTERFACE_IDIOM() == .pad {
            self.navigationItem.rightBarButtonItem = nil
        } else {
            self.navigationItem.rightBarButtonItem = menuButton
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        ButtonHelper.setRoundCornerButton(button: nextButton)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewDidDisappear(_ animated: Bool) {
        if self.isMovingFromParentViewController {
            self.sections.removeAll()
            // self.sections = nil
            tableview.reloadData()
        }
    }

    @IBAction func logOutAction(_ sender: Any) {
        performSegue(withIdentifier: "goToMenu", sender: self)
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return (sections[0].items?.count)!
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let item = sections[0].items![row] as! Regions
        return item.regionName
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let item = sections[0].items![row] as! Regions
        theTextfield.text = item.regionName
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[section].collapsed ? 0 : sections[section].items!.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SelectionLists
        // let item = sections[indexPath.section].items![indexPath.row]
        if indexPath.section == 0 {
            let item = sections[indexPath.section].items![indexPath.row] as! Regions
            cell.listLabel.text = item.regionName
        }
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = tableview.dequeueReusableCell(withIdentifier: "header") as! SelectionHeader
        header.selectionLabel.text = sections[section].name
        if section == 0 {
            header.selectionImage.image = #imageLiteral(resourceName: "img_356102")
        } else if section == 1 {
            header.selectionImage.image = #imageLiteral(resourceName: "65999-200")
        } else if section == 2 {
            header.selectionImage.image = #imageLiteral(resourceName: "staircase-icon-87074")
        } else {
            header.selectionImage.image = #imageLiteral(resourceName: "map_marker")
        }
        header.section = section
        header.delegate = self
        return header
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            if self.sections[1].items?.count == 0 {
                // self.sections?[1].items.append(Item(name: "One World Trade Center, New York, N.Y."))
                // self.sections?[1].items.append(Item(name: "Willis Tower, Chicago, III."))
                // self.sections?[1].items.append(Item(name: "432 Park Avenue, New York, N.Y."))
                // self.sections?[1].items.append(Item(name: "Trump International Hotel and Tower, Chicago, III. "))
                self.tableview.reloadData()
            }
        } else if indexPath.section == 1 {
            if self.sections[2].items?.count == 0 {
                // add data
                self.tableview.reloadData()
            }

        } else if indexPath.section == 2 {
            if self.sections[3].items?.count == 0 {
                // add data
                self.tableview.reloadData()
            }
        } else {
            nextButton.alpha = 1.0
            nextButton.isEnabled = true
        }
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44.0
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 1.0
    }

    func toggleSection(_ header: SelectionHeader, section: Int) {
        let collapsed = !sections[section].collapsed
        // Toggle collapse
        sections[section].collapsed = collapsed
        tableview.reloadData()
        // tableview.reloadSections(NSIndexSet(index: section) as IndexSet, with: .automatic)
    }

    /*
     // MARK: - Navigation

     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */

    // action
    @IBAction func nextAction(_ sender: Any) {
        let inspection = self.storyboard?.instantiateViewController(withIdentifier: "inspections")
        // self.revealViewController().pushFrontViewController(inspection!, animated: true)
        // let navController = UINavigationController(rootViewController: inspection!)
        // navController.setViewControllers([inspection!], animated:true)
        // self.revealViewController().setFront(navController, animated: true)
        self.show(inspection!, sender: self)
    }
}
// end of class

class Section : NSObject {
    @objc dynamic var name: String? = ""
    @objc dynamic var items: [Any]?
    @objc dynamic var collapsed: Bool = true

    init(name: String, items: [Any], collapsed: Bool = true) {
        self.name = name
        self.items = items
        self.collapsed = collapsed
    }
}
 */


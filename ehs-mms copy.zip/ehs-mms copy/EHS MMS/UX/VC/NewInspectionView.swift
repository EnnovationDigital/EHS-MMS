//
//  NewInspectionView.swift
//  EHS MMS
//
//  Created by Macbook Pro on 3/16/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import RealmSwift
import Realm
import TPKeyboardAvoiding
import SKActivityIndicatorView
class NewInspectionView: EHSBaseVC, UITextFieldDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var sideWidth: NSLayoutConstraint!
    @IBOutlet weak var InspecLabel: UILabel!
    
    @IBOutlet var regionView: UIView!
    @IBOutlet var buildingView: UIView!
    @IBOutlet var floorView: UIView!
    @IBOutlet var locationTypeView: UIView!
    @IBOutlet var locationView: UIView!
    @IBOutlet var inspectionTypeView1: UIView!
    
    @IBOutlet weak var regionField: UITextField!
    @IBOutlet weak var buildingField: UITextField!
    @IBOutlet weak var floorField: UITextField!
    @IBOutlet weak var locationTypeField: UITextField!
    @IBOutlet weak var locationField: UITextField!
    @IBOutlet weak var inspectionTypeField: UITextField!
    
    var checkParentCalling: Bool?
    var index = 0
    let picker = UIPickerView()
    var realm = try! Realm()
    
    var arrRegion = [md_lkp_Region]()
    var arrBuilding = [md_lkp_Buildings]()
    var arrFloor = [md_lkp_Floors]()
    var arrLocationType = [md_lkp_LocationType]() 
    var arrLocation = [md_lkp_Locations]()
    
    var regions: Results<md_lkp_Region>?
    var buildings: Results<md_lkp_Buildings>?
    var floors: Results<md_lkp_Floors>?
    var locationTypes: Results<md_lkp_LocationType>?
    var locations: Results<md_lkp_Locations>?
    
    var filteredBuildings: Results<md_lkp_Buildings>?
    var filteredFloors: Results<md_lkp_Floors>?
    var filteredLocationTypes: Results<md_lkp_LocationType>?
    var filteredLocations: Results<md_lkp_Locations>?
    
    var inspectionTypes: Results<md_lkp_InspectionType>?
    
    @IBOutlet var nextBtn: UIButton!
    
    var selectedRegionID : Int = -999
    var selectedBuildingID : Int = -999
    var selectedFloorID : Int = -999
    var selectedLocationTypeID : Int = -999
    var selectedLocationID : Int = -999
    var selectedInspectionID : Int = -999
    
    var errorHandle : [String] = ["No Data"]
    var field : UITextField?
    
    var isNewInspection : Bool = false
    
    var valueToBeUpdated : Bool = false
    
    //var upperText : String? = ""
    // var notificationToken : NotificationToken?
    
    //MARK: - ViewLifeCycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UserDefaults.standard.set(-1, forKey: "PrevCateg")
        UserDefaults.standard.set(-1, forKey: "PrevSubCateg")
        UserDefaults.standard.synchronize()
        self.setupUI()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setupScreenElements()
    }
    
    override func viewWillLayoutSubviews() {
        setSideMenu()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - TextFieldHandler
    
    func updateTextFieldsOnValueChange () {
        
        if valueToBeUpdated == true {
            valueToBeUpdated = false
        }
        else {
            return
        }
        
        if (regionField.isFirstResponder) { //(textField == regionField) {
            self.buildingField.text = ""
            self.floorField.text = ""
            self.locationTypeField.text = ""
            self.locationField.text = ""
            self.inspectionTypeField.text = ""
        }
            
        else if (buildingField.isFirstResponder) { //(textField == buildingField) {
            self.floorField.text = ""
            self.locationTypeField.text = ""
            self.locationField.text = ""
            self.inspectionTypeField.text = ""
        }
            
        else if (floorField.isFirstResponder) {  // (textField == floorField) {
            self.locationTypeField.text = ""
            self.locationField.text = ""
            self.inspectionTypeField.text = ""
        }
            
        else if (locationTypeField.isFirstResponder) { // (textField == locationTypeField) {
            self.locationField.text = ""
            self.inspectionTypeField.text = ""
        }
            
        else if (locationField.isFirstResponder) { // (textField == locationField) {
            self.inspectionTypeField.text = ""
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        picker.reloadAllComponents()
        
        if textField.text != nil {
            if textField.text != "-- Select --" && textField.text != "" {
                
                if textField == regionField {
                    let region = getRegionId(regionName: textField.text!, regionId: 1)
                    if (regions?.index(of: region!))! < (regions?.count)! {
                        index = (regions?.index(of: region!))!
                    }
                }
                else if textField == buildingField {
                    let building = getBuildingId(buildingName: textField.text!, buildingList: filteredBuildings)
                    if (filteredBuildings?.index(of: building!))! < ((filteredBuildings?.count))! {
                        index = (filteredBuildings?.index(of: building!))!
                    }
                }
                else if textField == floorField {
                    let floor = getFloorId(floorName: textField.text!, floorList: filteredFloors!)
                    if (filteredFloors?.index(of: floor!))! < (filteredFloors?.count)! {
                        index = (filteredFloors?.index(of: floor!))!
                    }
                    
                }
                else if textField == locationTypeField {
                    let locationType = getLocationTypeId(locationTypeName: textField.text!, locationTypeList: filteredLocationTypes)
                    if (filteredLocationTypes?.index(of: locationType!))! < (filteredLocationTypes?.count)! {
                        index = (filteredLocationTypes?.index(of: locationType!))!
                    }
                }
                else if textField == locationField {
                    let location = getLocationObject(locationName: textField.text!)
                    if (filteredLocations?.index(of: location!))! < (filteredLocations?.count)! {
                        index = (filteredLocations?.index(of: location!))!
                    }
                    
                }
                else if textField == inspectionTypeField {
                    let inspectionType = getInspectionTypeObject(name: textField.text!)
                    if (inspectionTypes?.index(of: inspectionType!))! < (inspectionTypes?.count)! {
                        index = (inspectionTypes?.index(of: inspectionType!))!
                    }
                }
                
                picker.selectRow(index, inComponent: 0, animated: false)
                index = -1
            }
        }
        
        valueToBeUpdated = true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return false
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        picker.reloadAllComponents()
    }
    
    // MARK: - Data Managers
    
    func generateInspectionId() -> String {
        
        _ = sqlDateString(date: Date())
        
        let str = "\(buildingField.text!)-\(locationField.text!)"
        let timeStamp = getCurrentDateTime()
        let id = str + "-" + timeStamp
        return id
    }
    
    // Region Id by Name
    func getRegionId(regionName: String, regionId: Int) -> md_lkp_Region? {   // -> Int
        let filteredRegion = realm.objects(md_lkp_Region.self).filter("regionName == %@", regionName)
        var id = 0
        if (regionName == "-- Select --") {
            // show No Data record
        } else {
            var regionSelected : md_lkp_Region?
            // filtered Object get Id - property
            for region in filteredRegion {
                if (regionName == region.regionName) {
                    id = region.regionId
                    regionSelected = region
                    selectedRegionID = id
                    print(id)
                }
            }
            self.filteredBuildings = getBuildings(regionId: id)
            return regionSelected!
        }
        return nil
    }
    
    // Buildings by region Id
    func getBuildings(regionId: Int) -> Results<md_lkp_Buildings> {
        let filteredBuildings = realm.objects(md_lkp_Buildings.self).filter("regionId == %@ || regionId == -999", regionId)
        return filteredBuildings
    }
    
    // Building Id by buildingName
    func getBuildingId(buildingName: String, buildingList: Results<md_lkp_Buildings>?) -> md_lkp_Buildings? {  // -> Int
        var id = 0
        if (buildingName == "-- Select --") {
            // show No Data record
        } else {
            guard let buidlings = buildingList else { return nil}
            var buildingSelected : md_lkp_Buildings?
            for building in buidlings {
                // check again
                if (buildingName == building.buildingName) {
                    id = building.buildingId
                    selectedBuildingID = id
                    buildingSelected = building
                }
            }
            self.filteredFloors = getFloors(buildingId: id)
            return buildingSelected
        }
        return nil
    }
    
    // Floors by buildingId
    func getFloors(buildingId: Int) -> Results<md_lkp_Floors>?  {
        let filteredFloors: Results<md_lkp_Floors>? = realm.objects(md_lkp_Floors.self).filter("(buildingId == %@  && regionId == %@)|| buildingId == -999", buildingId,selectedRegionID)
        return filteredFloors
    }
    
    // FloorId by floorName
    func getFloorId (floorName: String, floorList: Results<md_lkp_Floors>) -> md_lkp_Floors? {
        var id = 0
        if (floorName == "-- Select --") {
            return nil
        }
        else {
            var floorSelected : md_lkp_Floors?
            for floor in floorList {
                if (floorName == floor.floorName) {
                    id = floor.floorId
                    floorSelected = floor
                    self.selectedFloorID = id
                }
            }
            self.filteredLocationTypes = getLocationTypes()
            return floorSelected
        }
    
    }
    
    // LocationTypes
    func getLocationTypes() -> Results<md_lkp_LocationType>? {
        self.filteredLocationTypes = realm.objects(md_lkp_LocationType.self)        
        return self.filteredLocationTypes ?? nil
    }
    
    // LocaitonTypeId by locationTypeName
    func getLocationTypeId (locationTypeName: String, locationTypeList: Results<md_lkp_LocationType>?) -> md_lkp_LocationType? {
        var id = 0
        if (locationTypeName == "-- Select --") {
            return nil
        } else {
            var locationTypeSelected : md_lkp_LocationType?
            for locationType in locationTypeList! {
                if (locationTypeName == locationType.locationType) {
                    id = locationType.locationTypeId
                    print(id)
                    selectedLocationTypeID = id
                    locationTypeSelected = locationType
                }
            }
            self.filteredLocations = getLocations(floorId: selectedFloorID, locationTypeId: id)
            return locationTypeSelected
        }
    }
    
    // Locations by LocationTypeId
    func getLocations(floorId: Int, locationTypeId: Int) -> Results<md_lkp_Locations>? {
        return realm.objects(md_lkp_Locations.self).filter("(floorId == %@ && locationTypeId == %@ && regionId == %@ && buildingId == %@)  ||  floorId == -999", floorId, locationTypeId, selectedRegionID, selectedBuildingID)
    }
    
    func getLocationObject (locationName : String) -> md_lkp_Locations? {
        if filteredLocations?.count == 0 {
            return nil
        }
        else {
            for location in filteredLocations! {
                if location.locationName == locationName {
                    return location
                }
            }
        }
        return nil
    }
    
    func getInspectionTypeObject(name : String) -> md_lkp_InspectionType? {
        for inspection in inspectionTypes! {
            if inspection.inspectionTypeName == name {
                return inspection
            }
        }
        return nil
    }
    
    //MARK: - Action
    @IBAction func nextAct(_ sender: Any) {
        if ((regionField.text?.isEmpty)! || (buildingField.text?.isEmpty)! || (floorField.text?.isEmpty)! || (locationField.text?.isEmpty)! || (locationTypeField.text?.isEmpty)! ||
            regionField.text == "No Data" || buildingField.text == "No Data" || floorField.text == "No Data" || locationField.text == "No Data" || locationTypeField.text == "No data" || (inspectionTypeField.text?.isEmpty)! ||
            regionField.text == "-- Select --" || buildingField.text == "-- Select --" || floorField.text == "-- Select --" || locationField.text == "-- Select --" || locationTypeField.text == "-- Select --" || inspectionTypeField.text == "-- Select --")
        {
            
            Constants().displayAlert(title: "", message: "Fill all fields", dismiss: "Okay", view: self)
        }
        else {
            
            if isNewInspection == false {
                self.postNewInspection()
            }
            else {
                
                let dictParams = ["LocationId":String(format: "%ld", self.selectedLocationID),
                                  "WorkflowTaskList":"Workflow%20Tasks",
                                  "username":UserDefaults.standard.string(forKey: "UserEmailAddress")]
                SKActivityIndicator.show("Loading ...", userInteractionStatus: false)
                EHSInspectionManager.checkPendingInspections(params: dictParams as! [String : String]) { (message, response) in
                    SKActivityIndicator.dismiss()
                    if message == "SUCCESS" {
                        print(response)
                        let results = response["results"] as! [AnyObject]
                        if results.count > 0 {
                            let result = results[0] as! [String:AnyObject]
                            let pendingReports = Int(result["result"] as! String)
                            if pendingReports! > 0 {
                                let alert = UIAlertController(title: "Reports Pending", message: String(format: "There are %ld reports pending for the selected location", pendingReports!), preferredStyle: .alert)
                                
                                alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: { (action) in
                                    self.postNewInspection()
                                }))
                                self.present(alert, animated: true, completion: nil)
                                return
                            }
                        }
                        self.postNewInspection()
                    }
                }
            }
        }
    }
    
    func postNewInspection () {
        
        
        let category = self.storyboard?.instantiateViewController(withIdentifier: "InspectionCategory") as! InspectionCategory
        category.titleToShow = inspectionTypeField.text
        let id = generateInspectionId()
        
        Form.sharedInstance.regionId = md_lkp_Region().getRegionId(regionName: regionField.text!)
        Form.sharedInstance.buildingId = md_lkp_Buildings().getBuildingId(buildingName: buildingField.text!)
        Form.sharedInstance.floorId = md_lkp_Floors().getFloorId(floorName: floorField.text!)
        Form.sharedInstance.locationTypeId = md_lkp_LocationType().getLoactionTypeName(locationTypeName: locationTypeField.text!)
        Form.sharedInstance.locationId =  md_lkp_Locations().getLocationId(locationName: locationField.text!)
        Form.sharedInstance.insepectionTypeId = md_lkp_InspectionType().getInspectionTypeId(inspectionTypeName: inspectionTypeField.text!)

        category.inspectionTypeId = Form.sharedInstance.insepectionTypeId
        category.inspectionID = id
        if isNewInspection == false {
            self.show(category, sender: self)
            return
        }
        self.checkParentCalling = true
        let inspectionNo = stg_Inspection().autoIncrementId()
        
        let inspection =  stg_Inspection().saveInspection(realm: realm ,
                                                          inspectionId: id,
                                                          inspectionNo: inspectionNo,
                                                          createdBy: "empty",
                                                          createDate: sqlDateString(date: Date()),
                                                          modifiedDate: sqlDateString(date: Date()),
                                                          modifiedBy: "empty",
                                                          isSubmitted: false,
                                                          isSaved: true,
                                                          description_Stg: "Test",
                                                          regionId: Form.sharedInstance.regionId,
                                                          buildingId: Form.sharedInstance.buildingId,
                                                          floorId: Form.sharedInstance.floorId,
                                                          locationTypeId: Form.sharedInstance.locationTypeId,
                                                          locationId: Form.sharedInstance.locationId,
                                                          inspectionTypeId: Form.sharedInstance.insepectionTypeId)
        
        let params = ["InspectionNo":id,
                      "InspectionTypeId":String(format: "%ld",Form.sharedInstance.insepectionTypeId),
                      "RegionId":String(format: "%ld",Form.sharedInstance.regionId),
                      "BuildingId":String(format: "%ld",Form.sharedInstance.buildingId),
                      "FloorId":String(format: "%ld",Form.sharedInstance.floorId),
                      "LocationTypeId":String(format: "%ld",Form.sharedInstance.locationTypeId),
                      "LocationId":String(format: "%ld",Form.sharedInstance.locationId),
                      "IsSaved":"true",
                      "IsSubmitted":"false",
                      "Description":"Test",
                      "MobileCreatedDate":sqlDateString(date: Date())!,
                      "MobileModifiedDate":sqlDateString(date: Date())!]
        
        SKActivityIndicator.show("Loading...", userInteractionStatus: false)
        EHSInspectionManager.createNewInspection(params: params) { (message, response) in
            SKActivityIndicator.dismiss()
            if message == "SUCCESS" {
                let stg_Inspection = response["stg_Inspection"] as? [String : AnyObject]
                if stg_Inspection != nil {
                    if stg_Inspection!["ID"] != nil {
                        let inspectionID = stg_Inspection!["ID"] as! Int
                        let realm = try! Realm()
                        try! realm.write {
                            inspection.inspectionItemId = inspectionID
                        }
                        self.isNewInspection = false
                        category.inspectionItemID = inspectionID
                        category.locationID = self.selectedLocationID
                        self.show(category, sender: self)
                    }
                    else {
                        Constants().displayAlert(title: "Error", message: "Failed to create inspection. Try again", dismiss: "Okay", view: self)
                    }
                }
                else {
                    
                }
            }
            else {
                if message == "NI" {
                    self.show(category, sender: self)
                }
                else {
                    Constants().displayAlert(title: "Error!", message: "Unable to create new inspection. Try again later.", dismiss: "Dismiss", view: self)
                }
            }
        }
    }
    
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    
    // MARK:- Buttons
    
    @objc func doneClick() {

        regionField.resignFirstResponder()
        buildingField.resignFirstResponder()
        floorField.resignFirstResponder()
        locationTypeField.resignFirstResponder()
        locationField.resignFirstResponder()
        inspectionTypeField.resignFirstResponder()
    }
}

extension NewInspectionView:  UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if regionField.isFirstResponder {
            if (regions?.count == 0) {
                return errorHandle.count
            } else {
                return self.regions?.count ?? errorHandle.count
            }
        } else if buildingField.isFirstResponder {
            if (filteredBuildings?.count == 0 || filteredBuildings == nil) {
                return errorHandle.count
            } else {
                return self.filteredBuildings?.count ?? errorHandle.count
            }
        } else if floorField.isFirstResponder {
            if (filteredFloors?.count == 0 || floorField == nil) {
                return errorHandle.count
            } else {
                return self.filteredFloors?.count ?? errorHandle.count
            }
        } else if locationTypeField.isFirstResponder {
            if (filteredLocationTypes?.count == 0 || locationTypeField == nil) {
                return errorHandle.count
            } else {
                return self.filteredLocationTypes?.count ?? errorHandle.count
            }
        } else if locationField.isFirstResponder {
            if (filteredLocations?.count == 0 || filteredLocations == nil) {
                return errorHandle.count
            } else {
                return self.filteredLocations?.count ?? errorHandle.count
            }
        } else if inspectionTypeField.isFirstResponder {
            return self.inspectionTypes?.count ?? 0
        }
        return errorHandle.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if regionField.isFirstResponder {
            return regions?[row].regionName ?? errorHandle[0]
        }
        
        else if buildingField.isFirstResponder {
            if (filteredBuildings?.count == 0 || filteredBuildings == nil){
                return errorHandle[0]
            }
            else {
                return filteredBuildings?[row].buildingName
            }
        }
        
        else if floorField.isFirstResponder {
            if (filteredFloors?.count == 0 || filteredFloors == nil){
                return errorHandle[0]
            } else {
                return filteredFloors?[row].floorName
            }
        }
        else if locationTypeField.isFirstResponder {
            if (filteredLocationTypes?.count == 0 || filteredLocationTypes == nil) {
                return errorHandle[0]
            } else {
                
                return filteredLocationTypes?[row].locationType
            }
        }
        else if locationField.isFirstResponder {
            if (filteredLocations?.count == 0 || filteredLocations == nil) {
                return errorHandle[0]
            } else {
                return filteredLocations?[row].locationName
            }
        }
        else if inspectionTypeField.isFirstResponder {
            return inspectionTypes?[row].inspectionTypeName
        }
        picker.reloadAllComponents()
        return nil
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if index == row {
            return
        }
        let selectTitle = "-- Select --"
        self.updateTextFieldsOnValueChange()
        
        if regionField.isFirstResponder {
            filteredBuildings = nil
            filteredFloors = nil
            filteredLocations = nil
            if self.regions?[row].regionName == selectTitle {
                regionField.text = ""
            }
            else {
                self.regionField.text = self.regions?[row].regionName
                _ = getRegionId(regionName: regionField.text!, regionId: 1)
            }
            
        }
        
        else if buildingField.isFirstResponder {
            if filteredBuildings == nil || filteredBuildings?.count == 1 {
                self.buildingField.text = ""
            }
            filteredFloors = nil
            filteredLocations = nil
            if filteredBuildings?[row].buildingName == selectTitle {
                self.buildingField.text = ""
            }
            else {
                self.buildingField.text = filteredBuildings?[row].buildingName
                _ = getBuildingId(buildingName: buildingField.text!, buildingList: filteredBuildings)
            }
        }
        
        else if floorField.isFirstResponder {
            if (filteredFloors?.count == 1 || filteredFloors == nil) {
                self.floorField.text = ""
            } else {
                filteredLocations = nil
                
                let floor = filteredFloors![row]
                if floor.floorName == selectTitle {
                    self.floorField.text = ""
                }
                else {
                    _ =  getFloorId(floorName: floor.floorName!, floorList: filteredFloors!)
                    self.floorField.text = floor.floorName
                }
            }
        }
        
        else if locationTypeField.isFirstResponder {
            if (filteredLocationTypes?.count == 1 || filteredLocationTypes == nil) {
                self.locationTypeField.text = ""
            } else {
                if filteredLocationTypes?[row].locationType == selectTitle {
                    self.locationTypeField.text = ""
                }
                else {
                    self.locationTypeField.text = filteredLocationTypes?[row].locationType
                    _ =  getLocationTypeId(locationTypeName: locationTypeField.text!, locationTypeList: filteredLocationTypes)
                }
            }
        }
        
        else if locationField.isFirstResponder {
            if (filteredLocations?.count == 1 || filteredLocations == nil) {
                self.locationField.text = ""
            } else {
                if filteredLocations?[row].locationName == selectTitle {
                    self.locationField.text = ""
                }
                else {
                    self.locationField.text = filteredLocations?[row].locationName
                    self.selectedLocationID = (filteredLocations?[row].locationId)!
                }
            }
        }
        
        else if inspectionTypeField.isFirstResponder {
            self.inspectionTypeField.text = inspectionTypes?[row].inspectionTypeName
        }
        
    }
    
}




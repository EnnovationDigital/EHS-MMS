//
//  QuestionVC.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/8/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import Photos
import RealmSwift
import Realm
import BSImagePicker
import SKPhotoBrowser

//MARK: - Delegate

class QuestionVC: EHSBaseVC, UITextViewDelegate, UINavigationControllerDelegate,UIImagePickerControllerDelegate {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var submitBtn: UIButton!
    @IBOutlet weak var footerView: UIView!
    
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var menuImage: UIImageView!
    
    @IBOutlet weak var collectionViewPadding: NSLayoutConstraint!
    @IBOutlet weak var collectionViewPaddingRight: NSLayoutConstraint!
    @IBOutlet weak var sideWidth: NSLayoutConstraint!
    
    var hasAppeared : Bool = false
    
    var categoryID : Int = -1
    var subCategoryID : Int = -1
    
    var prevCategoryID : Int = -1
    var prevSubCategoryID : Int = -1
    
    var inspectionTypeId : Int = -1
    var locationID : Int = 0
    var usersForLocation : Results<md_Users>?
    var realm = try! Realm()
    var inspectionNo : Int = -1
    
    var questionsList: Results<md_Questions>?
    var questionObjects : Results<EHSQuestion>?
    
    var udpateProgress: Float = 0.0
    
    var SelectedAssets = [PHAsset]()
    var PhotoArray = [UIImage]()
    var PhotoNames = [String]()
    var arrPhotosBase64 = [String]()
    
    var lastContentOffset = CGFloat()
    var scrollDir = UISwipeGestureRecognizerDirection.right
    var prevPageNumber : NSInteger = 0
    var arrQuestions : Array = [""]
    var arrQuestionsParsed : NSMutableArray = [""]
    var previousAnswer : String = ""
    var selectedUsers : String = ""
    var shouldSubmit : Bool = false
    
    var offset : CGPoint = .zero
    var isNext : Bool = false
    
    var categoryName : String = ""
    var subCategoryName : String = ""
    
    var inspectionID : String = ""
    var isFromReports : Bool = false
    
    var currentQuestion : EHSQuestion?
    
    var indexOffset : Int = 0
    var indexOffsetPrev : Int = 0
    
    //MARK: - viewLifeCycle
    override func viewDidLoad() {

        super.viewDidLoad()
        self.setupUI()
        
        if UserDefaults.standard.object(forKey: "PrevCateg") != nil {
            prevCategoryID = UserDefaults.standard.integer(forKey: "PrevCateg")
        }
        if UserDefaults.standard.object(forKey: "PrevSubCateg") != nil {
            prevSubCategoryID = UserDefaults.standard.integer(forKey: "PrevSubCateg")
        }
        
        if inspectionNo == -1 {
            inspectionNo = stg_Inspection.lastInspectionId()
        }
        
        
        usersForLocation = md_Users.getAllUserNames(locationID: locationID)
        
        createQuestions()
        
//        collectionView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupNotifications()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        setSideMenu()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        UserDefaults.standard.set(categoryID, forKey: "PrevCateg")
        UserDefaults.standard.set(subCategoryID, forKey: "PrevSubCateg")
        UserDefaults.standard.synchronize()
    }
    // MARK: - Step 1 : CRSIQ
    // MARK: - Create/Submit Questions
    
    func createQuestions() {
        
        if isFromReports == true {
            questionObjects = EHSQuestion.getQuestionForOldInspection(inspectionID: self.inspectionID)
            print(questionObjects)
        }
        else {
            questionsList = md_Questions.getQuestionForInspection(iTypeID: self.inspectionTypeId, categoryID: categoryID, subCategoryID: subCategoryID)
            
            questionObjects = EHSQuestion.getQuestionForInspection(iTypeID: inspectionTypeId, categoryID: categoryID, subCategoryID: subCategoryID,inspectionID:self.inspectionID)
        }
        
        if questionObjects != nil {
            if (questionObjects?.count)! > 0 {
                currentQuestion = questionObjects![0]
                categoryID = (currentQuestion?.categoryId)!
                subCategoryID = (currentQuestion?.subCategoryId)!
            }
            
        }        
        if (categoryID != prevCategoryID || subCategoryID != prevSubCategoryID) && isFromReports == false {
             prepareToPostToSharePoint()
        }
    }
    
    func prepareToPostToSharePoint () {
        createQuestionObjects()
        questionObjects = EHSQuestion.getQuestionForInspection(iTypeID: inspectionTypeId, categoryID: categoryID, subCategoryID: subCategoryID, inspectionID:self.inspectionID)
        print(questionObjects)
        if questionObjects != nil {
            if (questionObjects?.count)! > 0 {
                currentQuestion = questionObjects![0]
            }
        }
        
        for question in questionObjects! {
            var param = ["Skipped": "true",
                         "InspectionTypeId":String(format: "%ld", inspectionTypeId),
                         "InspectionNo":inspectionID,
                         "CategoryId":String(format: "%ld", categoryID),
                         "QuestionId":String(format: "%ld", question.questionId),
                         "AssignToEHS":"false"]
            
            if question.repeatIds != "" {
                param["RepeatId"] = question.repeatIds
            }
            
            if subCategoryID != -1 {
                param["SubCategoryId"] = String(format: "%ld", subCategoryID)
            }
           // postQuestionToSharePoint(params: param )
        }
    }
    
    func postQuestionToSharePoint(params:[String:String]) {
        
        EHSInspectionManager.createCRSIQ(params: params) { (message, response) in
            if message == "SUCCESS" {
                print(response)
                let stg_InspectionQuestions = response["stg_InspectionQuestions"] as! [String : AnyObject]
                let qID = stg_InspectionQuestions["QuestionId"] as! Int
                var repeatID = ""
                if (stg_InspectionQuestions["RepeatId"] as? NSNull) == nil {
                    repeatID = stg_InspectionQuestions["RepeatId"] as! String
                }
                let qItemID = stg_InspectionQuestions["ID"] as! Int
                let question = EHSQuestion.getQuestionFromId(questionId: qID,inspectionId: self.inspectionID, repeatId: repeatID)
                if question != nil {
                    try! self.realm.write {
                        question?.questionItemId = qItemID
                    }
                }
            }
            else {
                // Question not created
            }
        }
    }
    
    // MARK: - Create Question Objects
    func createQuestionObjects () {
        for question in questionsList! {
            var index = 0
            let arrAnswers = md_AnswersToQuestions.getAnswers(questionId: (question.questionId))
            if usersForLocation != nil {
                if question.isReaptable == true {
                    var i = 1
                    for user in usersForLocation! {
                        let assignedUser = String(format: "%ld", user.userId)
                        let repeatId = String(format: "R_%ld", i)
                        print(repeatId)
                        print(assignedUser)
                        i = i + 1
                        EHSQuestion().saveQuestionObject(question: question, answers: arrAnswers, repeats: (usersForLocation?.count)!, inspectionId: inspectionID, status: "NA" , repeatId: repeatId, assignedToId: assignedUser, index: index)
                    }
                }
                else {
                    EHSQuestion().saveQuestionObject(question: question, answers: arrAnswers, repeats: (usersForLocation?.count)!, inspectionId: inspectionID, status: "NA" , repeatId: "", assignedToId: "", index: index)
                }
                
            }
            else {
                EHSQuestion().saveQuestionObject(question: question, answers: arrAnswers, repeats: 0, inspectionId: inspectionID, status: "NA",repeatId: "", assignedToId: "", index: index)
            }
            index = index + 1
        }
    }
    
    func deleteQuestion (qItemId: Int) {
        
        let param = ["itemid" : String(format: "%ld", qItemId)]
        EHSInspectionManager.deleteDRSIQ(params: param) { (message, response) in
            if message == "SUCCESS" {
                
            }
            else {
                
            }
            print(response)
        }
    }
    
    
    //MARK: - fetchNextQuestion
    func fetchNextQuestion (index: Int) {
        
        
        
    }
    
    // MARK: -  Actions
    @IBAction func btnBackTapped(_ sender: Any) {
        saveImagesAndAnswers()
        
        if questionObjects?.count == 0 {
            self.navigationController?.popViewController(animated: true)
            return
        }
        
        nextBtn.isUserInteractionEnabled = true
        nextBtn.alpha = 1.0
        
        isNext = true
        let visibleItems: NSArray = self.collectionView.indexPathsForVisibleItems as NSArray
        let currentItem: IndexPath = visibleItems.object(at: 0) as! IndexPath
        let nextItem: IndexPath?
        if currentItem.item > 0 {
            
            nextItem = IndexPath(item: currentItem.item - 1, section: 0)
            
            var indexOfNextQuestion = (nextItem?.item)! + indexOffset >= 0 ? (nextItem?.item)! + indexOffset : 0
            
            print(currentItem)
            print(indexOfNextQuestion)
            
            if indexOfNextQuestion > 0 {
                currentQuestion = questionObjects![indexOfNextQuestion]
            }
            else {
                currentQuestion = questionObjects?[0]
            }
            
            if currentQuestion?.isReaptable == true {
                if usersForLocation != nil {
                    if (usersForLocation?.count)! > 0 {
                        indexOffset = (usersForLocation?.count)! - 1
                        for i in 0 ... (usersForLocation?.count)! - 1 {
                            let index = indexOfNextQuestion - i
                            if index >= 0 {
                                currentQuestion = questionObjects?[index]
                            }
                        }
                        indexOffset = indexOffset - (usersForLocation?.count)! - 1
                        if indexOffset < 0 {
                            indexOffset = 0
                        }
                    }
                }
            }
            
            if currentQuestion?.isSubQuestion == true {
                if currentQuestion?.status == "D" {
                    currentQuestion = questionObjects![indexOfNextQuestion]
                    while(currentQuestion?.hasSubQuestion == false && indexOfNextQuestion >= 0) {
                        currentQuestion = questionObjects![indexOfNextQuestion]
                        indexOfNextQuestion = indexOfNextQuestion - 1
                        indexOffset = (indexOffset - 1) >= 0 ? indexOffset - 1 : 0
                        if indexOfNextQuestion == 0 {
                            currentQuestion = questionObjects?[0]
                            break
                        }
                    }
                }                
            }

            nextBtn.isUserInteractionEnabled = true
            nextBtn.alpha = 1.0
            
            self.collectionView.scrollToItem(at: nextItem!, at: .right, animated: true)
            self.udpateProgress = Float((nextItem?.row)!)
            progressView.progress = self.udpateProgress
            
        }
        else {
            self.navigationController?.popViewController(animated: true)
        }
        collectionView.reloadData()
    }
    
    @IBAction func nextBtn(_ sender: Any) {
        
        saveImagesAndAnswers()
        
        let visibleItems: NSArray = self.collectionView.indexPathsForVisibleItems as NSArray
        let currentItem: IndexPath = visibleItems.object(at: 0) as! IndexPath
        let nextItem: IndexPath = IndexPath(item: currentItem.item + 1, section: 0)
        
        var indexOfNextQuestion = nextItem.item + indexOffset
        print(nextItem.item)
        print(indexOfNextQuestion)
        isNext = true

        if (indexOfNextQuestion) == (questionObjects?.count)! - 1 {
            print("end")
            nextBtn.isUserInteractionEnabled = false
            nextBtn.alpha = 0.7
            
            return
        }
        else {
            print("Not the end")
            self.collectionView.scrollToItem(at: nextItem, at: .left, animated: true)
            self.udpateProgress = Float(nextItem.row)
            progressView.progress = self.udpateProgress
        }
        
        if currentQuestion?.isReaptable == true {
            if usersForLocation != nil {
                if (usersForLocation?.count)! > 0 {
                    indexOffset = indexOffset + (usersForLocation?.count)! - 1
                    for i in 0 ... (usersForLocation?.count)! - 1 {
                        let index = indexOfNextQuestion + i
                        if index < (questionObjects?.count)! {
                            currentQuestion = questionObjects?[index]
                        }
                    }
                }
            }
        }
        
        else if currentQuestion?.hasSubQuestion == true {
            if currentQuestion?.decisionAnswer != currentQuestion?.answerIds {
                currentQuestion = questionObjects![indexOfNextQuestion]
                while(currentQuestion?.parentQuestionId != -1 && indexOfNextQuestion < (questionObjects?.count)!) {
                    if currentQuestion?.isSubQuestion == true {
                        let realm = try! Realm()
                        try! realm.write {
                            currentQuestion?.status = "D"
                            currentQuestion?.assignedUsers = ""
                            currentQuestion?.answerIds = ""
                            currentQuestion?.textAnswer = ""
                            currentQuestion?.comment = ""
                            currentQuestion?.assignedToEHS = false
                        }
                    }
                    self.deleteQuestion(qItemId: (currentQuestion?.questionItemId)!)
                    indexOfNextQuestion = indexOfNextQuestion + 1
                    indexOffset = indexOffset + 1
                    
                    currentQuestion = questionObjects![indexOfNextQuestion]
                }
            }
            else {
                currentQuestion = questionObjects![indexOfNextQuestion]
            }
            
        }
        else {
            currentQuestion = questionObjects![indexOfNextQuestion]
        }
        
        if currentQuestion?.isSubQuestion == true {
            let realm = try! Realm()
            try! realm.write {
                currentQuestion?.status = "NA"
            }
        }
        
        collectionView.reloadData()
    }
    
    @IBAction func btnSubmitTapped (_ sender : UIButton) {
        
        let alert = UIAlertController(title: "Submit Inspection", message: "Do you want to submit the inspection?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action) in
            self.saveImagesAndAnswers()
            
            
            
            stg_Inspection.saveInspectionWithStatus(inspectionId: self.inspectionNo, status: false)
            stg_Inspection.submitInspectionWithStatus(inspectionId: self.inspectionNo, status: true)
            let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "EntryView")
            self.show(homeVC!, sender: self)
        }))
        
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @objc func didTapUploadButton(_ sender: UIButton) {
        
        
        let actionSheet = UIAlertController(title: "Photo Source", message: "Choose a source", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action: UIAlertAction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                let imagePickerController = UIImagePickerController()
                imagePickerController.delegate = self
                imagePickerController.sourceType = .camera
                self.present(imagePickerController, animated: true, completion:  nil)
            } else {
                print("Not Available")
            }
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action: UIAlertAction) in
//            // create an instance
//            let vc = BSImagePickerViewController()
//
//            //display picture gallery
//            //self.bs_present
//            self.bs_presentImagePickerController(vc, animated: true, select: { (asset: PHAsset) -> Void in
//            }, deselect: { (asset: PHAsset) -> Void in
//                // User deselected an assets.
//            }, cancel: { (assets: [PHAsset]) -> Void in
//                // User cancelled. And this where the assets currently selected.
//            }, finish: { (assets: [PHAsset]) -> Void in
//                // User finished with these assets
//                for i in 0..<assets.count {
//                    self.SelectedAssets.append(assets[i])
//                }
//                self.convertAssetToImages()
//            }, completion: nil)
            
            
                let imagePickerController = UIImagePickerController()
                imagePickerController.delegate = self
                imagePickerController.sourceType = .photoLibrary
                self.present(imagePickerController, animated: true, completion:  nil)
            
        }))
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        
        actionSheet.popoverPresentationController?.sourceView = self.view
        if UI_USER_INTERFACE_IDIOM() == .pad {
            //maxY
            actionSheet.popoverPresentationController?.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            actionSheet.popoverPresentationController?.permittedArrowDirections = []
        } else {
            actionSheet.popoverPresentationController?.sourceRect = self.view.bounds
        }
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    
    //MARK: - UIImagePickerControllerDelegate
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            self.PhotoArray.append(pickedImage)
            if picker.sourceType == .camera {
                UIImageWriteToSavedPhotosAlbum(pickedImage, nil, nil, nil)
            }
            
        }
        //inspectionID-ques
        
        let repeatID = self.currentQuestion?.repeatIds
        let questionId = self.currentQuestion?.questionId
        let index = self.currentQuestion?.index
        var name = ""
        
        if repeatID != "" {
            name = String(format: "%@-%ld-%@-%ld",inspectionID,questionId!,repeatID!,index! )
        }
        else {
            name = String(format: "%@-%ld-%ld",inspectionID,questionId!,index! )
        }
        
        PhotoNames.append(name)
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    //MARK: - Helper Functions
    @objc func userSelected(notif:Notification) {
        
        selectedUsers = notif.userInfo!["users"] as! String
        if selectedUsers == "EHS" {
            let realm = try! Realm()
            try! realm.write {
                currentQuestion?.assignedToEHS = true
                currentQuestion?.assignedUsers = ""
            }
        }
        else {
            if currentQuestion?.isReaptable == true {
                currentQuestion = EHSQuestion.getQuestionForUser(userId: selectedUsers, inspectionId: inspectionID)
            }
            else {
                let realm = try! Realm()
                try! realm.write {
                    currentQuestion?.assignedToEHS = false
                    currentQuestion?.assignedUsers = selectedUsers
                }
            }
        }
        selectedUsers = ""
        self.collectionView.reloadData()
    }
    
    @objc func userAnswered(notif:Notification) {

        previousAnswer = notif.userInfo!["answer"] as! String

        let type = notif.userInfo!["type"] as! String
        
        if type == "T" {
            let realm = try! Realm()
            try! realm.write {
                currentQuestion?.textAnswer = previousAnswer
                currentQuestion?.answerIds = ""
                currentQuestion?.status = "A"
            }
        }
        else {
            let realm = try! Realm()
            try! realm.write {
                currentQuestion?.answerIds = previousAnswer
                currentQuestion?.textAnswer = ""
                currentQuestion?.status = "A"
            }
            
        }
        self.collectionView.reloadData()
    }
    
    func fetchAnswerObjects () -> NSMutableArray {
        let arrAnswers = previousAnswer.components(separatedBy: ",")
        let arrAnswerObjects : NSMutableArray = []
        for ansID in arrAnswers {
            let answer = md_AnswersToQuestions.fetchAnswers(answerId:Int(ansID)!)
            arrAnswerObjects.add(answer!)
        }
        return arrAnswerObjects
    }
    
    func saveAnswerToRealmForQuestion(question: EHSQuestion) {

        previousAnswer = ""
    }
    
    func convertAssetToImages() -> Void {
        if SelectedAssets.count != 0 {
            for i in 0..<SelectedAssets.count{
                let asset = SelectedAssets[i]
                var name = ""
                let repeatID = self.currentQuestion?.repeatIds
                let questionId = self.currentQuestion?.questionId
                let index = self.currentQuestion?.index
                
                if repeatID != "" {
                    name = String(format: "%@-%ld-%@-%ld",inspectionID,questionId!,repeatID!,index! )
                }
                else {
                    name = String(format: "%@-%ld-%ld",inspectionID,questionId!,index! )
                }
                
                PhotoNames.append(name)
                
                
                let manager = PHImageManager.default()
                let option = PHImageRequestOptions()
                var thumbnail = UIImage()
                option.isSynchronous = true
                manager.requestImage(for: asset, targetSize: CGSize(width: 200, height: 200), contentMode: .aspectFill, options: option, resultHandler: {(result, info)->Void in
                    thumbnail = result!
                })
                let data = UIImageJPEGRepresentation(thumbnail, 0.7)
                let newImage = UIImage(data: data!)
                self.PhotoArray.append(newImage! as UIImage)
            }
            
        }
        print("complete photo array \(self.PhotoArray)")
    }
    
    //MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "TO_PREVIEW_VC" {
            let gridVC = segue.destination as! EHSPhotoGridVC
            gridVC.arrPhotos = self.PhotoArray
        }
    }
}


// MARK: - QuestionCellDelegate

extension QuestionVC : QuestionCellDelegate {
    
    @objc func btnPreviewTapped(_ sender:UIButton) {
        if PhotoArray.count == 0 {
            let alert = UIAlertController(title: "", message: "No images attached", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Okay", style: .cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else {
            self.performSegue(withIdentifier: "TO_PREVIEW_VC", sender: nil)
        }        
    }
    
    @objc func btnUploadPictureTapped(_ sender : UIButton) {
        self.didTapUploadButton(sender)
    }
    
}





















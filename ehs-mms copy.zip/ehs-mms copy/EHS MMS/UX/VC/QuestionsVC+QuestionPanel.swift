//
//  QuestionsVC+QuestionPanel.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 13/11/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

// MARK: - Extension
// MARK: - CollectionViewMethods
// MARK: - CollectionView in CollectionView Cell ----

extension QuestionVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return hasAppeared == true ? 1 : 0
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return hasAppeared == true ? questionObjects!.count : 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        //currentQuestion  = questionObjects![indexPath.item]
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "QCell", for: indexPath) as! QuestionCell
        
        cell.locationID = self.locationID
        cell.usersForLocation = self.usersForLocation
        cell.inspectionID = self.inspectionID
        cell.commentTextView.delegate = self
        
        cell.uploadBtn.addTarget(self, action: #selector(btnUploadPictureTapped(_:)), for: UIControlEvents.touchUpInside)
        cell.previewBtn.addTarget(self, action: #selector(btnPreviewTapped(_:)), for: UIControlEvents.touchUpInside)
        
        cell.configureCell(questionObject: currentQuestion!)
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIApplication.shared.statusBarOrientation == .landscapeLeft || UIApplication.shared.statusBarOrientation == .landscapeRight {
                return CGSize.init(width: (collectionView.frame.width) - 50 , height: (collectionView.frame.height) - 50)
            }
            else {
                return CGSize(width: UIScreen.main.bounds.size.width * 0.95 , height: (collectionView.frame.height) - 10)
            }
        }
        else {
            return CGSize.init(width: (collectionView.frame.width) - 10, height: (collectionView.frame.height) - 30)
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        if UIApplication.shared.statusBarOrientation == .landscapeLeft || UIApplication.shared.statusBarOrientation == .landscapeRight || UI_USER_INTERFACE_IDIOM() == .pad {
            if view.frame.height > view.frame.width {
                return UIEdgeInsets.init(top: 20, left: 10, bottom: 10, right: 10)
            }
            else {
                if (UI_USER_INTERFACE_IDIOM() == .pad) {
                    if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                        print("yes-no iPad")
                        return UIEdgeInsets.init(top: 20, left: 100, bottom: 10, right: 30)
                    } else {
                        return UIEdgeInsets.init(top: 20, left: 60 , bottom: 10, right: 40)
                    }
                } else {
                    print("yes-no iPhone")
                    return UIEdgeInsets.init(top: 20, left: 10, bottom: 10, right: 10)
                }
            }
        } else {
            print("no")
            return UIEdgeInsets.init(top: 10, left: 5, bottom: 10, right: 10)
        }
    }
    
    func currentPageNumber () -> Int {
        
        let pageNumber = NSInteger(self.collectionView.contentOffset.x / UIScreen.main.bounds.size.width)
        return pageNumber
        
    }
    
    func saveImagesAndAnswers () {
        
        let questions = EHSQuestion.getQuestions(questionId: (currentQuestion?.questionId)!, inspectionId: self.inspectionID)
        
        for question in questions! {
            var params = ["itemid":String(format: "%ld", question.questionItemId),
                          "InspectionTypeId":String(format: "%ld", self.inspectionTypeId),
                          "CategoryId":String(format: "%ld", self.categoryID),
                          "AssignToEHS":selectedUsers == "EHS" ? "true":"false"]
            
            if currentQuestion?.answerIds == "" && currentQuestion?.textAnswer == "" {
                params["Skipped"] = "true"
            }
            else {
                params["Skipped"] = "false"
            }
            if subCategoryID != -1 {
                params["SubCategoryId"] = String(format: "%ld", subCategoryID)
            }
            if question.parentQuestionId != -1 {
                //Sub-Question
            }
            if question.answerIds != "" {
                params["AnswerId"] = question.answerIds
            }
            if question.comment != "" {
                params["Comments"] = question.comment
            }
            if question.textAnswer != "" {
                params["AnswerInText"] = question.textAnswer
            }
            
            if question.assignedUsers != "" {
                params["AssignedToId"] = question.assignedUsers
            }
            
            if question.isReaptable == true {
                params["RepeatId"] = question.repeatIds
            }

            print (params)
            
            EHSInspectionManager.updateQuestion(params: params) { (message, response) in
                if message == "SUCCESS" {
                    self.saveAnswerToRealmForQuestion(question: question)
                }
                else {
                    if (message == "NI") {
                        self.saveAnswerToRealmForQuestion(question: question)
                    }
                    else {
                        Constants().displayAlert(title: "Error", message: "Unable to save questions", dismiss: "Dismiss", view: self)
                    }
                }
            }
        }
//
        let pageNumber = currentPageNumber()
//        let question  = questionObjects![pageNumber]
//        let prevQuestion = questionObjects![prevPageNumber]
//
//        if previousAnswer.count > 0 {
//
//        }
        
        if PhotoNames.count > 0 {
            let questionID = currentQuestion?.questionId
            for i in 0 ... PhotoArray.count - 1 {
                if stg_InspectionQuestionsPicture.getPicturesByName(imageName: PhotoNames[i]) == nil {
                    let image = PhotoArray[i]
                    let name = PhotoNames[i]
                    let inspectionNo = stg_InspectionQuestionsPicture().autoIncrementId()
                    NetworkManager().uploadImage(imgData: UIImageJPEGRepresentation(image, 0.2)! , imgName: name, endPoint: API.API_SUBMIT_PICTURE_CODE) { (message, response) in
                        if message == "SUCCESS" {
                            let stg_InspectionQuestionsPicture = response["stg_InspectionQuestionsPicture"] as! [String: AnyObject]
                            let id = stg_InspectionQuestionsPicture["ID"] as! String
                            let params = ["itemid": id,
                                          "InspectionNo":self.inspectionID,
                                          "QuestionId":String(format: "%ld", questionID!)]
                            EHSInspectionManager.updateImage(params: params, completionBlock: { (message, response) in
                                if message == "SUCCESS" {
                                    
                                }
                                else {
                                    
                                }
                            })
                        }
                        else {
                            print("hello world")
                        }
                        self.PhotoNames.removeAll()
                        self.PhotoArray.removeAll()
                    }

//                    stg_InspectionQuestionsPicture().saveInspectionQuestionsPicture(realm: realm,
//                                                                                    inspectionQuestionPictureId: inspectionNo,
//                                                                                    inspectionId: prevQuestion.inspectionId,
//                                                                                    questionId: prevQuestion.questionId,
//                                                                                    answerId: prevQuestion.answerTypeId,
//                                                                                    picture: image.base64(format: .jpeg(0.7)),
//                                                                                    repeatId: "",
//                                                                                    name: name)
                }
            }
        }
        else {
            PhotoNames.removeAll()
            PhotoArray.removeAll()
        }
        
        
        
        
//        if stg_InspectionQuestionsPicture.getPictures(questionId: question.questionId) != nil {
//            let arrBase64 = stg_InspectionQuestionsPicture.getPictures(questionId: question.questionId)
//            for obj in arrBase64! {
//                if obj.picture != nil {
//                    let image = obj.picture?.base64ToImage()
//                    if image != nil {
//                        self.PhotoArray.append(image!)
//                        self.PhotoNames.append(obj.name!)
//                    }
//                }
//            }
//        }
        prevPageNumber = NSInteger(pageNumber)
    }
    
    //MARK: - ScrollViewDelegates
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        offset = scrollView.contentOffset
    }
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        isNext = false
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if scrollView.contentOffset.x >= offset.x && isNext == false {
            scrollView.contentOffset = CGPoint(x: collectionView.frame.size.width * CGFloat(currentPageNumber()), y: offset.y)
        }
        else {
            offset = scrollView.contentOffset
        }
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        scrollView.contentOffset = CGPoint(x: collectionView.frame.size.width * CGFloat(currentPageNumber()), y: offset.y)
        CATransaction.commit()
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
    }
    
}

//
//  QuestionsVC+UI.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 12/11/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

extension QuestionVC {
    
    func setupUI () {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "back_Btn")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back_Btn")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        
        let nibFile = UINib.init(nibName: "QuestionCell", bundle: nil)
        self.collectionView.register(nibFile, forCellWithReuseIdentifier: "QCell")
        
        self.collectionView.isPagingEnabled = true
        progressView.setProgress(0, animated: true)
        
        self.hasAppeared = true
        
        self.title = "Questions"
        if Constants().isPad {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .always
            } else {
                // Fallback on earlier versions
            }
            ButtonHelper.setRoundCornerButton(button: nextBtn, cornerRadius: 30.0)
            ButtonHelper.setRoundCornerButton(button: submitBtn, cornerRadius: 30.0)
        } else {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .never
            } else {
                // Fallback on earlier versions
            }
            ButtonHelper.setRoundCornerButton(button: nextBtn, cornerRadius: 20.0)
            ButtonHelper.setRoundCornerButton(button: submitBtn, cornerRadius: 20.0)
        }
    }
    
    func setupNotifications () {
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("userAnswered"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(userAnswered(notif:)), name: NSNotification.Name("userAnswered"), object: nil)
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("userSelected"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(userSelected(notif:)), name: NSNotification.Name("userSelected"), object: nil)
    }
    
    // MARK :- Rotation
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                sideWidth.constant = 0
                menuImage.isHidden = true
                self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
            }
            else {
                self.navigationItem.rightBarButtonItem = nil
                sideWidth.constant = 250
                menuImage.isHidden = false
                collectionViewPadding.constant = 30
                collectionViewPaddingRight.constant = 30
            }
        }
        else {
            collectionViewPadding.constant = 0
            collectionViewPaddingRight.constant = 0
            self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
        
        self.collectionView.reloadData()
    }
    
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }
    
    // MARK: - Side Menu
    func setSideMenu() {
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                sideWidth.constant = 0
                menuImage.isHidden = true
                self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
            }
            else {
                self.navigationItem.rightBarButtonItem = nil
                menuImage.isHidden = false
                sideWidth.constant = 250
                collectionViewPadding.constant = 30
                collectionViewPaddingRight.constant = 30
            }
        }
        else {
            collectionViewPadding.constant = 0
            collectionViewPaddingRight.constant = 0
            self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
    }
    
    @objc func rightReveal() {
        
        let actionSheet = UIAlertController(title: "EHS MMS", message: "Perform Actions", preferredStyle: .actionSheet)
        
        if self.subCategoryName.count > 0 {
            actionSheet.addAction(UIAlertAction(title: subCategoryName, style: .default) { (action) in
                self.navigationController?.popViewController(animated: true)
            })
        }
        
        if self.categoryName.count > 0 {
            actionSheet.addAction(UIAlertAction(title: categoryName, style: .default) { (action) in
                if self.navigationController != nil {
                    let childControllers = self.navigationController?.childViewControllers
                    for vc in childControllers! {
                        if vc.isKind(of: InspectionCategory.self) {
                            self.navigationController?.popToViewController(vc, animated: true)
                            break
                        }
                    }
                }
            })
        }
        if isFromReports == true {
            actionSheet.addAction(UIAlertAction(title: "Manage Inspections", style: .default) { (action) in
                self.navigationController?.popViewController(animated: true)
            })
        }
        actionSheet.addAction(UIAlertAction(title: "Save", style: .default) { (action) in
            let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "EntryView")
            self.show(homeVC!, sender: self)
//            var params = ["InspectionNo":self.inspectionID,
//                          "CategoryId":currentQuestion?.categoryId,
//                          "TotalQuestions":String(format: "%ld",(self.questionObjects?.count)!),
//                          "TotalAnswered":String(format: "%ld","1"),
//                          "IsCompleted":"false"]
//            
//            if self.subCategoryID != -1 {
//                params["SubCategoryId"]  = currentQuestion?.subCategoryId
//            }
//            
//            EHSInspectionManager.createCRSIP(params: params, completionBlock: { (message, response) in
//                
//                if message == "SUCCESS" {
//                    stg_Inspection.saveInspectionWithStatus(inspectionId: self.inspectionNo, status: true)
//                    stg_Inspection.submitInspectionWithStatus(inspectionId: self.inspectionNo, status: false)
//                    self.saveImagesAndAnswers()
//                    Constants().displayAlert(title: "Save", message: "Saved Inspection", dismiss: "Ok", view: self)
//                }
//                else {
//                    if (message == "NI") {
//                        stg_Inspection.saveInspectionWithStatus(inspectionId: self.inspectionNo, status: true)
//                        stg_Inspection.submitInspectionWithStatus(inspectionId: self.inspectionNo, status: false)
//                        self.saveImagesAndAnswers()
//                        Constants().displayAlert(title: "Save", message: "Saved Inspection.", dismiss: "Ok", view: self)
//                    }
//                    else {
//                        Constants().displayAlert(title: "Save Failed", message: "Unable to save inspection ticket. Please try again.", dismiss: "Ok", view: self)
//                    }
//                    
//                }
//            })
        })
        
        actionSheet.addAction(UIAlertAction(title: "Discard", style: .default) { (action) in
            Constants().displayAlert(title: "Discard", message: "Are you sure you want to discard?", dismiss: "No", view: self)
        })
        actionSheet.addAction(UIAlertAction(title: "Main Menu", style: .default) { (action) in
            let inspection = self.storyboard?.instantiateViewController(withIdentifier: "EntryView")
            self.show(inspection!, sender: self)
        })
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel) { (action) in
            
        })
        
        actionSheet.popoverPresentationController?.sourceView = self.view
        if UI_USER_INTERFACE_IDIOM() == .pad {
            actionSheet.popoverPresentationController?.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            actionSheet.popoverPresentationController?.permittedArrowDirections = []
        } else {
            actionSheet.popoverPresentationController?.sourceRect = self.view.bounds
        }
        self.present(actionSheet, animated: true, completion: nil)
    }
}


//MARK: - TextFieldDelegate

extension QuestionVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true;
    }
    
    
}


//
//  RecallList.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/8/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import RealmSwift
import Realm
import SKActivityIndicatorView
class ReportVC: EHSBaseVC {
    
    @IBOutlet weak var tableView: UITableView!
    
    var realm = try! Realm()
    var recallList: Results<stg_Inspection>?
    
    var errorHandle : [String] = ["No Data"]
    
   // let sampleData  = ["1801-V301-06/-07/18-03:03", "1801-V306-06/-07/18-04:23", "1801-V307-07/-07/18-10:53", "1801-V308-07/-07/18-03:03"]
    //"lastUpdated": ["12-June-18","12-June-18","12-June-18","12-June-18"],"status": ["Step 1-20", "Step 4-20", "Step 5-20", "Step 18-20"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "back_Btn")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back_Btn")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)

        let nibFile = UINib.init(nibName: "RecallCell", bundle: nil)
        tableView.register(nibFile, forCellReuseIdentifier: "RecallCell")
        
        recallList = stg_Inspection.unsubmittedReports()
    }
    override func viewWillAppear(_ animated: Bool) {
        self.title = "Non-Submitted Tickets"
        tableView.backgroundColor = UIColor.clear
        self.tableView.estimatedRowHeight = 40
        self.tableView.tableFooterView = UIView(frame: .zero)
        self.tableView.rowHeight = UITableViewAutomaticDimension
        if Constants().isPad {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .always
            } else {
                // Fallback on earlier versions
            }
        } else {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .never
            } else {
                // Fallback on earlier versions
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension ReportVC: UITableViewDelegate, UITableViewDataSource { //UICollectionViewDelegateFlowLayout {
 
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recallList?.count ?? errorHandle.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RecallCell", for: indexPath) as! RecallCell
        
        // let formattedString = NSMutableAttributedString()
        // formattedString.bold("Ticket Id: ").normal("\(recallList![indexPath.row].inspectionId!)")
        
        cell.ticketId.text = "Ticket Id: \(recallList![indexPath.row].inspectionId!)"
        cell.lastUpdated?.text = "Last Updated: "
        cell.status?.text = ""
        return cell
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt: IndexPath) -> [UITableViewRowAction]? {
        let edit = UITableViewRowAction(style: .normal, title: "Edit") { action, index in
            let inspection = self.recallList![editActionsForRowAt.row]
            let questionVC = self.storyboard?.instantiateViewController(withIdentifier: "QuestionVC") as! QuestionVC
            questionVC.inspectionNo = inspection.inspectionNo
            questionVC.isFromReports = true
            self.show(questionVC, sender: nil)
        }
        edit.backgroundColor = .blue
        
        let delete = UITableViewRowAction(style: .normal, title: "Delete") { action, index in
            
            let alert = UIAlertController(title: "Delete Inspection?", message: "Are you sure you want to delete the inspection?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action) in
                
                
                let inspectionToDelete = self.recallList![editActionsForRowAt.row]
                SKActivityIndicator.show("Deleting...", userInteractionStatus: false)
                EHSInspectionManager.deleteInspection(inspectionID: inspectionToDelete.inspectionId!, completionBlock: { (message, response) in
                    SKActivityIndicator.dismiss()
                    if message == "SUCCESS" {
                        try! self.realm.write {
                            self.realm.delete(inspectionToDelete)
                            self.recallList = stg_Inspection.unsubmittedReports()
                            tableView.reloadData()
                        }
                    }
                    
                })
                
                
            }))
            
            self.present(alert, animated: true, completion: nil)
        }
        delete.backgroundColor = .red
        return [delete, edit]
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let inspection = recallList![indexPath.row]
        
        let questionVC = self.storyboard?.instantiateViewController(withIdentifier: "QuestionVC") as! QuestionVC
        
        questionVC.inspectionID = inspection.inspectionId!
        questionVC.inspectionNo = inspection.inspectionNo
        questionVC.inspectionTypeId = inspection.inspectionTypeId
        questionVC.locationID = inspection.locationId
        
        questionVC.isFromReports = true
        self.show(questionVC, sender: nil)
    }
}

//
//  SelectionHeader.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/20/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

protocol CollapsibleTableViewHeaderDelegate : class {
    func toggleSection(_ header: SelectionHeader, section: Int)
}

class SelectionHeader: UITableViewCell {

    // outlet
    @IBOutlet weak var selectionImage: UIImageView!
    @IBOutlet weak var selectionLabel: UILabel!

    weak var delegate: CollapsibleTableViewHeaderDelegate?
    var section: Int = 0

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(SelectionHeader.tapHeader(_:))))
    }
    
    // gesture
    @objc func tapHeader(_ gestureRecognizer: UITapGestureRecognizer) {
        guard let cell = gestureRecognizer.view as? SelectionHeader else {
            return
        }
        delegate?.toggleSection(self, section: cell.section)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

}

//
//  SelectionLists.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/20/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class SelectionLists: UITableViewCell {

    @IBOutlet weak var listLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }


    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  Settings.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/20/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class Settings: EHSBaseVC {
    
    @IBOutlet weak var collectionview: UICollectionView!
    
    var initialzeCellNames : [String]? = ["Sync Master Data", "Sync non-submited Data", "Notification", "Default Region", "Tutorial"] //"Settings"
    var initializeCellImages : [UIImage]? = [#imageLiteral(resourceName: "sync non submitted data"), #imageLiteral(resourceName: "sync master data"), #imageLiteral(resourceName: "user_guide"), #imageLiteral(resourceName: "select_region"), #imageLiteral(resourceName: "user_guide")] //#imageLiteral(resourceName: "settings_updated")
    
    @IBOutlet weak var collectionViewPadding: NSLayoutConstraint!
    @IBOutlet weak var collectionViewPaddingRight: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "back_Btn")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back_Btn")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        
        // Do any additional setup after loading the view.
        let nibFile = UINib.init(nibName: "GridCell", bundle: nil)
        collectionview.register(nibFile, forCellWithReuseIdentifier: "GridCell")
        collectionview.delegate = self
        collectionview.dataSource = self
    }
    override func viewWillAppear(_ animated: Bool) {
        self.title = "Settings"
        if Constants().isPad {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .always
            } else {
                // Fallback on earlier versions
            }
        } else {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .never
            } else {
                // Fallback on earlier versions
            }
        }
        collectionview.backgroundColor = UIColor.clear
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override var shouldAutorotate: Bool {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        self.collectionview.reloadData()
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                collectionViewPadding.constant = 150
                collectionViewPaddingRight.constant = 150
                //self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
            } else {
                self.navigationItem.rightBarButtonItem = nil
                collectionViewPadding.constant = 30
                collectionViewPaddingRight.constant = 30
            }
        } else {
            collectionViewPadding.constant = 0
            collectionViewPaddingRight.constant = 0
            //self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: #imageLiteral(resourceName: "menu_updated"), style: .plain, target: self, action: #selector(rightReveal))
        }
        self.collectionview.reloadData()
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
}

extension Settings: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return initialzeCellNames?.count ?? 0
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let gridCell = collectionview.dequeueReusableCell(withReuseIdentifier: "GridCell", for: indexPath) as! GridCell
        gridCell.label.text = initialzeCellNames?[indexPath.row]
        gridCell.imageView.image = initializeCellImages?[indexPath.row]
        return gridCell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            // sync master
            let progressVC = self.storyboard?.instantiateViewController(withIdentifier: "ProgressVC") as! ProgressVC
            progressVC.caller = "Sync Master Data"
            self.show(progressVC, sender: self)
        } else if indexPath.row == 1 {
            // sync unsaved
            let progressVC = self.storyboard?.instantiateViewController(withIdentifier: "ProgressVC") as! ProgressVC
            progressVC.caller = "Sync non-submitted Data"
            self.show(progressVC, sender: self)
        } else if indexPath.row == 2 {
            //EHSNotificationsVC
            let EHSNotificationsVC = self.storyboard?.instantiateViewController(withIdentifier: "EHSNotificationsVC") as! EHSNotificationsVC
            self.show(EHSNotificationsVC, sender: self)
        } else if indexPath.row == 3 {
            // region
            let defaultRegion = self.storyboard?.instantiateViewController(withIdentifier: "defaultRegion") as! defaultRegionVC
            self.show(defaultRegion, sender: self)
        } else if indexPath.row == 4 {
            // check walkthrough
            let walkThrough = self.storyboard?.instantiateViewController(withIdentifier: "WalkThroughVC") as! WalkThroughVC
            self.show(walkThrough, sender: self)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if self.interfaceOrientation == UIInterfaceOrientation.landscapeLeft || self.interfaceOrientation == UIInterfaceOrientation.landscapeRight || UI_USER_INTERFACE_IDIOM() == .pad {
            if view.frame.height > view.frame.width {
                print("-50")
                return CGSize.init(width: (collectionview.frame.width/2) - 50, height: (collectionview.frame.width/2) - 100)
            } else {
                if (UI_USER_INTERFACE_IDIOM() == .pad) {
                    print("-100")
                    return CGSize.init(width: (collectionview.frame.width/2) - 230, height: 200)
                } else {
                    return CGSize.init(width: (collectionview.frame.width/2) - 150, height: 150)
                }
            }
        } else {
            return CGSize.init(width: collectionview.frame.width/2.5, height: 110)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if section == 1 {
            //80
            let totalCellWidth = 40 * collectionview.numberOfItems(inSection: 1)
            let totalSpacingWidth = 10 * (collectionview.numberOfItems(inSection: 1) - 1)
            
            let leftInset = (collectionview.layer.frame.size.width - CGFloat(totalCellWidth + totalSpacingWidth)) / 2
            let rightInset = leftInset
            print("0")
            return UIEdgeInsetsMake(0, leftInset, 0, rightInset)
        } else {
            if self.interfaceOrientation == UIInterfaceOrientation.landscapeLeft || self.interfaceOrientation == UIInterfaceOrientation.landscapeRight || UI_USER_INTERFACE_IDIOM() == .pad {
                if view.frame.height > view.frame.width {
                    print("yes")
                    return UIEdgeInsets.init(top: 10, left: 20, bottom: 50, right: 20)
                } else {
                    print("yes-no")
                    return UIEdgeInsets.init(top: 10, left: 180, bottom: 50, right: 180)
                }
            } else {
                print("no")
                return UIEdgeInsets.init(top: 10, left: 20, bottom: 20, right: 20)
            }
        }
    }
}

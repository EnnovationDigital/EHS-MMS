//
//  TableViewHeader.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/20/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class TableViewHeader: UITableViewHeaderFooterView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}

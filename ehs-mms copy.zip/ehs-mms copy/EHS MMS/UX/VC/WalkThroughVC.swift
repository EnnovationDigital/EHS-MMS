//
//  WalkThroughVC.swift
//  EHS MMS
//
//  Created by Macbook Pro on 6/21/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class WalkThroughVC: EHSBaseVC {

    @IBOutlet weak var toggle: UISwitch!
    var toggleCheck: Bool = false
    
    @IBOutlet weak var lblToken: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "back_Btn")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back_Btn")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)

        toggleCheck = UserDefaults.standard.bool(forKey: "WalkThrough")
        if (toggleCheck == true) {
            toggle.setOn(true, animated: false)
        } else {
            toggle.setOn(false, animated: false)
        }
        
        if (UserDefaults.standard.value(forKey: "APNKey") != nil) {
            lblToken.text = UserDefaults.standard.value(forKey: "APNKey") as? String
        }
        else {
            lblToken.text = "No Token"
        }        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.title = "Tutorial"
        if Constants().isPad {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .always
            } else {
                // Fallback on earlier versions
            }
        } else {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .never
            } else {
                // Fallback on earlier versions
            }
        }
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func toggleAction(_ sender: Any) {
        updateState()
    }
    
    func updateState() {
        if toggle.isOn {
            print("Switch is On")
            //toggle.setOn(true, animated:true)
            UserDefaults.standard.set(true, forKey: "WalkThrough")
        } else {
            print("Switch is off")
            //toggle.setOn(false, animated:true)
            UserDefaults.standard.set(false, forKey: "WalkThrough")
        }
    }
    
//    func stateChanged(switchState: UISwitch) {
//    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

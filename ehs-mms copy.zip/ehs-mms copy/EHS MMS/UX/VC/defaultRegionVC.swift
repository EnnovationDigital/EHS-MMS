//
//  defaultRegionVC.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/19/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import RealmSwift
import Realm

class defaultRegionVC: EHSBaseVC, UITextFieldDelegate {

    @IBOutlet var regionView: UIView!
    @IBOutlet weak var regionField: UITextField!

    let picker = UIPickerView()
    
    var realm = try! Realm()
    var errorHandle : [String] = ["No Data"]

    var arrRegion = [md_lkp_Region]()
    var regions: Results<md_lkp_Region>?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "back_Btn")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back_Btn")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)

        regionField.inputView = picker
        
        picker.delegate = self
        picker.dataSource = self
        picker.backgroundColor = UIColor.white
        picker.showsSelectionIndicator = true
        
        regionField.delegate = self
        regions = realm.objects(md_lkp_Region.self)
        
        regionField?.text = UserDefaults.standard.string(forKey: "defaultRegion")
        
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor(red: 92/255, green: 216/255, blue: 255/255, alpha: 1)
        toolBar.sizeToFit()
        // Adding Button ToolBar
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(defaultRegionVC.doneClick))
        toolBar.setItems([doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        regionField.inputAccessoryView = toolBar
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = "Default Region"
        if Constants().isPad {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .always
            } else {
                // Fallback on earlier versions
            }
        } else {
            if #available(iOS 11.0, *) {
                self.navigationItem.largeTitleDisplayMode = .never
            } else {
                // Fallback on earlier versions
            }
        }
        regionView.backgroundColor = .clear
        viewHelper.setBorderToView(view: regionView, color: UIColor.gray.cgColor)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    func getRegionId(regionName: String, regionId: Int) {   // -> Int
        let filteredRegion = realm.objects(md_lkp_Region.self).filter("regionName == %@", regionName)
        var id = Int()
        
        if (regionName == "-- Select --") {
            // show No Data record
        } else {
            for region in filteredRegion {
                if (regionName == region.regionName) {
                    id = region.regionId
                    print(id)
                }
            }
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if (regionField.isFirstResponder) { //(textField == regionField) {
        }
        picker.reloadAllComponents()
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        picker.reloadAllComponents()
    }
    
    @objc func doneClick() {
        regionField.resignFirstResponder()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension defaultRegionVC: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if regionField.isFirstResponder {
            if (regions?.count == 0) {
                return errorHandle.count
            } else {
                return self.regions?.count ?? errorHandle.count
            }
        }
        return errorHandle.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if regionField.isFirstResponder {
            return regions?[row].regionName ?? errorHandle[0]
        }
        return nil
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if regionField.isFirstResponder {
            
            self.regionField.text = self.regions?[row].regionName
            UserDefaults.standard.set("\(self.regionField.text!)",forKey: "defaultRegion")
            
            let id = md_lkp_Region().getRegionId(regionName: regionField.text!)
            getRegionId(regionName: regionField.text!, regionId: id)
        }
    }
}

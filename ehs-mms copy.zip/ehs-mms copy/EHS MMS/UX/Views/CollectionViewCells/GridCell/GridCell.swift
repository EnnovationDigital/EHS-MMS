//
//  GridCell.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/19/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class GridCell: UICollectionViewCell {

    // outlet
    @IBOutlet weak var outerView: UIView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var label: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        sizeToFit()
        layoutIfNeeded()
        self.layer.borderWidth = 1.0
        self.layer.borderColor = UIColor.gray.cgColor
        self.layer.cornerRadius = 16

        self.layer.shadowOpacity = 0.5
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowRadius = 10.0
        self.layer.shadowOffset = CGSize(width: 5, height: 5)
    }

}

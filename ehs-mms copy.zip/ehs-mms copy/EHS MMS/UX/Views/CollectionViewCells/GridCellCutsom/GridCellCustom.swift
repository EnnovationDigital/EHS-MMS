//
//  GridCellCustom.swift
//  EHS MMS
//
//  Created by Macbook Pro on 6/20/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class GridCellCustom: UICollectionViewCell {
    // outlet
    @IBOutlet weak var outerView: UIView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var label: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        sizeToFit()
        layoutIfNeeded()
        self.layer.borderWidth = 1.5
        self.layer.borderColor = UIColor.gray.cgColor
        
        self.layer.shadowRadius = 5.0
        self.layer.cornerRadius = 10
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOffset = CGSize(width: 5, height: 5)
        
        self.imageView.alpha = 0.5
    }
}

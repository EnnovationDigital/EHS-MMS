//
//  QuestionCell.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/10/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import Photos
import BSImagePicker
import Realm
import RealmSwift
import DLRadioButton


protocol QuestionCellDelegate {
    func btnUploadPictureTapped(_ sender:UIButton)
    func btnPreviewTapped(_ sender:UIButton)
}


class QuestionCell: UICollectionViewCell, UITextViewDelegate, UIScrollViewDelegate {
    var delegate: QuestionCellDelegate?
    var question : EHSQuestion?
    var inspectionID : String = ""
    var arrAnswers : Results<md_AnswersToQuestions>?
    var SelectedAssets = [PHAsset]()
    var PhotoArray = [UIImage]()
    var answerType : Int = 1
    var isRepeatable : Bool = false
    var hasSubQuestions : Bool = false
    var decisionAnswer : String = ""    
    var userAnswers : String = ""
    var locationID : Int = 0
    var usersForLocation : Results<md_Users>?
    var selectedSampleNames = NSMutableArray()
    
    @IBOutlet weak var scMain: UIScrollView!
    @IBOutlet weak var tblAnswers: UITableView!
    @IBOutlet weak var previewBtn: UIButton!
    @IBOutlet weak var viewCheckEHS: UIView!
    @IBOutlet weak var uploadBtn: UIButton!
    @IBOutlet weak var commentTextView: UITextView!
    @IBOutlet weak var uploadView: UIView!
    
    @IBOutlet weak var tblAllUsers: UITableView!
    @IBOutlet weak var btnSelectUser: UIButton!
    @IBOutlet weak var cnTableAllUsersHeight: NSLayoutConstraint!
    
    @IBOutlet weak var cnAnswerTableHeight: NSLayoutConstraint!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var cnBtnSelectUserHeight: NSLayoutConstraint!
    
    @IBOutlet weak var cnTblUsersHeight: NSLayoutConstraint!
    
    @IBOutlet weak var btnEHS: UIButton!
    @IBOutlet weak var tblUsers: UITableView!

    // MARK: - Delegate Methods
    
    @objc func btnUploadPictureTapped (_ sender:UIButton) {
        if self.delegate != nil {
            self.delegate?.btnUploadPictureTapped(sender)
        }
    }
    
    @objc func btnPreviewPicTapped(_ sender:UIButton) {
        if self.delegate != nil {
            self.delegate?.btnPreviewTapped(sender)
        }
    }
    
    // MARK: - Cell Setup
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        tblUsers.layer.cornerRadius = 10.0
        tblUsers.clipsToBounds = true
        self.tblUsers.dataSource = self
        self.tblUsers.delegate = self
        
        commentTextView.placeholder = "Comments:"
        viewHelper.setBorderToViewWithRoundCorners(view: tblAnswers, color: UIColor.lightGray.cgColor)

        uploadView.backgroundColor = .clear
        ButtonHelper.setRoundCornerButton(button: previewBtn, cornerRadius: 16.0)
        
        viewCheckEHS.backgroundColor = .clear        
        
        setUpAnswerTableCells()
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("userAnsweredCell"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(userAnswered(notif:)), name: NSNotification.Name("userAnsweredCell"), object: nil)
        
        tblUsers.isUserInteractionEnabled = true
        tblUsers.alpha = 1.0
    }
    
    func configureCell (questionObject: EHSQuestion) {
        self.question = questionObject
        selectedSampleNames = NSMutableArray(array: (question?.assignedUsers.components(separatedBy: ","))!)
        let formattedString = NSMutableAttributedString()
        formattedString.bold("Question: ").normal((question!.question))
        self.lblTitle.attributedText = formattedString
        self.setUpAnswerType(id: (question?.answerTypeId)!)
        
        self.hasSubQuestions = questionObject.hasSubQuestion
        self.decisionAnswer = questionObject.decisionAnswer
        
        self.isRepeatable = questionObject.isReaptable
        
        self.arrAnswers = md_AnswersToQuestions.getAnswers(questionId: (question?.questionId)!)
        
        if self.isRepeatable == true {
            self.viewCheckEHS.isHidden = true
            self.cnTblUsersHeight.constant = 90.0
            self.tblUsers.isUserInteractionEnabled = true
        }
        else {
            self.viewCheckEHS.isHidden = false
            self.cnTblUsersHeight.constant = 90.0
            self.layoutSubviews()
            self.tblUsers.reloadData()
        }
        
        updateEHS(status: (question?.assignedToEHS)!)
        btnEHS.isSelected = (question?.assignedToEHS)!
        
        self.tblAnswers.dataSource = self
        self.tblAnswers.delegate = self
        self.tblAnswers.reloadData()
        tblUsers.reloadData()
    }
    
    func setUpAnswerTableCells () {
        
        tblAnswers.register(UINib(nibName: "RadioButtonCell", bundle: nil), forCellReuseIdentifier: "RadioButtonCell")
        tblAnswers.register(UINib(nibName: "CheckBoxCell", bundle: nil), forCellReuseIdentifier: "CheckBoxCell")
        tblAnswers.register(UINib(nibName: "TextViewCell", bundle: nil), forCellReuseIdentifier: "TextViewCell")
        
        tblUsers.register(UINib(nibName: "UserCell", bundle: nil), forCellReuseIdentifier: "UserCell")
    }
    
    func setUpAnswerType(id:Int) {
        let answerType = md_lkp_AnswerType.getAnswerTypeFromId(id: id)
        if answerType?.answerType == "RadioButton" {
            self.answerType = 1
        }
        else if answerType?.answerType == "CheckBox" {
            self.answerType = 2
        }
        else {
            self.answerType = 3
        }
        
    }
    
    @objc func userAnswered(notif:Notification) {
        userAnswers = notif.userInfo!["answer"] as! String
    }
    
    func updateEHS (status: Bool) {
        if status == true {
            tblUsers.isUserInteractionEnabled = false
            tblUsers.alpha = 0.5
        }
        else {
            tblUsers.isUserInteractionEnabled = true
            tblUsers.alpha = 1.0
        }
    }
    
    @IBAction func btnEHSTapped(_ sender: UIButton) {
        
        sender.isSelected = !sender.isSelected
        self.updateEHS(status: sender.isSelected)
        if sender.isSelected == true {
            NotificationCenter.default.post(name: NSNotification.Name("userSelected"), object: nil, userInfo: ["users" : "EHS"])
        }
        else {
            NotificationCenter.default.post(name: NSNotification.Name("userSelected"), object: nil, userInfo: ["users" : ""])
        }
        
        
    }
    
    func isUserSelected (userID: String) -> Bool {
        let assignedUsers = question?.assignedUsers.components(separatedBy: ",")
        if assignedUsers != nil {
            if (assignedUsers?.count)! > 0 {
                if (assignedUsers?.index(of: userID)) != nil {
                    if (assignedUsers?.index(of: userID))! < (assignedUsers?.count)! {
                        return true
                    }
                }
                
            }
        }
        
        return false
    }
    
}

extension QuestionCell : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tblUsers {
            if usersForLocation != nil {
                return usersForLocation!.count
            }
            else {
                return 0
            }
        }
        if isRepeatable == true {
            if selectedSampleNames.count > 0 {
                return 1
            }
            return 0
        }
        else if isRepeatable == false {
            return 1
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if tableView == tblUsers {
            return 45.0
        }
        
        else if answerType == 2 {
            return 120.0
        }
        
        var heightEven : CGFloat = 30.0
        var heightOdd : CGFloat = 30.0
        
        for i in 0...(arrAnswers?.count)! - 1 {
            let answer = arrAnswers![i]            
            if i % 2 == 0 {
                heightEven += (answer.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
            }
            else {
                heightOdd += (answer.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
            }
        }
        
        self.cnAnswerTableHeight.constant = 10.0 + (heightEven > heightOdd ? heightEven : heightOdd)
        self.layoutSubviews()
        return 10.0 + heightEven > heightOdd ? heightEven : heightOdd
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == tblUsers {
            let cell = tableView.dequeueReusableCell(withIdentifier: "UserCell", for: indexPath) as! UserCell
            let user = usersForLocation![indexPath.row]
            cell.userName.text = user.userName
            let userID = String(format: "%ld", user.userId)
            
            if self.isRepeatable == true {
                if question?.assignedUsers == userID {
                    cell.accessoryType = .checkmark
                }
                else {
                    cell.accessoryType = .none
                }
            }
            else {
                if self.isUserSelected(userID: userID) {
                    cell.accessoryType = .checkmark
                    btnEHS.isSelected = false
                    updateEHS(status:false)
                }
                else {
                    cell.accessoryType = .none
                }
            }
            
            
            return cell
        }
        
        if (answerType == 1) {
            let cell = tableView.dequeueReusableCell(withIdentifier: "RadioButtonCell", for: indexPath) as! RadioButtonCell
            cell.arrAnswers = self.arrAnswers
            for vwSub in cell.subviews {
                if vwSub.isKind(of: DLRadioButton.self) {
                    vwSub.removeFromSuperview()
                }
                else if vwSub.isKind(of: UILabel.self) {
                    vwSub.removeFromSuperview()
                }
            }
            cell.question = question
            cell.setUpRadioButtons()
            
            return cell
        }
        else if (answerType == 2) {
            let cell = tableView.dequeueReusableCell(withIdentifier: "CheckBoxCell", for: indexPath) as! CheckBoxCell
            cell.arrAnswers = self.arrAnswers
            for vwSub in cell.subviews {
                if vwSub.isKind(of: DLRadioButton.self) {
                    vwSub.removeFromSuperview()
                }
                else if vwSub.isKind(of: UILabel.self) {
                    vwSub.removeFromSuperview()
                }
            }
            cell.question = question
            cell.setUpCheckBoxButtons()
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TextViewCell", for: indexPath) as! TextViewCell
            cell.question = question
            return cell
        }
        
    }
    
    func tableView (_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if tableView == tblUsers {
            let cell = tableView.cellForRow(at: indexPath) as! UserCell
            let user = usersForLocation![indexPath.row]
            let selectedUserId = user.userId
            if self.isRepeatable == true && selectedSampleNames.count > 0{
                if (usersForLocation?.count)! > 0 {
                    for i in 0 ... (usersForLocation?.count)! - 1 {
                        let indexPath = IndexPath(row: i, section: 0)
                        let cell = tblUsers.cellForRow(at: indexPath) as! UserCell
                        cell.accessoryType = .none
                    }
                }
                selectedSampleNames.removeAllObjects()
            }
            else {
                
            }
            if selectedSampleNames.contains(selectedUserId) {
                cell.accessoryType = .none
                let index = selectedSampleNames.index(of: selectedUserId)
                if index < selectedSampleNames.count {
                    selectedSampleNames.removeObject(at: index)
                }
            }
            else {
                cell.accessoryType = .checkmark
                selectedSampleNames.add(selectedUserId)
            }
            
            print(selectedSampleNames)
            NotificationCenter.default.post(name: NSNotification.Name("userSelected"), object: nil, userInfo: ["users" : selectedSampleNames.componentsJoined(by: ",")])
            
            self.tblAnswers.reloadData()
            if selectedSampleNames.count > 0 {
                viewCheckEHS.isUserInteractionEnabled = false
                viewCheckEHS.alpha = 0.5
            }
            else {
                viewCheckEHS.isUserInteractionEnabled = true
                viewCheckEHS.alpha = 1.0
            }
        }
        
    }
}










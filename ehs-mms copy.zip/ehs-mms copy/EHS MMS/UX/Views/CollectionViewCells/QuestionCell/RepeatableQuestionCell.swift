//
//  RepeatableQuestionCell.swift
//  EHS MMS
//
//  Created by Ikarma Khan on 26/07/2018.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

protocol QuestionCellDelegate {
    func btnUploadPictureTapped(_ sender:UIButton)
    func btnPreviewTapped(_ sender:UIButton)
}

class RepeatableQuestionCell: UICollectionViewCell {

    @IBOutlet weak var cvVertical: UICollectionView!
    
    var PhotoArray = [UIImage]()
    
    var delegate : QuestionCellDelegate?
    var question : md_Questions?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let nibFile = UINib.init(nibName: "QuestionCell", bundle: nil)
        self.cvVertical.register(nibFile, forCellWithReuseIdentifier: "QCell")
    }
    
    @objc func btnUploadPictureTapped (_ sender:UIButton) {
        if self.delegate! != nil {
            self.delegate?.btnUploadPictureTapped(sender)
        }
    }
    
    @objc func btnPreviewPicTapped(_ sender:UIButton) {
        if self.delegate! != nil {
            self.delegate?.btnPreviewTapped(sender)
        }
    }
    
}


//MARK: - CollectionViewMethods

extension RepeatableQuestionCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {

        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    
        if question?.isReaptable == true {
            // Number of users here
            return 4
        }
        else {
            return 1
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "QCell", for: indexPath) as! QuestionCell
        
        let formattedString = NSMutableAttributedString()
        formattedString.bold("Question: ").normal((question?.question!)!)
        cell.lblTitle.attributedText = formattedString
        cell.question = question
        cell.answerType = (question?.answerTypeId)!
        cell.arrAnswers = md_AnswersToQuestions.getAnswers(questionId: (question?.questionId)!)
        
        if question?.isReaptable == true {
            //cell.lblUserName.text = "Repeatable"
            cell.viewCheckEHS.isHidden = true
            cell.cnTblUsersHeight.constant = 0.0
        }
        else {
            //cell.lblUserName.text = "For All"
            cell.viewCheckEHS.isHidden = false
            cell.cnTblUsersHeight.constant = 135.0
            cell.layoutSubviews()
            cell.tblUsers.reloadData()
        }
        
        cell.tblAnswers.dataSource = cell
        cell.tblAnswers.delegate = cell
        cell.tblAnswers.reloadData()
        
        
//        cell.commentTextView.delegate = self
        cell.uploadBtn.addTarget(self, action: #selector(btnUploadPictureTapped(_:)), for: UIControlEvents.touchUpInside)
        cell.previewBtn.addTarget(self, action: #selector(btnPreviewPicTapped(_:)), for: UIControlEvents.touchUpInside)

        //        cell.scMain.contentSize = CGSize(width: cell.scMain.frame.size.width,
//                                         height: UIScreen.main.bounds.size.height + 100.0)
        //cell.commentTextView.frame.origin.y + cell.commentTextView.frame.size.height + 100.0
        print(cell.scMain.contentSize)
        print(cell.scMain.frame)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if UI_USER_INTERFACE_IDIOM() == .pad {
            if UIApplication.shared.statusBarOrientation == .landscapeLeft || UIApplication.shared.statusBarOrientation == .landscapeRight {
                return CGSize.init(width: (collectionView.frame.width) - 50 , height: (collectionView.frame.height) - 50)
            }
            else {
                return CGSize(width: UIScreen.main.bounds.size.width * 0.52 , height: (collectionView.frame.height) - 10)
//                return CGSize.init(width: (collectionView.frame.width) - 10, height: (collectionView.frame.height) - 10)
            }
        }
        else {
            return CGSize.init(width: (collectionView.frame.width) - 10, height: (collectionView.frame.height) - 30)
        }

    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        if UIApplication.shared.statusBarOrientation == .landscapeLeft || UIApplication.shared.statusBarOrientation == .landscapeRight || UI_USER_INTERFACE_IDIOM() == .pad {
            if self.frame.height > self.frame.width {
                return UIEdgeInsets.init(top: 20, left: 10, bottom: 10, right: 10)
            }
            else {
                if (UI_USER_INTERFACE_IDIOM() == .pad) {
                    if UIDevice.current.orientation == .portrait || UIDevice.current.orientation == .portraitUpsideDown {
                        print("yes-no iPad")
                        return UIEdgeInsets.init(top: 20, left: 100, bottom: 10, right: 30)
                    } else {
                        return UIEdgeInsets.init(top: 20, left: 60 , bottom: 10, right: 40)
                    }
                } else {
                    print("yes-no iPhone")
                    return UIEdgeInsets.init(top: 20, left: 10, bottom: 10, right: 10)
                }
            }
        } else {
            print("no")
            return UIEdgeInsets.init(top: 10, left: 5, bottom: 10, right: 10)
        }
    }

}

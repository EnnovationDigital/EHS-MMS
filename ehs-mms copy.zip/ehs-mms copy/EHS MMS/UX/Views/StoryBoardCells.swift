//
//  StoryBoardCells.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/10/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

struct StoryboardCells {
    static let UserTVCell = "UserCell"
    static let TextViewTVCell = "TextViewCell"
    static let CheckBoxTVCell = "CheckBoxCell"
    static let RadioButtonTVCell = "RadioButtonCell"
    static let QuestionsTVCell = "QuestionsCell"
    static let RecallTVCell = "RecallCell"
    
    static let GridCVCell = "GridCell"
    static let GridCVCellCustom = "GridCellCustom"
}

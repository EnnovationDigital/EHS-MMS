//
//  CheckBoxCell.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/9/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import DLRadioButton
import Realm
import RealmSwift

class CheckBoxCell: UITableViewCell {
    
    var arrAnswers : Results<md_AnswersToQuestions>?
    var buttonCount : NSInteger = 4
    var boxButton : DLRadioButton?
    var question : EHSQuestion?
    /* Outlets */
    var prevAnswer : [String] = [""]
    

    override func awakeFromNib() {
        super.awakeFromNib()
    
    }
    
    func fetchSelectedAnswers() {
        if (question?.answerIds?.count)! > 0 {
            prevAnswer = (question?.answerIds?.components(separatedBy: ","))!
        }
        else {
            prevAnswer = [""]
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    @objc func answerSelected(_ sender: DLRadioButton) {
        
        let answer  = NSMutableArray()
        for button in sender.selectedButtons() {
            let selectedTag = button.tag
            let objAnswer = arrAnswers![selectedTag]
            answer.add(objAnswer.answerId)
        }
        let allAnswers = answer.componentsJoined(by: ",")
        
        NotificationCenter.default.post(name: NSNotification.Name("userAnswered"), object: nil, userInfo: ["answer" : allAnswers,"type" : "C"])
        
    }
    
    func answerIdString(answer:md_AnswersToQuestions) -> String {
        let answerId = String(format: "%ld", (answer.answerId))
        return answerId
    }
    
    func createLabel(text:String, frame: CGRect) ->UILabel {
        let lblTitle = UILabel(frame: frame)
        lblTitle.numberOfLines = 0
        lblTitle.font = UIFont.systemFont(ofSize: 14.0)
        lblTitle.lineBreakMode = .byWordWrapping
        lblTitle.text = text
        lblTitle.sizeToFit()
        return lblTitle
    }
    
    func createRadioButton (frame:CGRect) -> DLRadioButton {
        let boxButtonOther = DLRadioButton(frame: frame)
        boxButtonOther.iconColor = .black
        boxButtonOther.isMultipleSelectionEnabled = true
        boxButtonOther.isIconSquare = true
        boxButtonOther.indicatorColor = .black
        
        return boxButtonOther
    }
    
    
    func heightCalculator (forIndex: NSInteger) -> CGFloat{
        var heightEven : CGFloat = 0.0
        var heightOdd : CGFloat = 0.0
        
        for i in 0...forIndex - 1 {
            let answer = arrAnswers![i]
            
            if i % 2 == 0 {
                heightEven += (answer.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
            }
            else {
                heightOdd += (answer.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
            }
        }
        
        return (forIndex % 2 == 0 ? heightEven : heightOdd)
    }
    
    func shouldBeMultiLined () -> Bool {
        var flag = false
        for i in 0 ... (arrAnswers?.count)! - 1 {
            let answer = arrAnswers?[i]
            let answerHeight = (answer?.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
            if answerHeight > 60.0 {
                flag = true
                break
            }
        }
        return flag
    }
    
    func setUpCheckBoxButtons () {
        self.fetchSelectedAnswers()
        let answerWidth : CGFloat = Constants().answerWidth()
        
        // For 0
        
        var frame = CGRect(x: 0.0, y: 10.0, width: 30.0, height: 30.0)
        boxButton = DLRadioButton(frame: frame)
        boxButton?.iconColor = .black
        boxButton?.isMultipleSelectionEnabled = true
        boxButton?.isIconSquare = true
        boxButton?.indicatorColor = .black
        boxButton?.addTarget(self, action: #selector(answerSelected(_:)), for: .touchUpInside)
        let answer = arrAnswers?[0]
        self.addSubview((boxButton)!)
        let answerHeight = (answer?.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
        let lblFrame = CGRect(x: 35.0, y: 15.0, width: Double(answerWidth), height: Double(answerHeight))
        boxButton?.center = CGPoint(x: (boxButton?.center.x)!, y: CGFloat(lblFrame.origin.y) + CGFloat(answerHeight/2.0))
        self.addSubview(createLabel(text: (answer?.answer)!, frame: lblFrame))
        boxButton?.tag = 0
        if prevAnswer.contains(answerIdString(answer: answer!)) {
            boxButton?.isSelected = true
        }
        else {
            boxButton?.isSelected = false
        }
        
        if (arrAnswers?.count)! > 1 {
            // For 1
            let x = 35.0 + answerWidth
            let y = 10.0
            frame = CGRect(x: Double(x), y: Double(y), width: 30.0, height: 30.0)
            let boxButtonOther =  createRadioButton(frame: frame)
            self.addSubview(boxButtonOther)
            boxButton?.otherButtons.append(boxButtonOther)
            
            let answer = arrAnswers?[1]
            if prevAnswer.contains(answerIdString(answer: answer!)) {
                boxButtonOther.isSelected = true
            }
            else {
                boxButtonOther.isSelected = false
            }
            boxButtonOther.tag = 1
            boxButtonOther.addTarget(self, action: #selector(answerSelected(_:)), for: .touchUpInside)
            let answerHeight = (answer?.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
            let lblFrame = CGRect(x: Double(x) + 35.0, y: 15.0, width: Double(answerWidth), height: Double(answerHeight))
            self.addSubview(createLabel(text: (answer?.answer)!, frame: lblFrame))
        }
        
        if (arrAnswers?.count)! > 2 {
            for i in 2 ... (arrAnswers?.count)! - 1 {
                let answerHeight = (answer?.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
                let x = i % 2 == 0 ? 0.0 : 35 + answerWidth
                var y = ((i/2) * 5 + (i/2) * 30)
                y += 10
                let frame = CGRect(x: Double(x), y: Double(y) + 20.0, width: 30.0, height: 30.0)
                let boxButtonOther =  createRadioButton(frame: frame)
                self.addSubview(boxButtonOther)
                boxButton?.otherButtons.append(boxButtonOther)
                
                let answer = arrAnswers?[i]
                let prevHeight = heightCalculator(forIndex: i)
                if prevAnswer.contains(answerIdString(answer: answer!)) {
                    boxButtonOther.isSelected = true
                }
                else {
                    boxButtonOther.isSelected = false
                }
                boxButtonOther.tag = i
                boxButtonOther.addTarget(self, action: #selector(answerSelected(_:)), for: .touchUpInside)
                let lblFrame = CGRect(x: Double(x) + 35.0, y: Double(prevHeight) + 25.0, width: Double(answerWidth), height: Double(answerHeight+10.0))
                boxButtonOther.center = CGPoint(x: boxButtonOther.center.x, y: CGFloat(lblFrame.origin.y) + CGFloat(answerHeight/2.0))
                self.addSubview(createLabel(text: (answer?.answer)!, frame: lblFrame))
            }
        }
        
    }

    
    
    
//    func setUpCheckBoxButtons () {
//
//        let frame = CGRect(x: 10.0, y: 10.0, width: 30.0, height: 30.0)
//        boxButton = DLRadioButton(frame: frame)
//        boxButton?.iconColor = .black
//        boxButton?.isMultipleSelectionEnabled = true
//        boxButton?.indicatorColor = .black
//        boxButton?.isIconSquare = true
//
//        let lblFrame = CGRect(x: 45.0, y: 10.0, width: 100.0, height: 30.0)
//        let lblTitle = UILabel(frame: lblFrame)
//        lblTitle.text = String(format: "%ld", 0)
//        self.addSubview((boxButton)!)
//        self.addSubview(lblTitle)
//
//
//        for i in 1 ... buttonCount - 1 {
//
//            let x = i % 2 == 0 ? 10.0 : 140.0
//            let y = ((i/2) * 5 + (i/2) * 30)
//            let frame = CGRect(x: Double(x), y: Double(y) + 10.0, width: 30.0, height: 30.0)
//            let boxButtonOther = DLRadioButton(frame: frame)
//            boxButtonOther.iconColor = .black
//
//            boxButtonOther.indicatorColor = .black
//
//
//            let lblFrame = CGRect(x: Double(x) + 45.0, y: Double(y) + 10.0, width: 100.0, height: 30.0)
//            let lblTitle = UILabel(frame: lblFrame)
//            lblTitle.text = String(format: "%ld", i)
//
//
//            self.addSubview(boxButtonOther)
//            self.addSubview(lblTitle)
//            boxButton?.otheboxButtons.append(boxButtonOther)
//        }
//    }

}

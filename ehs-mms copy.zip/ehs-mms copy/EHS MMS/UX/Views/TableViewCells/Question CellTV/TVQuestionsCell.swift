//
//  QuestionsCell.swift
//  EHS MMS
//
//  Created by Macbook Pro on 2/22/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class QuestionsCell: UICollectionViewCell {

    @IBOutlet weak var questionNum: UIButton!
    @IBOutlet weak var question: UILabel!
    
    let check : Bool = false
    
    var optionTapped : ((UICollectionViewCell) -> Void)?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    // action
    @IBAction func tapOption(_ sender: Any) {
//        optionTapped?(self)
//        if (check) {
            questionNum.setImage(UIImage(named: "001-rec-circular-button"), for: UIControlState.normal)
//        }
    }
    
}

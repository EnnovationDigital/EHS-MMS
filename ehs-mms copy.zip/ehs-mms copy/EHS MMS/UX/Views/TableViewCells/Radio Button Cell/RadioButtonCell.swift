//
//  RadioButtonCell.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/9/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import DLRadioButton
import Realm
import RealmSwift

class RadioButtonCell: UITableViewCell {
    
//    var buttonCount : NSInteger = 4
    var rButton : DLRadioButton?
    /* Outlets */
    
    var arrAnswers : Results<md_AnswersToQuestions>?
    var prevAnswer : String = ""
    var question : EHSQuestion?
    var realm = try! Realm()
    
    // Views
    @IBOutlet weak var viewOne: UIView!
    @IBOutlet weak var viewTwo: UIView!
    
    // Buttons
    @IBOutlet weak var radioOne: DLRadioButton!
   // @IBOutlet weak var radioTwo: DLRadioButton!

    // Labels
    @IBOutlet weak var optionOne: UILabel!
    @IBOutlet weak var optionTwo: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        for vwSub in self.subviews {
            if vwSub.isKind(of: DLRadioButton.self) {
                vwSub.removeFromSuperview()
            }
        }
    }

    func createLabel(text:String, frame: CGRect) ->UILabel {
        let lblTitle = UILabel(frame: frame)
        lblTitle.numberOfLines = 0
        lblTitle.font = UIFont.systemFont(ofSize: 14.0)
        lblTitle.lineBreakMode = .byWordWrapping
        lblTitle.text = text
        lblTitle.sizeToFit()
        return lblTitle
    }
    
    func fetchSelectedAnswers() {
        if question?.answerIds != "" {
            prevAnswer = (question?.answerIds)!
        }
        else {
            prevAnswer = ""
        }
    }
    
    @objc func answerSelected(_ sender: DLRadioButton) {
        
        let selectedTag = sender.selected()?.tag
        let answer = arrAnswers![selectedTag!]
        NotificationCenter.default.post(name: NSNotification.Name("userAnswered"), object: nil, userInfo: ["answer" : String(format: "%ld",answer.answerId),"type" : "R"])        
        
    }
    
    func createRadioButton (frame:CGRect) -> DLRadioButton {
        let rButtonOther = DLRadioButton(frame: frame)
        rButtonOther.iconColor = .black
        rButtonOther.isMultipleSelectionEnabled = false
        rButtonOther.indicatorColor = .black
        return rButtonOther
    }
    
    
    func heightCalculator (forIndex: NSInteger) -> CGFloat {
        var heightEven : CGFloat = 0.0
        var heightOdd : CGFloat = 0.0
        
        for i in 0...forIndex - 1 {
            let answer = arrAnswers![i]
            
            if i % 2 == 0 {
                heightEven += (answer.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
            }
            else {
                heightOdd += (answer.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
            }
        }
        
        return (forIndex % 2 == 0 ? heightEven : heightOdd)
    }
    
    func shouldBeMultiLined () -> Bool {
        var flag = false
        for i in 0 ... (arrAnswers?.count)! - 1 {
            let answer = arrAnswers?[i]
            let answerHeight = (answer?.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
            if answerHeight > 60.0 {
                flag = true
                break
            }
        }
        return flag
    }
    
    func answerIdString(answer:md_AnswersToQuestions) -> String {
        let answerId = String(format: "%ld", (answer.answerId))
        return answerId
    }
    
    func setUpRadioButtons () {
        
        self.fetchSelectedAnswers()
        print(prevAnswer)
        let answerWidth : CGFloat = Constants().answerWidth()

        // For 0    
        
        var frame = CGRect(x: 0.0, y: 10.0, width: 30.0, height: 30.0)
        rButton = DLRadioButton(frame: frame)
        rButton?.iconColor = .black
        rButton?.isMultipleSelectionEnabled = false
        rButton?.indicatorColor = .black
        rButton?.addTarget(self, action: #selector(answerSelected(_:)), for: .touchUpInside)
        rButton?.tag = 0
        
        let answer = arrAnswers?[0]
        self.addSubview((rButton)!)
        let answerHeight = (answer?.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
        let lblFrame = CGRect(x: 35.0, y: 15.0, width: Double(answerWidth), height: Double(answerHeight))
        rButton?.center = CGPoint(x: (rButton?.center.x)!, y: CGFloat(lblFrame.origin.y) + CGFloat(answerHeight/2.0))
        self.addSubview(createLabel(text: (answer?.answer)!, frame: lblFrame))
        
        if prevAnswer == answerIdString(answer: answer!) {
            rButton?.isSelected = true
            rButton?.deselectOtherButtons()
        }
        else {
            rButton?.isSelected = false
        }
        if (arrAnswers?.count)! > 1 {
            // For 1
            let answer = arrAnswers?[1]
            let x = 35.0 + answerWidth
            let y = 10.0
            frame = CGRect(x: Double(x), y: Double(y), width: 30.0, height: 30.0)
            let rButtonOther =  createRadioButton(frame: frame)
            self.addSubview(rButtonOther)
            if prevAnswer == answerIdString(answer: answer!) {
                rButtonOther.isSelected = true
                rButtonOther.deselectOtherButtons()
            }
            else {
                rButtonOther.isSelected = false
            }
            rButtonOther.addTarget(self, action: #selector(answerSelected(_:)), for: .touchUpInside)
            rButton?.otherButtons.append(rButtonOther)
            
            rButtonOther.tag = 1
            let answerHeight = (answer?.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
            let lblFrame = CGRect(x: Double(x) + 35.0, y: 15.0, width: Double(answerWidth), height: Double(answerHeight))
            self.addSubview(createLabel(text: (answer?.answer)!, frame: lblFrame))
        }
        
        if (arrAnswers?.count)! > 2 {
            for i in 2 ... (arrAnswers?.count)! - 1 {
                let answerHeight = (answer?.answer?.heightWithConstrainedWidth(width: Constants().answerWidth(), font: UIFont.systemFont(ofSize: 15.0)))!
             
                let x = i % 2 == 0 ? 0.0 : 35 + answerWidth
                var y = ((i/2) * 5 + (i/2) * 30)
                y += 10
                let frame = CGRect(x: Double(x), y: Double(y) + 20.0, width: 30.0, height: 30.0)
                let rButtonOther =  createRadioButton(frame: frame)
                self.addSubview(rButtonOther)
                rButton?.otherButtons.append(rButtonOther)
                
                let answer = arrAnswers?[i]
                if prevAnswer == answerIdString(answer: answer!) {
                    rButtonOther.isSelected = true
                    rButtonOther.deselectOtherButtons()
                }
                else {
                    rButtonOther.isSelected = false
                }
                let prevHeight = heightCalculator(forIndex: i)
                
                let lblFrame = CGRect(x: Double(x) + 35.0, y: Double(prevHeight) + 25.0, width: Double(answerWidth), height: Double(answerHeight+10.0))
                rButtonOther.center = CGPoint(x: rButtonOther.center.x, y: CGFloat(lblFrame.origin.y) + CGFloat(answerHeight/2.0))
                rButtonOther.addTarget(self, action: #selector(answerSelected(_:)), for: .touchUpInside)
                rButtonOther.tag = i
                self.addSubview(createLabel(text: (answer?.answer)!, frame: lblFrame))
            }
        }
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

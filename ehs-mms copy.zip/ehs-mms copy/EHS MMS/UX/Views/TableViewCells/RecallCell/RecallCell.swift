//
//  DetailCellTableViewCell.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/8/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class RecallCell: UITableViewCell {

    @IBOutlet weak var ticketId: UILabel!
    @IBOutlet weak var lastUpdated: UILabel!
    @IBOutlet weak var status: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.backgroundColor = UIColor.clear
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

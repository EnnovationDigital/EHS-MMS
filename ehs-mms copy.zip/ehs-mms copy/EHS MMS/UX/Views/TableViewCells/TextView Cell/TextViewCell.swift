//
//  TextViewCell.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/9/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class TextViewCell: UITableViewCell, UITextViewDelegate {

    @IBOutlet weak var answerTextView: UITextView!
    var question : EHSQuestion?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        answerTextView.delegate  = self
        answerTextView.text = question?.textAnswer
    }

    func textViewDidEndEditing(_ textView: UITextView) {
        NotificationCenter.default.post(name: NSNotification.Name("userAnswered"), object: nil, userInfo: ["answer" : textView.text!,
                                                                                                           "type" : "T"])
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
        answerTextView.placeholder = "Answer:"
    }
}

//
//  UserCell.swift
//  EHS MMS
//
//  Created by App Developers R US Pvt Ltd Co on 7/10/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class UserCell: UITableViewCell {

    @IBOutlet weak var userName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
